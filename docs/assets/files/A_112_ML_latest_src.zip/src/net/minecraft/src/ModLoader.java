package net.minecraft.src;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.Charset;
import java.security.DigestException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Random;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.imageio.ImageIO;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;

public final class ModLoader {
	
	// TODO: getMinecraftDir
	
	private static final List animList = new LinkedList();
	private static final Map blockModels = new HashMap();
	private static final Map blockSpecialInv = new HashMap();
	private static final File cfgdir = new File(Minecraft.getMinecraftDir(), "/config/");
	private static final File cfgfile = new File(cfgdir, "ModLoader.cfg");
	public static Level cfgLoggingLevel = Level.FINER;
	private static Map classMap = null;
	private static long clock = 0L;
	public static final boolean DEBUG = false;
	//private static Field field_animList = null;
	//private static Field field_armorList = null;
	private static Field field_modifiers = null;
	//private static Field field_TileEntityRenderers = null;
	private static boolean hasInit = false;
	private static int highestEntityId = 3000;
	private static final Map inGameHooks = new HashMap();
	private static final Map inGUIHooks = new HashMap();
	//private static Minecraft instance = null;
	public static Object serverInstance = null;
	private static int itemSpriteIndex = 0;
	private static int itemSpritesLeft = 0;
	private static final Map keyList = new HashMap();
	//private static String langPack = null;
	private static Map localizedStrings = new HashMap();
	private static final File logfile = new File(Minecraft.getMinecraftDir(), "ModLoader.txt");
	private static final Logger logger = Logger.getLogger("ModLoader");
	private static FileHandler logHandler = null;
	private static Method method_RegisterEntityID = null;
	private static Method method_RegisterTileEntity = null;
	private static final File modDir = new File(Minecraft.getMinecraftDir(), "/mods/");
	private static final LinkedList modList = new LinkedList();
	private static int nextBlockModelID = 1000;
	private static final Map overrides = new HashMap();
	private static final Map packetChannels = new HashMap();
	public static final Properties props = new Properties();
	//private static BiomeGenBase[] standardBiomes;
	private static int terrainSpriteIndex = 0;
	private static int terrainSpritesLeft = 0;
	//private static String texPack = null;
	private static boolean texturesAdded = false;
	private static final boolean[] usedItemSprites = new boolean[256];
	private static final boolean[] usedTerrainSprites = new boolean[256];
	public static final String VERSION = "ModLoader 1.2.5";
	private static NetClientHandler netHandler = null;

	/*
	public static void addAchievementDesc(Achievement achievement, String name, String description) {
		try {
			if(achievement.getName().contains(".")) {
				String[] e = achievement.getName().split("\\.");
				if(e.length == 2) {
					String key = e[1];
					addLocalization("achievement." + key, name);
					addLocalization("achievement." + key + ".desc", description);
					setPrivateValue(StatBase.class, achievement, 1, StatCollector.translateToLocal("achievement." + key));
					setPrivateValue(Achievement.class, achievement, 3, StatCollector.translateToLocal("achievement." + key + ".desc"));
				} else {
					setPrivateValue(StatBase.class, achievement, 1, name);
					setPrivateValue(Achievement.class, achievement, 3, description);
				}
			} else {
				setPrivateValue(StatBase.class, achievement, 1, name);
				setPrivateValue(Achievement.class, achievement, 3, description);
			}
		} catch (IllegalArgumentException illegalArgumentException5) {
			logger.throwing("ModLoader", "AddAchievementDesc", illegalArgumentException5);
			throwException(illegalArgumentException5);
		} catch (SecurityException securityException6) {
			logger.throwing("ModLoader", "AddAchievementDesc", securityException6);
			throwException(securityException6);
		} catch (NoSuchFieldException noSuchFieldException7) {
			logger.throwing("ModLoader", "AddAchievementDesc", noSuchFieldException7);
			throwException(noSuchFieldException7);
		}

	}
	*/

	public static int addAllFuel(int id, int metadata) {
		logger.finest("Finding fuel for " + id);
		int result = 0;

		for(Iterator iter = modList.iterator(); iter.hasNext() && result == 0; result = ((BaseMod)iter.next()).addFuel(id, metadata)) {
		}

		if(result != 0) {
			logger.finest("Returned " + result);
		}

		return result;
	}

	public static void addAllRenderers(Map renderers) {
		if(!hasInit) {
			init();
			logger.fine("Initialized");
		}

		Iterator iterator2 = modList.iterator();

		while(iterator2.hasNext()) {
			BaseMod mod = (BaseMod)iterator2.next();
			mod.addRenderer(renderers);
		}

	}

	public static void addAnimation(TextureFX anim) {
		logger.finest("Adding animation " + anim.toString());
		Iterator iterator2 = animList.iterator();

		while(iterator2.hasNext()) {
			TextureFX oldAnim = (TextureFX)iterator2.next();
			if(oldAnim.iconIndex == anim.iconIndex && oldAnim.tileImage == anim.tileImage) {
				animList.remove(anim);
				break;
			}
		}

		animList.add(anim);
	}

	public static int addArmor(String armor) {
		try {
			// Made armorFilenamePrefix public, so need to fiddle.
			/*
			String[] e = (String[])field_armorList.get((Object)null);
			List existingArmorList = Arrays.asList(e);
			ArrayList combinedList = new ArrayList();
			combinedList.addAll(existingArmorList);
			if(!combinedList.contains(armor)) {
				combinedList.add(armor);
			}

			int index = combinedList.indexOf(armor);
			field_armorList.set((Object)null, combinedList.toArray(new String[0]));
			*/
			List existingArmorList = Arrays.asList(RenderPlayer.armorFilenamePrefix);
			ArrayList combinedList = new ArrayList();
			combinedList.addAll(existingArmorList);
			if(!combinedList.contains(armor)) {
				combinedList.add(armor);
			}
			
			int index = combinedList.indexOf(armor);
			RenderPlayer.armorFilenamePrefix = (String[]) combinedList.toArray(new String[0]);	
			
			return index;
		} catch (IllegalArgumentException illegalArgumentException5) {
			logger.throwing("ModLoader", "AddArmor", illegalArgumentException5);
			throwException("An impossible error has occured!", illegalArgumentException5);
		} /*catch (IllegalAccessException illegalAccessException6) {
			logger.throwing("ModLoader", "AddArmor", illegalAccessException6);
			throwException("An impossible error has occured!", illegalAccessException6);
		}*/

		return -1;
	}

	/*
	public static void addBiome(BiomeGenBase biome) {
		BiomeGenBase[] existingBiomes = GenLayerBiome.biomeArray;
		List existingBiomeList = Arrays.asList(existingBiomes);
		ArrayList combinedList = new ArrayList();
		combinedList.addAll(existingBiomeList);
		if(!combinedList.contains(biome)) {
			combinedList.add(biome);
		}

		GenLayerBiome.biomeArray = (BiomeGenBase[])combinedList.toArray(new BiomeGenBase[0]);
	}
	*/

	public static void addLocalization(String key, String value) {
		addLocalization(key, "en_US", value);
	}

	public static void addLocalization(String key, String lang, String value) {
		Object langMap;
		if(localizedStrings.containsKey(lang)) {
			langMap = (Map)localizedStrings.get(lang);
		} else {
			langMap = new HashMap();
			localizedStrings.put(lang, langMap);
		}

		((Map)langMap).put(key, value);
	}

	private static void addMod(ClassLoader loader, String filename) {
		try {
			String e = filename.split("\\.")[0];
			if(e.contains("$")) {
				return;
			}

			if(props.containsKey(e) && (props.getProperty(e).equalsIgnoreCase("no") || props.getProperty(e).equalsIgnoreCase("off"))) {
				return;
			}

			Package pack = ModLoader.class.getPackage();
			if(pack != null) {
				e = pack.getName() + "." + e;
			}

			Class instclass = loader.loadClass(e);
			if(!BaseMod.class.isAssignableFrom(instclass)) {
				return;
			}

			setupProperties(instclass);
			BaseMod mod = (BaseMod)instclass.newInstance();
			if(mod != null) {
				modList.add(mod);
				logger.fine("Mod Initialized: \"" + mod.toString() + "\" from " + filename);
				System.out.println("Mod Initialized: " + mod.toString());
			}
		} catch (Throwable throwable6) {
			logger.fine("Failed to load mod from \"" + filename + "\"");
			System.out.println("Failed to load mod from \"" + filename + "\"");
			logger.throwing("ModLoader", "addMod", throwable6);
			throwException(throwable6);
		}

	}

	public static void addName(Object instance, String name) {
		addName(instance, "en_US", name);
	}

	public static void addName(Object instance, String lang, String name) {
		/*
		String tag = null;
		Exception e3;
		if(instance instanceof Item) {
			Item e = (Item)instance;
			if(e.getItemName() != null) {
				tag = e.getItemName() + ".name";
			}
		} else if(instance instanceof Block) {
			Block e1 = (Block)instance;
			if(e1.getBlockName() != null) {
				tag = e1.getBlockName() + ".name";
			}
		} else if(instance instanceof ItemStack) {
			ItemStack e2 = (ItemStack)instance;
			String stackTag = Item.itemsList[e2.itemID].getItemNameIS(e2);
			if(stackTag != null) {
				tag = stackTag + ".name";
			}
		} else {
			e3 = new Exception(instance.getClass().getName() + " cannot have name attached to it!");
			logger.throwing("ModLoader", "AddName", e3);
			throwException(e3);
		}

		if(tag != null) {
			addLocalization(tag, lang, name);
		} else {
			e3 = new Exception(instance + " is missing name tag!");
			logger.throwing("ModLoader", "AddName", e3);
			throwException(e3);
		}
		*/
	}

	public static int addOverride(String fileToOverride, String fileToAdd) {
		try {
			int e = getUniqueSpriteIndex(fileToOverride);
			addOverride(fileToOverride, fileToAdd, e);
			return e;
		} catch (Throwable throwable3) {
			logger.throwing("ModLoader", "addOverride", throwable3);
			throwException(throwable3);
			throw new RuntimeException(throwable3);
		}
	}

	public static void addOverride(String path, String overlayPath, int index) {
		byte dst1;
		int left1;
		if(path.equals("/terrain.png")) {
			dst1 = 0;
			left1 = terrainSpritesLeft;
		} else {
			if(!path.equals("/gui/items.png")) {
				return;
			}

			dst1 = 1;
			left1 = itemSpritesLeft;
		}

		System.out.println("Overriding " + path + " with " + overlayPath + " @ " + index + ". " + left1 + " left.");
		logger.finer("addOverride(" + path + "," + overlayPath + "," + index + "). " + left1 + " left.");
		Object overlays = (Map)overrides.get(Integer.valueOf(dst1));
		if(overlays == null) {
			overlays = new HashMap();
			overrides.put(Integer.valueOf(dst1), overlays);
		}

		((Map)overlays).put(overlayPath, index);
	}

	public static void addRecipe(ItemStack output, Object... params) {
		CraftingManager.getInstance().addRecipe(output, params);
	}

	public static void addShapelessRecipe(ItemStack output, Object... params) {
		CraftingManager.getInstance().addShapelessRecipe(output, params);
	}

	/*
	public static void addSmelting(int input, ItemStack output) {
		FurnaceRecipes.smelting().addSmelting(input, output);
	}*/
	// Alpha version
	public static void addSmelting(int input, int output) {
		TileEntityFurnace.smeltings.put(Integer.valueOf(input), Integer.valueOf(output));
	}

	public static void addSpawn(Class entityClass, int weightedProb, int min, int max, EnumCreatureType spawnList) {
		if(entityClass == null) {
			throw new IllegalArgumentException("entityClass cannot be null");
		} else if(spawnList == null) {
			throw new IllegalArgumentException("spawnList cannot be null");
		} else {

			// Custom code. We'll store the new spanw list entry in the right list.
			if(spawnList == EnumCreatureType.creature) {
				SpawnLists.spawnableAnimals.add(entityClass);
			} else {
				SpawnLists.spawnableMobs.add(entityClass);
			}
			
		}
	}

	public static void addSpawn(String entityName, int weightedProb, int min, int max, EnumCreatureType spawnList) {
		Class entityClass = (Class)classMap.get(entityName);
		if(entityClass != null && EntityLiving.class.isAssignableFrom(entityClass)) {
			addSpawn(entityClass, weightedProb, min, max, spawnList);
		}

	}

	public static boolean dispenseEntity(World world, double x, double y, double z, int xVel, int zVel, ItemStack item) {
		boolean result = false;

		for(Iterator iter = modList.iterator(); iter.hasNext() && !result; result = ((BaseMod)iter.next()).dispenseEntity(world, x, y, z, xVel, zVel, item)) {
		}

		return result;
	}

	public static void genericContainerRemoval(World world, int x, int y, int z) {
		IInventory container = (IInventory)world.getBlockTileEntity(x, y, z);
		if(container != null) {
			for(int i = 0; i < container.getSizeInventory(); ++i) {
				ItemStack item = container.getStackInSlot(i);
				if(item != null) {
					double xOffset = world.rand.nextDouble() * 0.8D + 0.1D;
					double yOffset = world.rand.nextDouble() * 0.8D + 0.1D;

					EntityItem entity;
					for(double zOffset = world.rand.nextDouble() * 0.8D + 0.1D; item.stackSize > 0; world.spawnEntityInWorld(entity)) {
						int amt = world.rand.nextInt(21) + 10;
						if(amt > item.stackSize) {
							amt = item.stackSize;
						}

						item.stackSize -= amt;
						entity = new EntityItem(world, (double)x + xOffset, (double)y + yOffset, (double)z + zOffset, new ItemStack(item.itemID, amt, item.getItemDamage()));
						double speed = 0.05D;
						entity.motionX = world.rand.nextGaussian() * speed;
						entity.motionY = world.rand.nextGaussian() * speed + 0.2D;
						entity.motionZ = world.rand.nextGaussian() * speed;
						/*
						if(item.hasTagCompound()) {
							entity.item.setTagCompound((NBTTagCompound)item.getTagCompound().copy());
						}
						*/
					}

					container.setInventorySlotContents(i, (ItemStack)null);
				}
			}
		}

	}

	public static List getLoadedMods() {
		return Collections.unmodifiableList(modList);
	}

	public static Logger getLogger() {
		return logger;
	}

	public static Minecraft getMinecraftInstance() {
		// Now minecraft is accessible. But I'm leaving this for compatibility.
		
		/*
		if(instance == null) {
			try {
				ThreadGroup e = Thread.currentThread().getThreadGroup();
				int count = e.activeCount();
				Thread[] threads = new Thread[count];
				e.enumerate(threads);

				int i;
				for(i = 0; i < threads.length; ++i) {
					System.out.println(threads[i].getName());
				}

				for(i = 0; i < threads.length; ++i) {
					if(threads[i].getName().equals("Minecraft main thread")) {
						instance = (Minecraft)getPrivateValue(Thread.class, threads[i], "target");
						break;
					}
				}
			} catch (SecurityException securityException4) {
				logger.throwing("ModLoader", "getMinecraftInstance", securityException4);
				throw new RuntimeException(securityException4);
			} catch (NoSuchFieldException noSuchFieldException5) {
				logger.throwing("ModLoader", "getMinecraftInstance", noSuchFieldException5);
				throw new RuntimeException(noSuchFieldException5);
			}
		}

		return instance;
		*/
		
		return Minecraft.instance;
	}

	public static Object getPrivateValue(Class instanceclass, Object instance, int fieldindex) throws IllegalArgumentException, SecurityException, NoSuchFieldException {
		try {
			Field e = instanceclass.getDeclaredFields()[fieldindex];
			e.setAccessible(true);
			return e.get(instance);
		} catch (IllegalAccessException illegalAccessException4) {
			logger.throwing("ModLoader", "getPrivateValue", illegalAccessException4);
			throwException("An impossible error has occured!", illegalAccessException4);
			return null;
		}
	}

	public static Object getPrivateValue(Class instanceclass, Object instance, String field) throws IllegalArgumentException, SecurityException, NoSuchFieldException {
		try {
			Field e = instanceclass.getDeclaredField(field);
			e.setAccessible(true);
			return e.get(instance);
		} catch (IllegalAccessException illegalAccessException4) {
			logger.throwing("ModLoader", "getPrivateValue", illegalAccessException4);
			throwException("An impossible error has occured!", illegalAccessException4);
			return null;
		}
	}

	public static int getUniqueBlockModelID(BaseMod mod, boolean full3DItem) {
		int id = nextBlockModelID++;
		blockModels.put(id, mod);
		blockSpecialInv.put(id, full3DItem);
		return id;
	}

	public static int getUniqueEntityId() {
		return highestEntityId++;
	}

	private static int getUniqueItemSpriteIndex() {
		while(itemSpriteIndex < usedItemSprites.length) {
			if(!usedItemSprites[itemSpriteIndex]) {
				usedItemSprites[itemSpriteIndex] = true;
				--itemSpritesLeft;
				return itemSpriteIndex++;
			}

			++itemSpriteIndex;
		}

		Exception e = new Exception("No more empty item sprite indices left!");
		logger.throwing("ModLoader", "getUniqueItemSpriteIndex", e);
		throwException(e);
		return 0;
	}

	public static int getUniqueSpriteIndex(String path) {
		if(path.equals("/gui/items.png")) {
			return getUniqueItemSpriteIndex();
		} else if(path.equals("/terrain.png")) {
			return getUniqueTerrainSpriteIndex();
		} else {
			Exception e = new Exception("No registry for this texture: " + path);
			logger.throwing("ModLoader", "getUniqueItemSpriteIndex", e);
			throwException(e);
			return 0;
		}
	}

	private static int getUniqueTerrainSpriteIndex() {
		while(terrainSpriteIndex < usedTerrainSprites.length) {
			if(!usedTerrainSprites[terrainSpriteIndex]) {
				usedTerrainSprites[terrainSpriteIndex] = true;
				--terrainSpritesLeft;
				return terrainSpriteIndex++;
			}

			++terrainSpriteIndex;
		}

		Exception e = new Exception("No more empty terrain sprite indices left!");
		logger.throwing("ModLoader", "getUniqueItemSpriteIndex", e);
		throwException(e);
		return 0;
	}

	private static void init() {
		hasInit = true;
		String usedItemSpritesString = "1111111111111111111111111111111111111101111111111111111111111111111111111111111111111111111111111111110111111111111111000111111111111101111111110000000101111111000000010101111100000000000000110000000000000000000000000000000000000000000000001111111111111111";
		String usedTerrainSpritesString = "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111110000001111111111000000001111111100000111111111100000001111111110000001111111111111111111";

		for(int e = 0; e < 256; ++e) {
			usedItemSprites[e] = usedItemSpritesString.charAt(e) == 49;
			if(!usedItemSprites[e]) {
				++itemSpritesLeft;
			}

			usedTerrainSprites[e] = usedTerrainSpritesString.charAt(e) == 49;
			if(!usedTerrainSprites[e]) {
				++terrainSpritesLeft;
			}
		}

		try {
			// This part originally hacks into Minecraft.java using reflection.
			// There's no need for this, I don't have any trouble changing Minecraft.java directly!
			
			// But this is needed:
			field_modifiers = Field.class.getDeclaredField("modifiers");
			field_modifiers.setAccessible(true);
						
			// Change EntityRenderer to EntityRendererProxy
			/*
			instance = (Minecraft)getPrivateValue(Minecraft.class, (Object)null, 1);
			instance.entityRenderer = new EntityRendererProxy(instance);
			*/
			if(isThisClient()) Minecraft.instance.entityRenderer = new EntityRendererProxy(Minecraft.instance);
			
			// Get EntityList.stringToClassMapping, which is originally private. Made it public.
			/*
			classMap = (Map)getPrivateValue(EntityList.class, (Object)null, 0);
			*/			
			classMap = EntityList.stringToClassMapping;
			
			// Gain access to TileEntityRenderers.specialRendererMap. Made it public, so no need to fiddle
			/*
			field_TileEntityRenderers = TileEntityRenderer.class.getDeclaredFields()[0];
			field_TileEntityRenderers.setAccessible(true);
			*/
			
			// Gain access to RenderPlayer.armorFilenamePrefix. Made it public, so no need to fiddle
			/*
			field_armorList = RenderPlayer.class.getDeclaredFields()[3];
			field_modifiers.setInt(field_armorList, field_armorList.getModifiers() & -17);
			field_armorList.setAccessible(true);
			*/
			
			// Gain access to RenderEngine.textureList. Not sure why.
			/*
			field_animList = RenderEngine.class.getDeclaredFields()[6];
			field_animList.setAccessible(true);
			*/
			
			/*
			Field[] field15 = BiomeGenBase.class.getDeclaredFields();
			LinkedList mod = new LinkedList();

			for(int e1 = 0; e1 < field15.length; ++e1) {
				Class fieldType = field15[e1].getType();
				if((field15[e1].getModifiers() & 8) != 0 && fieldType.isAssignableFrom(BiomeGenBase.class)) {
					BiomeGenBase biome = (BiomeGenBase)field15[e1].get((Object)null);
					if(!(biome instanceof BiomeGenHell) && !(biome instanceof BiomeGenEnd)) {
						mod.add(biome);
					}
				}
			}

			standardBiomes = (BiomeGenBase[])mod.toArray(new BiomeGenBase[0]);
			*/

			try {
				method_RegisterTileEntity = TileEntity.class.getDeclaredMethod("a", new Class[]{Class.class, String.class});
			} catch (NoSuchMethodException noSuchMethodException8) {
				method_RegisterTileEntity = TileEntity.class.getDeclaredMethod("addMapping", new Class[]{Class.class, String.class});
			}

			method_RegisterTileEntity.setAccessible(true);

			try {
				method_RegisterEntityID = EntityList.class.getDeclaredMethod("a", new Class[]{Class.class, String.class, Integer.TYPE});
			} catch (NoSuchMethodException noSuchMethodException7) {
				method_RegisterEntityID = EntityList.class.getDeclaredMethod("addMapping", new Class[]{Class.class, String.class, Integer.TYPE});
			}

			method_RegisterEntityID.setAccessible(true);
		} catch (SecurityException securityException10) {
			logger.throwing("ModLoader", "init", securityException10);
			throwException(securityException10);
			throw new RuntimeException(securityException10);
		} catch (NoSuchFieldException noSuchFieldException11) {
			logger.throwing("ModLoader", "init", noSuchFieldException11);
			throwException(noSuchFieldException11);
			throw new RuntimeException(noSuchFieldException11);
		} catch (NoSuchMethodException noSuchMethodException12) {
			logger.throwing("ModLoader", "init", noSuchMethodException12);
			throwException(noSuchMethodException12);
			throw new RuntimeException(noSuchMethodException12);
		} catch (IllegalArgumentException illegalArgumentException13) {
			logger.throwing("ModLoader", "init", illegalArgumentException13);
			throwException(illegalArgumentException13);
			throw new RuntimeException(illegalArgumentException13);
		} /*catch (IllegalAccessException illegalAccessException14) {
			logger.throwing("ModLoader", "init", illegalAccessException14);
			throwException(illegalAccessException14);
			throw new RuntimeException(illegalAccessException14);
		}*/

		try {
			loadConfig();
			if(props.containsKey("loggingLevel")) {
				cfgLoggingLevel = Level.parse(props.getProperty("loggingLevel"));
			}

			/*
			if(props.containsKey("grassFix")) {
				RenderBlocks.cfgGrassFix = Boolean.parseBoolean(props.getProperty("grassFix"));
			}
			*/

			logger.setLevel(cfgLoggingLevel);
			if((logfile.exists() || logfile.createNewFile()) && logfile.canWrite() && logHandler == null) {
				logHandler = new FileHandler(logfile.getPath());
				logHandler.setFormatter(new SimpleFormatter());
				logger.addHandler(logHandler);
			}

			logger.fine("ModLoader a1.1.2_01 Initializing...");
			System.out.println("ModLoader a1.1.2_01 Initializing...");
			File file16 = new File(ModLoader.class.getProtectionDomain().getCodeSource().getLocation().toURI());
			modDir.mkdirs();
			readFromClassPath(file16);
			readFromModFolder(modDir);
			sortModList();
			Iterator iterator18 = modList.iterator();

			BaseMod baseMod17;
			while(iterator18.hasNext()) {
				baseMod17 = (BaseMod)iterator18.next();
				baseMod17.load();
				logger.fine("Mod Loaded: \"" + baseMod17.toString() + "\"");
				System.out.println("Mod Loaded: " + baseMod17.toString());
				if(!props.containsKey(baseMod17.getClass().getSimpleName())) {
					props.setProperty(baseMod17.getClass().getSimpleName(), "on");
				}
			}

			iterator18 = modList.iterator();

			while(iterator18.hasNext()) {
				baseMod17 = (BaseMod)iterator18.next();
				baseMod17.modsLoaded();
			}

			System.out.println("Done.");
			props.setProperty("loggingLevel", cfgLoggingLevel.getName());
			/*
			props.setProperty("grassFix", Boolean.toString(RenderBlocks.cfgGrassFix));
			*/
			if(isThisClient()) {
				Minecraft.instance.options.keyBindings = registerAllKeys(Minecraft.instance.options.keyBindings);
				Minecraft.instance.options.loadOptions();
			}
			
			initStats();
			saveConfig();
		} catch (Throwable throwable9) {
			throwable9.printStackTrace();
			logger.throwing("ModLoader", "init", throwable9);
			throwException("ModLoader has failed to initialize.", throwable9);
			if(logHandler != null) {
				logHandler.close();
			}


		}
	}

	public static boolean isThisClient() {
		try {
			Class.forName("net.minecraft.client.Minecraft");
		} catch (Exception e) {
			return false;
		}
		
		return Minecraft.instance != null;
	}

	private static void initStats() {
		/*
		int idHashSet;
		String id;
		for(idHashSet = 0; idHashSet < Block.blocksList.length; ++idHashSet) {
			if(!StatList.oneShotStats.containsKey(16777216 + idHashSet) && Block.blocksList[idHashSet] != null && Block.blocksList[idHashSet].getEnableStats()) {
				id = StatCollector.translateToLocalFormatted("stat.mineBlock", new Object[]{Block.blocksList[idHashSet].translateBlockName()});
				StatList.mineBlockStatArray[idHashSet] = (new StatCrafting(16777216 + idHashSet, id, idHashSet)).registerStat();
				StatList.objectMineStats.add(StatList.mineBlockStatArray[idHashSet]);
			}
		}

		for(idHashSet = 0; idHashSet < Item.itemsList.length; ++idHashSet) {
			if(!StatList.oneShotStats.containsKey(16908288 + idHashSet) && Item.itemsList[idHashSet] != null) {
				id = StatCollector.translateToLocalFormatted("stat.useItem", new Object[]{Item.itemsList[idHashSet].getStatName()});
				StatList.objectUseStats[idHashSet] = (new StatCrafting(16908288 + idHashSet, id, idHashSet)).registerStat();
				if(idHashSet >= Block.blocksList.length) {
					StatList.itemStats.add(StatList.objectUseStats[idHashSet]);
				}
			}

			if(!StatList.oneShotStats.containsKey(16973824 + idHashSet) && Item.itemsList[idHashSet] != null && Item.itemsList[idHashSet].isDamageable()) {
				id = StatCollector.translateToLocalFormatted("stat.breakItem", new Object[]{Item.itemsList[idHashSet].getStatName()});
				StatList.objectBreakStats[idHashSet] = (new StatCrafting(16973824 + idHashSet, id, idHashSet)).registerStat();
			}
		}

		HashSet hashSet4 = new HashSet();
		Iterator iterator2 = CraftingManager.getInstance().getRecipeList().iterator();

		Object object5;
		while(iterator2.hasNext()) {
			object5 = iterator2.next();
			hashSet4.add(((IRecipe)object5).getRecipeOutput().itemID);
		}

		iterator2 = FurnaceRecipes.smelting().getSmeltingList().values().iterator();

		while(iterator2.hasNext()) {
			object5 = iterator2.next();
			hashSet4.add(((ItemStack)object5).itemID);
		}

		iterator2 = hashSet4.iterator();

		while(iterator2.hasNext()) {
			int i6 = ((Integer)iterator2.next()).intValue();
			if(!StatList.oneShotStats.containsKey(16842752 + i6) && Item.itemsList[i6] != null) {
				String str = StatCollector.translateToLocalFormatted("stat.craftItem", new Object[]{Item.itemsList[i6].getStatName()});
				StatList.objectCraftStats[i6] = (new StatCrafting(16842752 + i6, str, i6)).registerStat();
			}
		}
		*/
	}

	public static boolean isGUIOpen(Class gui) {
		Minecraft game = getMinecraftInstance();
		return gui == null ? game.currentScreen == null : (game.currentScreen == null && gui != null ? false : gui.isInstance(game.currentScreen));
	}

	public static boolean isModLoaded(String modname) {
		Iterator iterator2 = modList.iterator();

		while(iterator2.hasNext()) {
			BaseMod mod = (BaseMod)iterator2.next();
			if(modname.contentEquals(mod.getName())) {
				return true;
			}
		}

		return false;
	}

	public static void loadConfig() throws IOException {
		cfgdir.mkdir();
		if(cfgfile.exists() || cfgfile.createNewFile()) {
			if(cfgfile.canRead()) {
				FileInputStream in = new FileInputStream(cfgfile);
				props.load(in);
				in.close();
			}

		}
	}

	public static BufferedImage loadImage(RenderEngine texCache, String path) throws Exception {
		/*
		TexturePackList pack = (TexturePackList)getPrivateValue(RenderEngine.class, texCache, 11);
		InputStream input = pack.selectedTexturePack.getResourceAsStream(path);
		*/
		InputStream input = RenderEngine.class.getResourceAsStream(path);
		if(input == null) {
			throw new Exception("Image not found: " + path);
		} else {
			BufferedImage image = ImageIO.read(input);
			if(image == null) {
				throw new Exception("Image corrupted: " + path);
			} else {
				return image;
			}
		}
	}

	public static void onItemPickup(EntityPlayer player, ItemStack item) {
		Iterator iterator3 = modList.iterator();

		while(iterator3.hasNext()) {
			BaseMod mod = (BaseMod)iterator3.next();
			mod.onItemPickup(player, item);
		}

	}

	public static void onTick(float tick, Minecraft game) {
		if(!hasInit) {
			init();
			logger.fine("Initialized");
		}
		
		/*
		if(texPack == null || game.options.skin != texPack) {
			texturesAdded = false;
			texPack = game.options.skin;
		}

		if(langPack == null || StringTranslate.getInstance().getCurrentLanguage() != langPack) {
			Properties newclock = null;

			try {
				newclock = (Properties)getPrivateValue(StringTranslate.class, StringTranslate.getInstance(), 1);
			} catch (SecurityException securityException12) {
				logger.throwing("ModLoader", "AddLocalization", securityException12);
				throwException(securityException12);
			} catch (NoSuchFieldException noSuchFieldException13) {
				logger.throwing("ModLoader", "AddLocalization", noSuchFieldException13);
				throwException(noSuchFieldException13);
			}

			langPack = StringTranslate.getInstance().getCurrentLanguage();
			if(newclock != null) {
				if(localizedStrings.containsKey("en_US")) {
					newclock.putAll((Map)localizedStrings.get("en_US"));
				}

				if(!langPack.contentEquals("en_US") && localizedStrings.containsKey(langPack)) {
					newclock.putAll((Map)localizedStrings.get(langPack));
				}
			}
		}
		*/

		if(!texturesAdded && game.renderEngine != null) {
			registerAllTextureOverrides(game.renderEngine);
			texturesAdded = true;
		}

		long newclock1 = 0L;
		Iterator modSet;
		Entry modSet1;
		if(game.theWorld != null) {
			newclock1 = game.theWorld.worldTime;
			modSet = inGameHooks.entrySet().iterator();

			label122:
			while(true) {
				do {
					if(!modSet.hasNext()) {
						break label122;
					}

					modSet1 = (Entry)modSet.next();
				} while(clock == newclock1 && ((Boolean)modSet1.getValue()).booleanValue());

				if(!((BaseMod)modSet1.getKey()).onTickInGame(tick, game)) {
					modSet.remove();
				}
			}
		}

		/*
		if(game.standardGalacticFontRenderer != null) {
			modSet = inGUIHooks.entrySet().iterator();

			label109:
			while(true) {
				do {
					if(!modSet.hasNext()) {
						break label109;
					}

					modSet1 = (Entry)modSet.next();
				} while(clock == newclock1 && ((Boolean)modSet1.getValue()).booleanValue() & game.theWorld != null);

				if(!((BaseMod)modSet1.getKey()).onTickInGUI(tick, game, game.currentScreen)) {
					modSet.remove();
				}
			}
		}
		*/

		if(clock != newclock1) {
			Iterator modSet3 = keyList.entrySet().iterator();

			label95:
			while(modSet3.hasNext()) {
				Entry modSet2 = (Entry)modSet3.next();
				Iterator iterator7 = ((Map)modSet2.getValue()).entrySet().iterator();

				while(true) {
					Entry keySet;
					boolean state;
					boolean[] keyInfo;
					boolean oldState;
					do {
						do {
							if(!iterator7.hasNext()) {
								continue label95;
							}

							keySet = (Entry)iterator7.next();
							int key = ((KeyBinding)keySet.getKey()).keyCode;
							if(key < 0) {
								key += 100;
								state = Mouse.isButtonDown(key);
							} else {
								state = Keyboard.isKeyDown(key);
							}

							keyInfo = (boolean[])keySet.getValue();
							oldState = keyInfo[1];
							keyInfo[1] = state;
						} while(!state);
					} while(oldState && !keyInfo[0]);

					((BaseMod)modSet2.getKey()).keyboardEvent((KeyBinding)keySet.getKey());
				}
			}
		}

		clock = newclock1;
	}

	public static void openGUI(EntityPlayer player, GuiScreen gui) {
		if(!hasInit) {
			init();
			logger.fine("Initialized");
		}

		Minecraft game = getMinecraftInstance();

		if(gui != null) {
			game.displayGuiScreen(gui);
		}

	}

	public static void populateChunk(IChunkProvider generator, int chunkX, int chunkZ, World world) {
		if(!hasInit) {
			init();
			logger.fine("Initialized");
		}

		Random rnd = new Random(world.randomSeed);
		long xSeed = rnd.nextLong() / 2L * 2L + 1L;
		long zSeed = rnd.nextLong() / 2L * 2L + 1L;
		rnd.setSeed((long)chunkX * xSeed + (long)chunkZ * zSeed ^ world.randomSeed);
		Iterator iterator10 = modList.iterator();

		while(iterator10.hasNext()) {
			BaseMod mod = (BaseMod)iterator10.next();
			mod.generateSurface(world, rnd, chunkX << 4, chunkZ << 4);
		}

	}

	private static void readFromClassPath(File source) throws FileNotFoundException, IOException {
		logger.finer("Adding mods from " + source.getCanonicalPath());
		ClassLoader loader = ModLoader.class.getClassLoader();
		String name;
		if(!source.isFile() || !source.getName().endsWith(".jar") && !source.getName().endsWith(".zip")) {
			if(source.isDirectory()) {
				Package package6 = ModLoader.class.getPackage();
				if(package6 != null) {
					String string7 = package6.getName().replace('.', File.separatorChar);
					source = new File(source, string7);
				}

				logger.finer("Directory found.");
				File[] file8 = source.listFiles();
				if(file8 != null) {
					for(int i9 = 0; i9 < file8.length; ++i9) {
						name = file8[i9].getName();
						if(file8[i9].isFile() && name.startsWith("mod_") && name.endsWith(".class")) {
							addMod(loader, name);
						}
					}
				}
			}
		} else {
			logger.finer("Zip found.");
			FileInputStream pkg = new FileInputStream(source);
			ZipInputStream files = new ZipInputStream(pkg);
			ZipEntry i = null;

			while(true) {
				i = files.getNextEntry();
				if(i == null) {
					pkg.close();
					break;
				}

				name = i.getName();
				if(!i.isDirectory() && name.startsWith("mod_") && name.endsWith(".class")) {
					addMod(loader, name);
				}
			}
		}

	}

	private static void readFromModFolder(File folder) throws IOException, IllegalArgumentException, IllegalAccessException, InvocationTargetException, SecurityException, NoSuchMethodException {
		ClassLoader loader = Minecraft.class.getClassLoader();
		Method addURL = URLClassLoader.class.getDeclaredMethod("addURL", new Class[]{URL.class});
		addURL.setAccessible(true);
		if(!folder.isDirectory()) {
			throw new IllegalArgumentException("folder must be a Directory.");
		} else {
			File[] sourcefiles = folder.listFiles();
			Arrays.sort(sourcefiles);
			int file;
			File source;
			if(loader instanceof URLClassLoader) {
				for(file = 0; file < sourcefiles.length; ++file) {
					source = sourcefiles[file];
					if(source.isDirectory() || source.isFile() && (source.getName().endsWith(".jar") || source.getName().endsWith(".zip"))) {
						addURL.invoke(loader, new Object[]{source.toURI().toURL()});
					}
				}
			}

			for(file = 0; file < sourcefiles.length; ++file) {
				source = sourcefiles[file];
				if(source.isDirectory() || source.isFile() && (source.getName().endsWith(".jar") || source.getName().endsWith(".zip"))) {
					logger.finer("Adding mods from " + source.getCanonicalPath());
					String name;
					if(!source.isFile()) {
						if(source.isDirectory()) {
							Package package10 = ModLoader.class.getPackage();
							if(package10 != null) {
								String string11 = package10.getName().replace('.', File.separatorChar);
								source = new File(source, string11);
							}

							logger.finer("Directory found.");
							File[] file12 = source.listFiles();
							if(file12 != null) {
								for(int i13 = 0; i13 < file12.length; ++i13) {
									name = file12[i13].getName();
									if(file12[i13].isFile() && name.startsWith("mod_") && name.endsWith(".class")) {
										addMod(loader, name);
									}
								}
							}
						}
					} else {
						logger.finer("Zip found.");
						FileInputStream pkg = new FileInputStream(source);
						ZipInputStream dirfiles = new ZipInputStream(pkg);
						ZipEntry j = null;

						while(true) {
							j = dirfiles.getNextEntry();
							if(j == null) {
								dirfiles.close();
								pkg.close();
								break;
							}

							name = j.getName();
							if(!j.isDirectory() && name.startsWith("mod_") && name.endsWith(".class")) {
								addMod(loader, name);
							}
						}
					}
				}
			}

		}
	}

	public static void receivePacket(Packet250CustomPayload packet) {
		if(packetChannels.containsKey(packet.channel)) {
			BaseMod mod = (BaseMod)packetChannels.get(packet.channel);
			if(mod != null) {
				mod.receiveCustomPacket(packet);
			}
		}

	}

	public static KeyBinding[] registerAllKeys(KeyBinding[] keys) {
		LinkedList combinedList = new LinkedList();
		combinedList.addAll(Arrays.asList(keys));
		Iterator iterator3 = keyList.values().iterator();

		while(iterator3.hasNext()) {
			Map keyMap = (Map)iterator3.next();
			combinedList.addAll(keyMap.keySet());
		}

		return (KeyBinding[])combinedList.toArray(new KeyBinding[0]);
	}

	public static void registerAllTextureOverrides(RenderEngine cache) {
		animList.clear();
		Minecraft game = getMinecraftInstance();
		Iterator iterator3 = modList.iterator();

		while(iterator3.hasNext()) {
			BaseMod overlay = (BaseMod)iterator3.next();
			overlay.registerAnimation(game);
		}

		iterator3 = animList.iterator();

		while(iterator3.hasNext()) {
			TextureFX overlay1 = (TextureFX)iterator3.next();
			cache.registerTextureFX(overlay1);
		}

		iterator3 = overrides.entrySet().iterator();

		while(iterator3.hasNext()) {
			Entry overlay2 = (Entry)iterator3.next();
			Iterator iterator5 = ((Map)overlay2.getValue()).entrySet().iterator();

			while(iterator5.hasNext()) {
				Entry overlayEntry = (Entry)iterator5.next();
				String overlayPath = (String)overlayEntry.getKey();
				int index = ((Integer)overlayEntry.getValue()).intValue();
				int dst = ((Integer)overlay2.getKey()).intValue();

				try {
					BufferedImage e = loadImage(cache, overlayPath);
					ModTextureStatic anim = new ModTextureStatic(index, dst, e);
					cache.registerTextureFX(anim);
				} catch (Exception exception11) {
					logger.throwing("ModLoader", "RegisterAllTextureOverrides", exception11);
					throwException(exception11);
					throw new RuntimeException(exception11);
				}
			}
		}

	}

	public static void registerBlock(Block block) {
		registerBlock(block, (Class)null);
	}

	public static void registerBlock(Block block, Class itemclass) {
		try {
			if(block == null) {
				throw new IllegalArgumentException("block parameter cannot be null.");
			}

			int e = block.blockID;
			ItemBlock item = null;
			if(itemclass != null) {
				item = (ItemBlock)itemclass.getConstructor(new Class[]{Integer.TYPE}).newInstance(new Object[]{e - 256});
			} else {
				item = new ItemBlock(e - 256);
			}

			if(Block.blocksList[e] != null && Item.itemsList[e] == null) {
				Item.itemsList[e] = item;
			}
		} catch (IllegalArgumentException illegalArgumentException4) {
			logger.throwing("ModLoader", "RegisterBlock", illegalArgumentException4);
			throwException(illegalArgumentException4);
		} catch (IllegalAccessException illegalAccessException5) {
			logger.throwing("ModLoader", "RegisterBlock", illegalAccessException5);
			throwException(illegalAccessException5);
		} catch (SecurityException securityException6) {
			logger.throwing("ModLoader", "RegisterBlock", securityException6);
			throwException(securityException6);
		} catch (InstantiationException instantiationException7) {
			logger.throwing("ModLoader", "RegisterBlock", instantiationException7);
			throwException(instantiationException7);
		} catch (InvocationTargetException invocationTargetException8) {
			logger.throwing("ModLoader", "RegisterBlock", invocationTargetException8);
			throwException(invocationTargetException8);
		} catch (NoSuchMethodException noSuchMethodException9) {
			logger.throwing("ModLoader", "RegisterBlock", noSuchMethodException9);
			throwException(noSuchMethodException9);
		}

	}

	public static void registerEntityID(Class entityClass, String entityName, int id) {
		try {
			method_RegisterEntityID.invoke((Object)null, new Object[]{entityClass, entityName, id});
		} catch (IllegalArgumentException illegalArgumentException4) {
			logger.throwing("ModLoader", "RegisterEntityID", illegalArgumentException4);
			throwException(illegalArgumentException4);
		} catch (IllegalAccessException illegalAccessException5) {
			logger.throwing("ModLoader", "RegisterEntityID", illegalAccessException5);
			throwException(illegalAccessException5);
		} catch (InvocationTargetException invocationTargetException6) {
			logger.throwing("ModLoader", "RegisterEntityID", invocationTargetException6);
			throwException(invocationTargetException6);
		}

	}

	public static void registerEntityID(Class entityClass, String entityName, int id, int background, int foreground) {
		registerEntityID(entityClass, entityName, id);
		//EntityList.entityEggs.put(id, new EntityEggInfo(id, background, foreground));
	}

	public static void registerKey(BaseMod mod, KeyBinding keyHandler, boolean allowRepeat) {
		Object keyMap = (Map)keyList.get(mod);
		if(keyMap == null) {
			keyMap = new HashMap();
		}

		((Map)keyMap).put(keyHandler, new boolean[]{allowRepeat, false});
		keyList.put(mod, keyMap);
	}

	public static void registerPacketChannel(BaseMod mod, String channel) {
		if(channel.length() < 16) {
			packetChannels.put(channel, mod);
		} else {
			throw new RuntimeException(String.format("Invalid channel name: %s. Must be less than 16 characters.", new Object[]{channel}));
		}
	}

	public static void registerTileEntity(Class tileEntityClass, String id) {
		registerTileEntity(tileEntityClass, id, (TileEntitySpecialRenderer)null);
	}

	public static void registerTileEntity(Class tileEntityClass, String id, TileEntitySpecialRenderer renderer) {
		try {
			method_RegisterTileEntity.invoke((Object)null, new Object[]{tileEntityClass, id});
			if(renderer != null) {
				// Made the field public.
				
				/*
				TileEntityRenderer e = TileEntityRenderer.instance;
				Map renderers = (Map)field_TileEntityRenderers.get(e);
				renderers.put(tileEntityClass, renderer);
				renderer.setTileEntityRenderer(e);
				*/
				
				TileEntityRenderer e = TileEntityRenderer.instance;
				e.specialRendererMap.put(tileEntityClass, renderer);
				renderer.setTileEntityRenderer(e);
			}
		} catch (IllegalArgumentException illegalArgumentException5) {
			logger.throwing("ModLoader", "RegisterTileEntity", illegalArgumentException5);
			throwException(illegalArgumentException5);
		} catch (IllegalAccessException illegalAccessException6) {
			logger.throwing("ModLoader", "RegisterTileEntity", illegalAccessException6);
			throwException(illegalAccessException6);
		} catch (InvocationTargetException invocationTargetException7) {
			logger.throwing("ModLoader", "RegisterTileEntity", invocationTargetException7);
			throwException(invocationTargetException7);
		}

	}

	/*
	public static void removeBiome(BiomeGenBase biome) {
		BiomeGenBase[] existingBiomes = GenLayerBiome.biomeArray;
		List existingBiomeList = Arrays.asList(existingBiomes);
		ArrayList combinedList = new ArrayList();
		combinedList.addAll(existingBiomeList);
		if(combinedList.contains(biome)) {
			combinedList.remove(biome);
		}

		GenLayerBiome.biomeArray = (BiomeGenBase[])combinedList.toArray(new BiomeGenBase[0]);
	}
	*/

	public static void removeSpawn(Class entityClass, EnumCreatureType spawnList) {
		if(entityClass == null) {
			throw new IllegalArgumentException("entityClass cannot be null");
		} else if(spawnList == null) {
			throw new IllegalArgumentException("spawnList cannot be null");
		} else {
			
			// Custom code. We'll store the new spanw list entry in the right list.
			if(spawnList == EnumCreatureType.creature) {
				SpawnLists.spawnableAnimals.remove(entityClass);
			} else {
				SpawnLists.spawnableMobs.remove(entityClass);
			}
		}
	}

	public static void removeSpawn(String entityName, EnumCreatureType spawnList)  {
		Class entityClass = (Class)classMap.get(entityName);
		if(entityClass != null && EntityLiving.class.isAssignableFrom(entityClass)) {
			removeSpawn(entityClass, spawnList);
		}

	}

	public static boolean renderBlockIsItemFull3D(int modelID) {
		return !blockSpecialInv.containsKey(modelID) ? modelID == 16 : ((Boolean)blockSpecialInv.get(modelID)).booleanValue();
	}

	public static void renderInvBlock(RenderBlocks renderer, Block block, int metadata, int modelID) {
		BaseMod mod = (BaseMod)blockModels.get(modelID);
		if(mod != null) {
			mod.renderInvBlock(renderer, block, metadata, modelID);
		}
	}

	public static boolean renderWorldBlock(RenderBlocks renderer, IBlockAccess world, int x, int y, int z, Block block, int modelID) {
		BaseMod mod = (BaseMod)blockModels.get(modelID);
		return mod == null ? false : mod.renderWorldBlock(renderer, world, x, y, z, block, modelID);
	}

	public static void saveConfig() throws IOException {
		cfgdir.mkdir();
		if(cfgfile.exists() || cfgfile.createNewFile()) {
			if(cfgfile.canWrite()) {
				FileOutputStream out = new FileOutputStream(cfgfile);
				props.store(out, "ModLoader Config");
				out.close();
			}

		}
	}

	public static void serverChat(String text) {
		Iterator iterator2 = modList.iterator();

		while(iterator2.hasNext()) {
			BaseMod mod = (BaseMod)iterator2.next();
			mod.receiveChatPacket(text);
		}

	}
	
	public static void serverChat(String s, EntityPlayerMP entityplayermp) {
		Iterator iterator = modList.iterator();

		while(iterator.hasNext()) {
			BaseMod basemod = (BaseMod)iterator.next();
			basemod.receiveChatPacket(s, entityplayermp);
		}

	}

	public static void serverConnect(NetClientHandler handler, Packet1Login loginPacket) {
		netHandler = handler;
		if(packetChannels.size() > 0) {
			Packet250CustomPayload mod = new Packet250CustomPayload();
			mod.channel = "REGISTER";
			StringBuilder channels = new StringBuilder();
			Iterator iter = packetChannels.keySet().iterator();
			channels.append((String)iter.next());

			while(iter.hasNext()) {
				channels.append("\u0000");
				channels.append((String)iter.next());
			}

			mod.data = channels.toString().getBytes(Charset.forName("UTF8"));
			mod.length = mod.data.length;
			sendPacket(mod);
		}

		Iterator channels1 = modList.iterator();

		while(channels1.hasNext()) {
			BaseMod mod1 = (BaseMod)channels1.next();
			mod1.serverConnect(netHandler);
		}

	}

	public static void serverDisconnect() {
		Iterator iterator1 = modList.iterator();

		while(iterator1.hasNext()) {
			BaseMod mod = (BaseMod)iterator1.next();
			mod.serverDisconnect();
		}

		netHandler = null;
	}
	
	public static void serverDisconnect(EntityPlayerMP entityplayermp) {
		Iterator iterator = modList.iterator();

		while(iterator.hasNext()) {
			BaseMod basemod = (BaseMod)iterator.next();
			basemod.serverDisconnect(entityplayermp);
		}

	}

	public static void sendPacket(Packet packet) {
		if(netHandler != null) {
			netHandler.addToSendQueue(packet);
		}

	}

	public static void setInGameHook(BaseMod mod, boolean enable, boolean useClock) {
		if(enable) {
			inGameHooks.put(mod, useClock);
		} else {
			inGameHooks.remove(mod);
		}

	}

	public static void setInGUIHook(BaseMod mod, boolean enable, boolean useClock) {
		if(enable) {
			inGUIHooks.put(mod, useClock);
		} else {
			inGUIHooks.remove(mod);
		}

	}

	public static void setPrivateValue(Class instanceclass, Object instance, int fieldindex, Object value) throws IllegalArgumentException, SecurityException, NoSuchFieldException {
		try {
			Field e = instanceclass.getDeclaredFields()[fieldindex];
			e.setAccessible(true);
			int modifiers = field_modifiers.getInt(e);
			if((modifiers & 16) != 0) {
				field_modifiers.setInt(e, modifiers & -17);
			}

			e.set(instance, value);
		} catch (IllegalAccessException illegalAccessException6) {
			logger.throwing("ModLoader", "setPrivateValue", illegalAccessException6);
			throwException("An impossible error has occured!", illegalAccessException6);
		}

	}

	public static void setPrivateValue(Class instanceclass, Object instance, String field, Object value) throws IllegalArgumentException, SecurityException, NoSuchFieldException {
		try {
			Field e = instanceclass.getDeclaredField(field);
			int modifiers = field_modifiers.getInt(e);
			if((modifiers & 16) != 0) {
				field_modifiers.setInt(e, modifiers & -17);
			}

			e.setAccessible(true);
			e.set(instance, value);
		} catch (IllegalAccessException illegalAccessException6) {
			logger.throwing("ModLoader", "setPrivateValue", illegalAccessException6);
			throwException("An impossible error has occured!", illegalAccessException6);
		}

	}

	@SuppressWarnings("resource")
	private static void setupProperties(Class mod) throws IllegalArgumentException, IllegalAccessException, IOException, SecurityException, NoSuchFieldException, NoSuchAlgorithmException, DigestException {
		LinkedList fieldList = new LinkedList();
		Properties modprops = new Properties();
		int currentHash = 0;
		int cfgHash = 0;
		File modcfgfile = new File(cfgdir, mod.getSimpleName() + ".cfg");
		if(modcfgfile.exists() && modcfgfile.canRead()) {
			modprops.load(new FileInputStream(modcfgfile));
		}

		if(modprops.containsKey("checksum")) {
			cfgHash = Integer.parseInt(modprops.getProperty("checksum"), 36);
		}

		Field[] type;
		int i8 = (type = mod.getDeclaredFields()).length;

		for(int field = 0; field < i8; ++field) {
			Field helptext = type[field];
			if((helptext.getModifiers() & 8) != 0 && helptext.isAnnotationPresent(MLProp.class)) {
				fieldList.add(helptext);
				Object annotation = helptext.get((Object)null);
				currentHash += annotation.hashCode();
			}
		}

		StringBuilder stringBuilder19 = new StringBuilder();
		Iterator iterator21 = fieldList.iterator();

		while(true) {
			String key;
			Object currentvalue;
			Object value;
			double num;
			Field field20;
			MLProp mLProp23;
			do {
				do {
					while(true) {
						do {
							do {
								if(!iterator21.hasNext()) {
									modprops.put("checksum", Integer.toString(currentHash, 36));
									if(!modprops.isEmpty() && (modcfgfile.exists() || modcfgfile.createNewFile()) && modcfgfile.canWrite()) {
										modprops.store(new FileOutputStream(modcfgfile), stringBuilder19.toString());
									}

									return;
								}

								field20 = (Field)iterator21.next();
							} while((field20.getModifiers() & 8) == 0);
						} while(!field20.isAnnotationPresent(MLProp.class));

						Class class22 = field20.getType();
						mLProp23 = (MLProp)field20.getAnnotation(MLProp.class);
						key = mLProp23.name().length() == 0 ? field20.getName() : mLProp23.name();
						currentvalue = field20.get((Object)null);
						StringBuilder range = new StringBuilder();
						if(mLProp23.min() != Double.NEGATIVE_INFINITY) {
							range.append(String.format(",>=%.1f", new Object[]{mLProp23.min()}));
						}

						if(mLProp23.max() != Double.POSITIVE_INFINITY) {
							range.append(String.format(",<=%.1f", new Object[]{mLProp23.max()}));
						}

						StringBuilder info = new StringBuilder();
						if(mLProp23.info().length() > 0) {
							info.append(" -- ");
							info.append(mLProp23.info());
						}

						stringBuilder19.append(String.format("%s (%s:%s%s)%s\n", new Object[]{key, class22.getName(), currentvalue, range, info}));
						if(cfgHash == currentHash && modprops.containsKey(key)) {
							String strvalue = modprops.getProperty(key);
							value = null;
							if(class22.isAssignableFrom(String.class)) {
								value = strvalue;
							} else if(class22.isAssignableFrom(Integer.TYPE)) {
								value = Integer.parseInt(strvalue);
							} else if(class22.isAssignableFrom(Short.TYPE)) {
								value = Short.parseShort(strvalue);
							} else if(class22.isAssignableFrom(Byte.TYPE)) {
								value = Byte.parseByte(strvalue);
							} else if(class22.isAssignableFrom(Boolean.TYPE)) {
								value = Boolean.parseBoolean(strvalue);
							} else if(class22.isAssignableFrom(Float.TYPE)) {
								value = Float.parseFloat(strvalue);
							} else if(class22.isAssignableFrom(Double.TYPE)) {
								value = Double.parseDouble(strvalue);
							}
							break;
						}

						logger.finer(key + " not in config, using default: " + currentvalue);
						modprops.setProperty(key, currentvalue.toString());
					}
				} while(value == null);

				if(!(value instanceof Number)) {
					break;
				}

				num = ((Number)value).doubleValue();
			} while(mLProp23.min() != Double.NEGATIVE_INFINITY && num < mLProp23.min() || mLProp23.max() != Double.POSITIVE_INFINITY && num > mLProp23.max());

			logger.finer(key + " set to " + value);
			if(!value.equals(currentvalue)) {
				field20.set((Object)null, value);
			}
		}
	}

	private static void sortModList() throws Exception {
		HashMap loadedMods = new HashMap();
		Iterator pass = getLoadedMods().iterator();

		while(pass.hasNext()) {
			BaseMod newList = (BaseMod)pass.next();
			loadedMods.put(newList.getClass().getSimpleName(), newList);
		}

		LinkedList linkedList17 = new LinkedList();
		int i18 = 0;

		label127:
		while(linkedList17.size() != modList.size() && i18 <= 10) {
			Iterator iterator4 = modList.iterator();

			while(true) {
				BaseMod mod;
				int newIndex;
				label123:
				while(true) {
					String priority;
					do {
						while(true) {
							do {
								if(!iterator4.hasNext()) {
									++i18;
									continue label127;
								}

								mod = (BaseMod)iterator4.next();
							} while(linkedList17.contains(mod));

							priority = mod.getPriorities();
							if(priority != null && priority.length() != 0 && priority.indexOf(58) != -1) {
								break;
							}

							linkedList17.add(mod);
						}
					} while(i18 <= 0);

					newIndex = -1;
					int max = Integer.MIN_VALUE;
					int min = Integer.MAX_VALUE;
					String[] rules;
					if(priority.indexOf(59) > 0) {
						rules = priority.split(";");
					} else {
						rules = new String[]{priority};
					}

					int i = 0;

					while(true) {
						if(i >= rules.length) {
							break label123;
						}

						String rule = rules[i];
						if(rule.indexOf(58) != -1) {
							String[] keyValuePair = rule.split(":");
							String key = keyValuePair[0];
							String value = keyValuePair[1];
							if(key.contentEquals("required-before") || key.contentEquals("before") || key.contentEquals("after") || key.contentEquals("required-after")) {
								if(value.contentEquals("*")) {
									if(!key.contentEquals("required-before") && !key.contentEquals("before")) {
										if(key.contentEquals("required-after") || key.contentEquals("after")) {
											newIndex = linkedList17.size();
										}
										break label123;
									}

									newIndex = 0;
									break label123;
								}

								if((key.contentEquals("required-before") || key.contentEquals("required-after")) && !loadedMods.containsKey(value)) {
									throw new Exception(String.format("%s is missing dependency: %s", new Object[]{mod, value}));
								}

								BaseMod mod2 = (BaseMod)loadedMods.get(value);
								if(!linkedList17.contains(mod2)) {
									break;
								}

								int index = linkedList17.indexOf(mod2);
								if(!key.contentEquals("required-before") && !key.contentEquals("before")) {
									if(key.contentEquals("required-after") || key.contentEquals("after")) {
										newIndex = index + 1;
										if(newIndex > max) {
											max = newIndex;
										} else {
											newIndex = max;
										}
									}
								} else {
									newIndex = index;
									if(index < min) {
										min = index;
									} else {
										newIndex = min;
									}
								}
							}
						}

						++i;
					}
				}

				if(newIndex != -1) {
					linkedList17.add(newIndex, mod);
				}
			}
		}

		modList.clear();
		modList.addAll(linkedList17);
	}

	public static void takenFromCrafting(EntityPlayer player, ItemStack item, IInventory matrix) {
		Iterator iterator4 = modList.iterator();

		while(iterator4.hasNext()) {
			BaseMod mod = (BaseMod)iterator4.next();
			mod.takenFromCrafting(player, item, matrix);
		}

	}

	public static void takenFromFurnace(EntityPlayer player, ItemStack item) {
		Iterator iterator3 = modList.iterator();

		while(iterator3.hasNext()) {
			BaseMod mod = (BaseMod)iterator3.next();
			mod.takenFromFurnace(player, item);
		}

	}

	public static void throwException(String message, Throwable e) {
		Minecraft game = getMinecraftInstance();
		if(game != null) {
			game.displayUnexpectedThrowable(new UnexpectedThrowable(message, e));
		} else {
			throw new RuntimeException(e);
		}
	}

	private static void throwException(Throwable e) {
		throwException("Exception occured in ModLoader", e);
	}
	
	public static void initialize(MinecraftServer minecraftserver) {
		serverInstance = minecraftserver;
/*
		try {
			String nosuchmethodexception1 = ModLoader.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
			nosuchmethodexception1 = nosuchmethodexception1.substring(0, nosuchmethodexception1.lastIndexOf(47));
			cfgdir = new File(nosuchmethodexception1, "/config/");
			cfgfile = new File(nosuchmethodexception1, "/config/ModLoader.cfg");
			logfile = new File(nosuchmethodexception1, "ModLoader.txt");
			modDir = new File(nosuchmethodexception1, "/mods/");
		} catch (URISyntaxException uRISyntaxException6) {
			getLogger().throwing("ModLoader", "Init", uRISyntaxException6);
			throwException("ModLoader", uRISyntaxException6);
			return;
		}
*/
		init();
	}
}
