package net.minecraft.src;

public class GuiMultiplayer extends GuiScreen {
	private GuiScreen parentScreen;
	private int updateCounter = 0;
	private GuiTextField address;

	public GuiMultiplayer(GuiScreen var1) {
		this.parentScreen = var1;
	}

	public void updateScreen() {
		this.setUpdateCounter(this.getUpdateCounter() + 1);
	}

	public void initGui() {
		this.controlList.clear();
		this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 96 + 12, "Connect"));
		this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 120 + 12, "Cancel"));
		String s = this.mc.options.lastServerAddress.replaceAll("_", ":");
		((GuiButton)this.controlList.get(0)).enabled = s.length() > 0;
		this.address = new GuiTextField(this, this.fontRenderer, this.width / 2 - 100, this.height / 4 - 10 + 50 + 18, 200, 20, s);
		this.address.isFocused = true;
		this.address.setMaxStringLength(128);
		
	}

	protected void actionPerformed(GuiButton var1) {
		if(var1.enabled) {
			if(var1.id == 1) {
				this.mc.displayGuiScreen(this.parentScreen);
			} else if(var1.id == 0) {
				String s = this.address.getText().trim();
				this.mc.options.lastServerAddress = s.replaceAll(":", "_");
				this.mc.options.saveOptions();
				String[] var2 = s.split(":");
				this.mc.displayGuiScreen(new GuiConnecting(this.mc, var2[0], var2.length > 1 ? Integer.parseInt(var2[1]) : 25565));
			}

		}
	}

	protected void keyTyped(char var1, int var2) {
		this.address.textboxKeyTyped(var1, var2);

		if(var1 == 13) {
			this.actionPerformed((GuiButton)this.controlList.get(0));
		}

		((GuiButton)this.controlList.get(0)).enabled = this.address.getText().length() > 0;
	}

	public void drawScreen(int var1, int var2, float var3) {
		this.drawDefaultBackground();
		this.drawCenteredString(this.fontRenderer, "Play Multiplayer", this.width / 2, this.height / 4 - 60 + 20, 16777215);
		this.drawString(this.fontRenderer, "Minecraft Multiplayer is currently not finished, but there", this.width / 2 - 140, this.height / 4 - 60 + 60 + 0, 10526880);
		this.drawString(this.fontRenderer, "is some buggy early testing going on.", this.width / 2 - 140, this.height / 4 - 60 + 60 + 9, 10526880);
		this.drawString(this.fontRenderer, "Enter the IP of a server to connect to it:", this.width / 2 - 140, this.height / 4 - 60 + 60 + 36, 10526880);
		this.address.drawTextBox();
		super.drawScreen(var1, var2, var3);
	}

	public int getUpdateCounter() {
		return updateCounter;
	}

	public void setUpdateCounter(int updateCounter) {
		this.updateCounter = updateCounter;
	}
}
