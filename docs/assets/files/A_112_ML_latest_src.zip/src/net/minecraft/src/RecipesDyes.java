package net.minecraft.src;

public class RecipesDyes {
	public void addRecipes(CraftingManager craftingManager1) {
		for(int i2 = 0; i2 < 16; ++i2) {
			craftingManager1.addShapelessRecipe(new ItemStack(Block.cloth, 1, BlockCloth.getDyeFromBlock(i2)), new Object[]{new ItemStack(Item.dyePowder, 1, i2), new ItemStack(Item.itemsList[Block.cloth.blockID], 1, 0)});
		}

		// Black :: 0 from coal (NEW)
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 0), new Object[]{Item.coal});
		
		// Red :: 1 from red rose
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 1), new Object[]{Block.plantRed});
		
		// Dark green :: 2 from cactus (NEW)
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 4, 2), new Object[]{Block.cactus});
		
		// Brown :: 3 red + dark green (NEW)
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 3), new Object[]{new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 2)});
		
		// Blue :: 4 lapis (TODO)
		//craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 4, 4), new Object[]{});
		
		// Purple :: 5
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 5), new Object[]{new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.dyePowder, 1, 1)});
		
		// Cyan :: 6
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 6), new Object[]{new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.dyePowder, 1, 2)});
		
		// Light grey :: 7
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 7), new Object[]{new ItemStack(Item.dyePowder, 1, 8), new ItemStack(Item.dyePowder, 1, 15)});
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 3, 7), new Object[]{new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.dyePowder, 1, 15), new ItemStack(Item.dyePowder, 1, 15)});
		
		// Dark grey :: 8
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 8), new Object[]{new ItemStack(Item.dyePowder, 1, 0), new ItemStack(Item.dyePowder, 1, 15)});
		
		// Pink :: 9
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 9), new Object[]{new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 15)});
		
		// Light green: 10
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 10), new Object[]{new ItemStack(Item.dyePowder, 1, 2), new ItemStack(Item.dyePowder, 1, 15)});
		
		// Yellow: 11
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 11), new Object[]{Block.plantYellow});
		
		// Light Blue: 12
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 12), new Object[]{new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.dyePowder, 1, 15)});
		
		// Magenta: 13
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 13), new Object[]{new ItemStack(Item.dyePowder, 1, 5), new ItemStack(Item.dyePowder, 1, 9)});
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 3, 13), new Object[]{new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 9)});
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 4, 13), new Object[]{new ItemStack(Item.dyePowder, 1, 4), new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 15)});
		
		// Orange: 14
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 2, 14), new Object[]{new ItemStack(Item.dyePowder, 1, 1), new ItemStack(Item.dyePowder, 1, 11)});
		
		// White == Bone meal: 15
		craftingManager1.addShapelessRecipe(new ItemStack(Item.dyePowder, 3, 15), new Object[]{Item.bone});
		
	}
}
