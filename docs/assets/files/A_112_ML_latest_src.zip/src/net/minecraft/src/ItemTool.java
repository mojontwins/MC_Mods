package net.minecraft.src;

public class ItemTool extends Item {
	private BlockState[] blocksEffectiveAgainst;
	private float efficiencyOnProperMaterial = 4.0F;
	private int damageVsEntity;
	protected int toolMaterial;

	public ItemTool(int var1, int var2, int var3, BlockState[] var4) {
		super(var1);
		this.toolMaterial = var3;
		this.blocksEffectiveAgainst = var4;
		this.maxStackSize = 1;
		this.maxDamage = 32 << var3;
		if(var3 == 3) {
			this.maxDamage *= 4;
		}

		this.efficiencyOnProperMaterial = (float)((var3 + 1) * 2);
		this.damageVsEntity = var2 + var3;
	}

	@Override
	public float getStrVsBlock(ItemStack stack, Block block, int meta) {
		for(int i = 0; i < this.blocksEffectiveAgainst.length; ++i) {
			if(this.blocksEffectiveAgainst[i].block == block && (this.blocksEffectiveAgainst[i].meta == -1 || meta == this.blocksEffectiveAgainst[i].meta)) {
				return this.efficiencyOnProperMaterial;
			}
		}

		return 1.0F;
	}

	public void hitEntity(ItemStack var1, EntityLiving var2) {
		var1.damageItem(2);
	}

	public void onBlockDestroyed(ItemStack var1, int var2, int var3, int var4, int var5) {
		var1.damageItem(1);
	}

	public int getDamageVsEntity(Entity var1) {
		return this.damageVsEntity;
	}

	public boolean isFull3D() {
		return true;
	}
}
