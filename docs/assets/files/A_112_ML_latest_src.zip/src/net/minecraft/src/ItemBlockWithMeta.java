package net.minecraft.src;

public class ItemBlockWithMeta extends ItemBlock {
	Block baseBlock;
	
	public ItemBlockWithMeta(int id) {
		super(id);
		this.baseBlock = Block.blocksList[id + 256];
		this.maxDamage = 0;
		this.hasSubtypes = true;
	}

	@Override
	public int getPlacedBlockMetadata(int damage) {
		return damage;
	}
	
	@Override
	public int getIconFromDamage(int damage) {
		return this.baseBlock.getBlockTextureFromSideAndMetadata(2, damage);
	}
		
}
