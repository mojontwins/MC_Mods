package net.minecraft.src;

import java.util.Random;

public class GuiCreateWorld extends GuiScreen {
	private GuiScreen parentGuiScreen;
    private GuiTextField textboxSeed;
    private int slot; 
    
    protected String screenTitle = "Create new world";
	private boolean selected = false;
	
	public GuiCreateWorld(GuiSelectWorld guiSelectWorld, int slot) {
    	this.parentGuiScreen = guiSelectWorld;
    	this.slot = slot;
	}

    public void initGui() {
    	this.controlList.clear();
    	
        textboxSeed = new GuiTextField(this, this.fontRenderer, width / 2 -104, 90, 208, 20, "");
        textboxSeed.isFocused = true;
        
        this.controlList.add(new GuiButton(100, this.width / 2 - 104, 120, 208, 20, this.mc.options.getOptionDisplayString(100)));
        
        this.controlList.add(new GuiButton(0, this.width / 2 - 104, 198, 102, 20, "Create"));
        this.controlList.add(new GuiButton(1, this.width / 2 + 2, 198, 102, 20, "Cancel"));
    }
    
	protected void keyTyped(char var1, int var2) {
		this.textboxSeed.textboxKeyTyped(var1, var2);
		
		if(var1 == 13) {
			this.actionPerformed((GuiButton)this.controlList.get(0));
		}
	}
	
	protected void actionPerformed(GuiButton var1) {
		if(var1.enabled) {
			switch (var1.id) {
				case 0:
					if (this.selected == false) {
						this.mc.displayGuiScreen((GuiScreen)null);
						this.selected = true;
						
						long actualSeed = (new Random ()).nextLong ();
						String seed = this.textboxSeed.getText();
						if (seed != null && !"".equals(seed)) {
							try {
								long aux = Long.parseLong(seed);
								if (aux != 0) actualSeed = aux;
							} catch (Exception e) {
								actualSeed = (long)seed.hashCode();
							}
						}
						
						this.mc.playerController = new PlayerControllerSP(this.mc);
						this.mc.startWorld("World" + this.slot, actualSeed, this.mc.options.snowCovered);
						this.mc.displayGuiScreen((GuiScreen)null);
					}
					break;
				case 1:
					this.mc.displayGuiScreen(this.parentGuiScreen);
					break;
				case 100:
					this.mc.options.snowCovered = !this.mc.options.snowCovered;
					var1.displayString = this.mc.options.getOptionDisplayString(100);
					break;
			}
		}
	}
	
    
	public void drawScreen(int i, int j, float f) {
		this.drawDefaultBackground();
		this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 20, 16777215);
		this.drawCenteredString(this.fontRenderer, "Enter a seed for your world.", this.width/2, 50, 0xEEEEEE);
		this.drawCenteredString(this.fontRenderer, "Leave blank for random seed.", this.width/2, 60, 0xEEEEEE);
    	
    	this.drawString(this.fontRenderer, "Seed:", this.width / 2 + 4, 80, 0xCCCCCC);
    	
    	this.textboxSeed.drawTextBox();
    	
		super.drawScreen(i, j, f);
	}    
}
