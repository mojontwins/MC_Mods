package net.minecraft.src;

public class CraftingRecipe implements IRecipe {
	private int width;
	private int height;
	private ItemStack[] ingredients;
	private ItemStack result;
	public final int resultId;

	public CraftingRecipe(int width, int height, ItemStack[] ingredients, ItemStack result) {
		this.resultId = result.itemID;
		this.width = width;
		this.height = height;
		this.ingredients = ingredients;
		this.result = result;
	}

	public boolean matches(ItemStack[] var1) {
		for(int var2 = 0; var2 <= 3 - this.width; ++var2) {
			for(int var3 = 0; var3 <= 3 - this.height; ++var3) {
				if(this.checkMatch(var1, var2, var3, true)) {
					return true;
				}

				if(this.checkMatch(var1, var2, var3, false)) {
					return true;
				}
			}
		}

		return false;
	}

	private boolean checkMatch(ItemStack[] craftMatrix, int ox, int oy, boolean mirrored) {
		for(int x = 0; x < 3; ++x) {
			for(int y = 0; y < 3; ++y) {
				int cx = x - ox;
				int cy = y - oy;
				ItemStack stack = null;
				if(cx >= 0 && cy >= 0 && cx < this.width && cy < this.height) {
					if(mirrored) {
						stack = this.ingredients[this.width - cx - 1 + cy * this.width];
					} else {
						stack = this.ingredients[cx + cy * this.width];
					}
				}

				ItemStack matrixStack = craftMatrix[x + y * 3];
				if(matrixStack != null || stack != null) {
					if(matrixStack == null && stack != null || matrixStack != null && stack == null) {
						return false;
					}

					if(stack.itemID != matrixStack.itemID) {
						return false;
					}

					if(stack.getItemDamage() != -1 && stack.getItemDamage() != matrixStack.getItemDamage()) {
						return false;
					}
				}
			}
		}

		return true;
	}

	public ItemStack getCraftingResult(ItemStack[] var1) {
		return new ItemStack(this.result.itemID, this.result.stackSize, this.result.itemDmg);
	}

	public int getRecipeSize() {
		return this.width * this.height;
	}

	@Override
	public ItemStack getRecipeOutput() {
		return new ItemStack(this.result.itemID, this.result.stackSize, this.result.getItemDamage());
	}

	@Override
	public ItemStack[] getRecipeItems() {
		return this.ingredients;
	}

	@Override
	public int getWidth() {
		return this.width;
	}

	@Override
	public int getHeight() {
		return this.height;
	}
}


