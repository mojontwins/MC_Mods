package net.minecraft.src;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import net.minecraft.server.MinecraftServer;

public class ModLoaderMp {
	public static final String NAME = "ModLoaderMP";
	public static final String VERSION = "a1.1.2_01";
	private static boolean hasInit = false;
	private static Map entityTrackerMap = new HashMap();
	private static Map entityTrackerEntryMap = new HashMap();
	private static List bannedMods = new ArrayList();
	private static boolean packet230Received = false;
	private static Map netClientHandlerEntityMap = new HashMap();
	private static Map guiModMap = new HashMap();

	public static void initialize() {
		if(!hasInit) {
			initializePrivate();
		}

	}

	public static void registerEntityTracker(Class class1, int i, int j) {
		if(!hasInit) {
			initializePrivate();
		}

		if(entityTrackerMap.containsKey(class1)) {
			System.out.println("RegisterEntityTracker error: entityClass already registered.");
		} else {
			entityTrackerMap.put(class1, new Pair(i, j));
		}

	}

	public static void registerEntityTrackerEntry(Class class1, int i) {
		registerEntityTrackerEntry(class1, false, i);
	}

	public static void registerEntityTrackerEntry(Class class1, boolean flag, int i) {
		if(!hasInit) {
			initializePrivate();
		}

		if(i > 255) {
			System.out.println("RegisterEntityTrackerEntry error: entityId cannot be greater than 255.");
		}

		if(entityTrackerEntryMap.containsKey(class1)) {
			System.out.println("RegisterEntityTrackerEntry error: entityClass already registered.");
		} else {
			entityTrackerEntryMap.put(class1, new EntityTrackerEntry2(i, flag));
		}

	}

	public static void handleAllLogins(EntityPlayerMP entityplayermp) {
		if(!hasInit) {
			initializePrivate();
		}

		sendModCheck(entityplayermp);

		for(int i = 0; i < ModLoader.getLoadedMods().size(); ++i) {
			BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(i);
			if(basemod instanceof BaseModMp) {
				((BaseModMp)basemod).handleLogin(entityplayermp);
			}
		}

	}

	public static void handleAllPackets(Packet230ModLoader packet230modloader, EntityPlayerMP entityplayermp) {
		if(!hasInit) {
			initializePrivate();
		}

		if(packet230modloader.modId == "ModLoaderMP".hashCode()) {
			switch(packet230modloader.packetType) {
			case 0:
				handleModCheckResponse(packet230modloader, entityplayermp);
				break;
			case 1:
				handleSendKey(packet230modloader, entityplayermp);
			}
		} else {
			for(int i = 0; i < ModLoader.getLoadedMods().size(); ++i) {
				BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(i);
				if(basemod instanceof BaseModMp) {
					BaseModMp basemodmp = (BaseModMp)basemod;
					if(basemodmp.getId() == packet230modloader.modId) {
						basemodmp.handlePacket(packet230modloader, entityplayermp);
						break;
					}
				}
			}
		}

	}

	public static void getCommandInfo(ICommandListener icommandlistener) {
		for(int i = 0; i < ModLoader.getLoadedMods().size(); ++i) {
			BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(i);
			if(basemod instanceof BaseModMp) {
				BaseModMp basemodmp = (BaseModMp)basemod;
				basemodmp.getCommandInfo(icommandlistener);
			}
		}

	}

	public static boolean handleCommand(String s, String s1, Logger logger, boolean flag) {
		boolean flag1 = false;

		for(int i = 0; i < ModLoader.getLoadedMods().size(); ++i) {
			BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(i);
			if(basemod instanceof BaseModMp) {
				BaseModMp basemodmp = (BaseModMp)basemod;
				if(basemodmp.handleCommand(s, s1, logger, flag)) {
					flag1 = true;
				}
			}
		}

		return flag1;
	}

	
	private static void handleSendKey(Packet230ModLoader packet230modloader, EntityPlayerMP entityplayermp) {
		if(packet230modloader.dataInt.length != 2) {
			System.out.println("SendKey packet received with missing data.");
		} else {
			int i = packet230modloader.dataInt[0];
			int j = packet230modloader.dataInt[1];

			for(int k = 0; k < ModLoader.getLoadedMods().size(); ++k) {
				BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(k);
				if(basemod instanceof BaseModMp) {
					BaseModMp basemodmp = (BaseModMp)basemod;
					if(basemodmp.getId() == i) {
						basemodmp.handleSendKey(entityplayermp, j);
						break;
					}
				}
			}
		}

	}
	
	public static void handleEntityTrackers(EntityTracker entitytracker, Entity entity) {
		if(!hasInit) {
			initializePrivate();
		}

		Iterator iterator = entityTrackerMap.entrySet().iterator();

		Entry entry;
		do {
			if(!iterator.hasNext()) {
				return;
			}

			entry = (Entry)iterator.next();
		} while(!((Class)entry.getKey()).isInstance(entity));

		entitytracker.trackEntity(entity, ((Integer)((Pair)entry.getValue()).getLeft()).intValue(), ((Integer)((Pair)entry.getValue()).getRight()).intValue());
	}

	public static EntityTrackerEntry2 handleEntityTrackerEntries(Entity entity) {
		if(!hasInit) {
			initializePrivate();
		}

		return entityTrackerEntryMap.containsKey(entity.getClass()) ? (EntityTrackerEntry2)entityTrackerEntryMap.get(entity.getClass()) : null;
	}
	
		public static void sendPacketToAll(BaseModMp basemodmp, Packet230ModLoader packet230modloader) {
		if(!hasInit) {
			initializePrivate();
		}

		if(basemodmp == null) {
			IllegalArgumentException illegalargumentexception = new IllegalArgumentException("baseModMp cannot be null.");
			ModLoader.getLogger().throwing("ModLoaderMP", "SendPacketToAll", illegalargumentexception);
			ModLoader.throwException("baseModMp cannot be null.", illegalargumentexception);
		} else {
			packet230modloader.modId = basemodmp.getId();
			sendPacketToAll(packet230modloader);
		}
	}

	private static void sendPacketToAll(Packet packet) {
		if(packet != null) {
			for(int i = 0; i < MinecraftServer.instance.configManager.playerEntities.size(); ++i) {
				((EntityPlayerMP)MinecraftServer.instance.configManager.playerEntities.get(i)).playerNetServerHandler.sendPacket(packet);
			}
		}

	}

	public static void sendPacketTo(BaseModMp basemodmp, EntityPlayerMP entityplayermp, Packet230ModLoader packet230modloader) {
		if(!hasInit) {
			initializePrivate();
		}

		if(basemodmp == null) {
			IllegalArgumentException illegalargumentexception = new IllegalArgumentException("baseModMp cannot be null.");
			ModLoader.getLogger().throwing("ModLoaderMP", "SendPacketTo", illegalargumentexception);
			ModLoader.throwException("baseModMp cannot be null.", illegalargumentexception);
		} else {
			packet230modloader.modId = basemodmp.getId();
			sendPacketTo(entityplayermp, packet230modloader);
		}
	}

	public static void log(String s) {
		System.out.println(s);
		ModLoader.getLogger().fine(s);
	}
	
	public static void handleAllPackets(Packet230ModLoader packet230modloader) {
		if(!hasInit) {
			initializePrivate();
		}

		packet230Received = true;
		if(packet230modloader.modId == "ModLoaderMP".hashCode()) {
			switch(packet230modloader.packetType) {
			case 0:
				handleModCheck(packet230modloader);
				break;
			case 1:
				handleTileEntityPacket(packet230modloader);
			}
		} else if(packet230modloader.modId == "Spawn".hashCode()) {
			NetClientHandlerEntity i = handleNetClientHandlerEntities(packet230modloader.packetType);
			if(i != null && ISpawnable.class.isAssignableFrom(i.entityClass)) {
				try {
					Entity basemod = (Entity)i.entityClass.getConstructor(new Class[]{World.class}).newInstance(new Object[]{ModLoader.getMinecraftInstance().theWorld});
					((ISpawnable)basemod).spawn(packet230modloader);
					((WorldClient)ModLoader.getMinecraftInstance().theWorld).addEntityToWorld(basemod.entityID, basemod);
				} catch (Exception exception4) {
					ModLoader.getLogger().throwing("ModLoader", "handleCustomSpawn", exception4);
					ModLoader.throwException(String.format("Error initializing entity of type %s.", new Object[]{packet230modloader.packetType}), exception4);
					return;
				}
			}
		} else {
			for(int i5 = 0; i5 < ModLoader.getLoadedMods().size(); ++i5) {
				BaseMod baseMod6 = (BaseMod)ModLoader.getLoadedMods().get(i5);
				if(baseMod6 instanceof BaseModMp) {
					BaseModMp basemodmp = (BaseModMp)baseMod6;
					if(basemodmp.getId() == packet230modloader.modId) {
						basemodmp.handlePacket(packet230modloader);
						break;
					}
				}
			}
		}

	}

	public static NetClientHandlerEntity handleNetClientHandlerEntities(int i) {
		if(!hasInit) {
			initializePrivate();
		}

		return netClientHandlerEntityMap.containsKey(i) ? (NetClientHandlerEntity)netClientHandlerEntityMap.get(i) : null;
	}

	public static void sendPacket(BaseModMp basemodmp, Packet230ModLoader packet230modloader) {
		if(!hasInit) {
			initializePrivate();
		}

		if(basemodmp == null) {
			IllegalArgumentException illegalargumentexception = new IllegalArgumentException("baseModMp cannot be null.");
			ModLoader.getLogger().throwing("ModLoaderMp", "SendPacket", illegalargumentexception);
			ModLoader.throwException("baseModMp cannot be null.", illegalargumentexception);
		} else {
			packet230modloader.modId = basemodmp.getId();
			sendPacket(packet230modloader);
		}

	}

	public static void registerGUI(BaseModMp basemodmp, int i) {
		if(!hasInit) {
			initializePrivate();
		}

		if(guiModMap.containsKey(i)) {
			log("RegisterGUI error: inventoryType already registered.");
		} else {
			guiModMap.put(i, basemodmp);
		}

	}

	/*
	public static void handleGUI(Packet100OpenWindow packet100openwindow) {
		if(!hasInit) {
			initializePrivate();
		}

		BaseModMp basemodmp = (BaseModMp)guiModMap.get(packet100openwindow.inventoryType);
		GuiScreen guiscreen = basemodmp.handleGUI(packet100openwindow.inventoryType);
		if(guiscreen != null) {
			ModLoader.openGUI(ModLoader.getMinecraftInstance().thePlayer, guiscreen);
			ModLoader.getMinecraftInstance().thePlayer.craftingInventory.windowId = packet100openwindow.windowId;
		}

	}
	*/

	public static void registerNetClientHandlerEntity(Class class1, int i) {
		registerNetClientHandlerEntity(class1, false, i);
	}

	public static void registerNetClientHandlerEntity(Class class1, boolean flag, int i) {
		if(!hasInit) {
			initializePrivate();
		}

		if(i > 255) {
			log("RegisterNetClientHandlerEntity error: entityId cannot be greater than 255.");
		} else if(netClientHandlerEntityMap.containsKey(i)) {
			log("RegisterNetClientHandlerEntity error: entityId already registered.");
		} else {
			if(i > 127) {
				i -= 256;
			}

			netClientHandlerEntityMap.put(i, new NetClientHandlerEntity(class1, flag));
		}

	}

	public static void sendKey(BaseModMp basemodmp, int i) {
		if(!hasInit) {
			initializePrivate();
		}

		if(basemodmp == null) {
			IllegalArgumentException packet230modloader = new IllegalArgumentException("baseModMp cannot be null.");
			ModLoader.getLogger().throwing("ModLoaderMp", "SendKey", packet230modloader);
			ModLoader.throwException("baseModMp cannot be null.", packet230modloader);
		} else {
			Packet230ModLoader packet230modloader1 = new Packet230ModLoader();
			packet230modloader1.modId = "ModLoaderMP".hashCode();
			packet230modloader1.packetType = 1;
			packet230modloader1.dataInt = new int[]{basemodmp.getId(), i};
			sendPacket(packet230modloader1);
		}

	}
	
	

	private static void initializePrivate() {
		hasInit = true;

		/*
		try {
			Method securityexception;
			try {
				securityexception = Packet.class.getDeclaredMethod("a", new Class[]{Integer.TYPE, Boolean.TYPE, Boolean.TYPE, Class.class});
			} catch (NoSuchMethodException noSuchMethodException2) {
				securityexception = Packet.class.getDeclaredMethod("addIdClassMapping", new Class[]{Integer.TYPE, Boolean.TYPE, Boolean.TYPE, Class.class});
			}

			securityexception.setAccessible(true);
			securityexception.invoke((Object)null, new Object[]{230, true, true, Packet230ModLoader.class});
			
			
		} catch (IllegalAccessException illegalAccessException3) {
			ModLoader.getLogger().throwing("ModLoaderMp", "init", illegalAccessException3);
			ModLoader.throwException("An impossible error has occurred!", illegalAccessException3);
		} catch (IllegalArgumentException illegalArgumentException4) {
			ModLoader.getLogger().throwing("ModLoaderMp", "init", illegalArgumentException4);
			ModLoader.throwException("An impossible error has occurred!", illegalArgumentException4);
		} catch (InvocationTargetException invocationTargetException5) {
			ModLoader.getLogger().throwing("ModLoaderMp", "init", invocationTargetException5);
			ModLoader.throwException("An impossible error has occurred!", invocationTargetException5);
		} catch (NoSuchMethodException noSuchMethodException6) {
			ModLoader.getLogger().throwing("ModLoaderMp", "init", noSuchMethodException6);
			ModLoader.throwException("An impossible error has occurred!", noSuchMethodException6);
		} catch (SecurityException securityException7) {
			ModLoader.getLogger().throwing("ModLoaderMp", "init", securityException7);
			ModLoader.throwException("An impossible error has occurred!", securityException7);
		}
		*/
		//Packet.addIdClassMapping(230, Packet230ModLoader.class);

		log("ModLoaderMP 1.0.0 Initialized");
	}

	private static void handleModCheck(Packet230ModLoader packet230modloader) {
		Packet230ModLoader packet230modloader1 = new Packet230ModLoader();
		packet230modloader1.modId = "ModLoaderMP".hashCode();
		packet230modloader1.packetType = 0;
		packet230modloader1.dataString = new String[ModLoader.getLoadedMods().size()];

		for(int i = 0; i < ModLoader.getLoadedMods().size(); ++i) {
			packet230modloader1.dataString[i] = ((BaseMod)ModLoader.getLoadedMods().get(i)).toString();
		}

		sendPacket(packet230modloader1);
	}
	
	private static void sendPacketTo(EntityPlayerMP entityplayermp, Packet230ModLoader packet230modloader) {
		entityplayermp.playerNetServerHandler.sendPacket(packet230modloader);
	}
	
	private static void sendModCheck(EntityPlayerMP entityplayermp) {
		Packet230ModLoader packet230modloader = new Packet230ModLoader();
		packet230modloader.modId = "ModLoaderMP".hashCode();
		packet230modloader.packetType = 0;
		sendPacketTo(entityplayermp, packet230modloader);
	}

	private static void handleModCheckResponse(Packet230ModLoader packet230modloader, EntityPlayerMP entityplayermp) {
		StringBuilder stringbuilder = new StringBuilder();
		if(packet230modloader.dataString.length != 0) {
			for(int arraylist = 0; arraylist < packet230modloader.dataString.length; ++arraylist) {
				if(packet230modloader.dataString[arraylist].lastIndexOf("mod_") != -1) {
					if(stringbuilder.length() != 0) {
						stringbuilder.append(", ");
					}

					stringbuilder.append(packet230modloader.dataString[arraylist].substring(packet230modloader.dataString[arraylist].lastIndexOf("mod_")));
				}
			}
		} else {
			stringbuilder.append("no mods");
		}

		log(entityplayermp.username + " joined with " + stringbuilder.toString());
		ArrayList arrayList11 = new ArrayList();

		int stringbuilder2;
		for(int arraylist1 = 0; arraylist1 < bannedMods.size(); ++arraylist1) {
			for(stringbuilder2 = 0; stringbuilder2 < packet230modloader.dataString.length; ++stringbuilder2) {
				if(packet230modloader.dataString[stringbuilder2].lastIndexOf("mod_") != -1 && packet230modloader.dataString[stringbuilder2].substring(packet230modloader.dataString[stringbuilder2].lastIndexOf("mod_")).startsWith((String)bannedMods.get(arraylist1))) {
					arrayList11.add(packet230modloader.dataString[stringbuilder2]);
				}
			}
		}

		ArrayList arrayList12 = new ArrayList();

		for(stringbuilder2 = 0; stringbuilder2 < ModLoader.getLoadedMods().size(); ++stringbuilder2) {
			BaseModMp j1 = (BaseModMp)ModLoader.getLoadedMods().get(stringbuilder2);
			if(j1.hasClientSide() && j1.toString().lastIndexOf("mod_") != -1) {
				String k1 = j1.toString().substring(j1.toString().lastIndexOf("mod_"));
				boolean flag = false;

				for(int l1 = 0; l1 < packet230modloader.dataString.length; ++l1) {
					if(packet230modloader.dataString[l1].lastIndexOf("mod_") != -1) {
						String s1 = packet230modloader.dataString[l1].substring(packet230modloader.dataString[l1].lastIndexOf("mod_"));
						if(k1.equals(s1)) {
							flag = true;
							break;
						}
					}
				}

				if(!flag) {
					arrayList12.add(k1);
				}
			}
		}

		StringBuilder stringBuilder13;
		int i14;
		if(arrayList11.size() != 0) {
			stringBuilder13 = new StringBuilder();

			for(i14 = 0; i14 < arrayList11.size(); ++i14) {
				if(((String)arrayList11.get(i14)).lastIndexOf("mod_") != -1) {
					if(stringBuilder13.length() != 0) {
						stringBuilder13.append(", ");
					}

					stringBuilder13.append(((String)arrayList11.get(i14)).substring(((String)arrayList11.get(i14)).lastIndexOf("mod_")));
				}
			}

			log(entityplayermp.username + " kicked for having " + stringBuilder13.toString());
			StringBuilder stringBuilder15 = new StringBuilder();

			for(int i16 = 0; i16 < arrayList11.size(); ++i16) {
				if(((String)arrayList11.get(i16)).lastIndexOf("mod_") != -1) {
					stringBuilder15.append("\n");
					stringBuilder15.append(((String)arrayList11.get(i16)).substring(((String)arrayList11.get(i16)).lastIndexOf("mod_")));
				}
			}

			entityplayermp.playerNetServerHandler.kickPlayer("The following mods are banned on this server:" + stringBuilder15.toString());
		} else if(arrayList12.size() != 0) {
			stringBuilder13 = new StringBuilder();

			for(i14 = 0; i14 < arrayList12.size(); ++i14) {
				if(((String)arrayList12.get(i14)).lastIndexOf("mod_") != -1) {
					stringBuilder13.append("\n");
					stringBuilder13.append(((String)arrayList12.get(i14)).substring(((String)arrayList12.get(i14)).lastIndexOf("mod_")));
				}
			}

			entityplayermp.playerNetServerHandler.kickPlayer("You are missing the following mods:" + stringBuilder13.toString());
		}

	}

	private static void handleTileEntityPacket(Packet230ModLoader packet230modloader) {
		if(packet230modloader.dataInt != null && packet230modloader.dataInt.length >= 5) {
			int i = packet230modloader.dataInt[0];
			int j = packet230modloader.dataInt[1];
			int k = packet230modloader.dataInt[2];
			int l = packet230modloader.dataInt[3];
			int i1 = packet230modloader.dataInt[4];
			int[] ai = new int[packet230modloader.dataInt.length - 5];
			System.arraycopy(packet230modloader.dataInt, 5, ai, 0, packet230modloader.dataInt.length - 5);
			float[] af = packet230modloader.dataFloat;
			String[] as = packet230modloader.dataString;

			for(int j1 = 0; j1 < ModLoader.getLoadedMods().size(); ++j1) {
				BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(j1);
				if(basemod instanceof BaseModMp) {
					BaseModMp basemodmp = (BaseModMp)basemod;
					if(basemodmp.getId() == i) {
						basemodmp.handleTileEntityPacket(j, k, l, i1, ai, af, as);
						break;
					}
				}
			}
		} else {
			log("Bad TileEntityPacket received.");
		}

	}

	private static void sendPacket(Packet230ModLoader packet230modloader) {
		if(packet230Received && ModLoader.getMinecraftInstance().theWorld != null && ModLoader.getMinecraftInstance().theWorld.multiplayerWorld) {
			ModLoader.getMinecraftInstance().getSendQueue().addToSendQueue(packet230modloader);
		}

	}

	public static BaseModMp getModInstance(Class class1) {
		for(int i = 0; i < ModLoader.getLoadedMods().size(); ++i) {
			BaseMod basemod = (BaseMod)ModLoader.getLoadedMods().get(i);
			if(basemod instanceof BaseModMp) {
				BaseModMp basemodmp = (BaseModMp)basemod;
				if(class1.isInstance(basemodmp)) {
					return (BaseModMp)ModLoader.getLoadedMods().get(i);
				}
			}
		}

		return null;
	}
}
