package net.minecraft.src;

public class ItemArmor extends Item {
	
	public enum EnumArmorMaterial {
		CLOTH(5, new int[]{1, 3, 2, 1}, 15),
		CHAIN(15, new int[]{2, 5, 4, 1}, 12),
		IRON(15, new int[]{2, 6, 5, 2}, 9),
		GOLD(7, new int[]{2, 5, 3, 1}, 25),
		DIAMOND(33, new int[]{3, 8, 6, 3}, 10);
		
		private int maxDamageFactor;
		private int[] damageReductionAmountArray;
		private int enchantability;

		private EnumArmorMaterial(int i3, int[] i4, int i5) {
			this.maxDamageFactor = i3;
			this.damageReductionAmountArray = i4;
			this.enchantability = i5;
		}

		public int getDurability(int i1) {
			return ItemArmor.getMaxDamageArray()[i1] * this.maxDamageFactor;
		}

		public int getDamageReductionAmount(int i1) {
			return this.damageReductionAmountArray[i1];
		}

		public int getEnchantability() {
			return this.enchantability;
		}
	}
	
	private static final int[] maxDamageArray = new int[]{11, 16, 15, 13};
	public final int armorType;
	public final int damageReduceAmount;
	public final int renderIndex;
	public final EnumArmorMaterial material;

	public ItemArmor(int i1, EnumArmorMaterial enumArmorMaterial2, int i3, int i4) {
		super(i1);
		this.material = enumArmorMaterial2;
		this.armorType = i4;
		this.renderIndex = i3;
		this.damageReduceAmount = enumArmorMaterial2.getDamageReductionAmount(i4);
		this.maxDamage = enumArmorMaterial2.getDurability(i4);
		this.maxStackSize = 1;
	}
	
	static int[] getMaxDamageArray() {
		return maxDamageArray;
	}
}
