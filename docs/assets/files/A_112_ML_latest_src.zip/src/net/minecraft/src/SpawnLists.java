package net.minecraft.src;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SpawnLists {
	// Made those as public lists so modloader can add its own mobs.
	
	public static List spawnableMobs = new ArrayList(
			Arrays.asList(EntityZombie.class, EntitySkeleton.class, EntityCreeper.class, EntitySpider.class, EntitySlime.class)
		);
	
	public static List spawnableAnimals = new ArrayList(
			Arrays.asList(EntitySheep.class, EntityPig.class, EntityCow.class, EntityChicken.class)
		);
			

}
