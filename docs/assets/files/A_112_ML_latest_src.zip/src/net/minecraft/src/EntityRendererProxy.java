package net.minecraft.src;

import net.minecraft.client.Minecraft;

public class EntityRendererProxy extends EntityRenderer {
	private Minecraft game;

	public EntityRendererProxy(Minecraft minecraft) {
		super(minecraft);
		this.game = minecraft;
	}

	public void updateCameraAndRender(float tick) {
		super.updateCameraAndRender(tick);
		ModLoader.onTick(tick, this.game);
	}
}
