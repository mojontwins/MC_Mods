package net.minecraft.src;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CraftingRecipeShapeless implements IRecipe {
	private final ItemStack recipeOutput;
	private final List<ItemStack> recipeItems;

	public CraftingRecipeShapeless(ItemStack itemStack1, List<ItemStack> list2) {
		this.recipeOutput = itemStack1;
		this.recipeItems = list2;
	}
	
	@Override
	public boolean matches(ItemStack[] var1) {
		ArrayList<ItemStack> arrayList2 = new ArrayList<ItemStack>(this.recipeItems);

		for(int i3 = 0; i3 < 3; ++i3) {
			for(int i4 = 0; i4 < 3; ++i4) {
				ItemStack itemStack5 = var1[i3 * 3 + i4];
				if(itemStack5 != null) {
					boolean z6 = false;
					Iterator<ItemStack> iterator7 = arrayList2.iterator();

					while(iterator7.hasNext()) {
						ItemStack itemStack8 = (ItemStack)iterator7.next();
						if(itemStack5.itemID == itemStack8.itemID && (itemStack8.getItemDamage() == -1 || itemStack5.getItemDamage() == itemStack8.getItemDamage())) {
							z6 = true;
							arrayList2.remove(itemStack8);
							break;
						}
					}

					if(!z6) {
						return false;
					}
				}
			}
		}

		return arrayList2.isEmpty();
	}

	@Override
	public ItemStack getCraftingResult(ItemStack[] var1) {
		return this.recipeOutput.copy();
	}

	@Override
	public int getRecipeSize() {
		return this.recipeItems.size();
	}

	@Override
	public ItemStack getRecipeOutput() {
		return this.recipeOutput;
	}

	@Override
	public ItemStack[] getRecipeItems() {
		ItemStack[] recipeItemsAsArray = new ItemStack[9];
		for (int i = 0; i < 9; i ++) recipeItemsAsArray [i] = null;
		for (int i = 0; i < this.recipeItems.size(); i ++) recipeItemsAsArray[i] = this.recipeItems.get(i);
		return recipeItemsAsArray;
	}

	@Override
	public int getWidth() {
		return 3;
	}

	@Override
	public int getHeight() {
		return 3;
	}

}
