package net.minecraft.src;

import java.util.Map;
import java.util.Random;

import net.minecraft.client.Minecraft;

public abstract class BaseMod {
	public int addFuel(int id, int metadata) {
		return 0;
	}

	public void addRenderer(Map renderers) {
	}

	public boolean dispenseEntity(World world, double x, double y, double z, int xVel, int zVel, ItemStack item) {
		return false;
	}

	public void generateNether(World world, Random random, int chunkX, int chunkZ) {
	}

	public void generateSurface(World world, Random random, int chunkX, int chunkZ) {
	}

	public String getName() {
		return this.getClass().getSimpleName();
	}

	public String getPriorities() {
		return "";
	}

	public abstract String getVersion();

	public void keyboardEvent(KeyBinding event) {
	}

	public abstract void load();

	public void modsLoaded() {
	}

	public void onItemPickup(EntityPlayer player, ItemStack item) {
	}

	public boolean onTickInGame(float tick, Minecraft game) {
		return false;
	}

	public boolean onTickInGUI(float tick, Minecraft game, GuiScreen gui) {
		return false;
	}

	public void receiveChatPacket(String text) {
	}

	public void receiveChatPacket(String s, EntityPlayerMP entityplayermp) {
	}
	
	public void receiveCustomPacket(Packet250CustomPayload packet) {
	}

	public void registerAnimation(Minecraft game) {
	}

	public void renderInvBlock(RenderBlocks renderer, Block block, int metadata, int modelID) {
	}

	public boolean renderWorldBlock(RenderBlocks renderer, IBlockAccess world, int x, int y, int z, Block block, int modelID) {
		return false;
	}

	public void serverConnect(NetClientHandler handler) {
	}

	public void serverDisconnect() {
	}

	public void serverDisconnect(EntityPlayerMP entityplayermp) {
	}
	
	public void takenFromCrafting(EntityPlayer player, ItemStack item, IInventory matrix) {
	}

	public void takenFromFurnace(EntityPlayer player, ItemStack item) {
	}

	public String toString() {
		return this.getName() + ' ' + this.getVersion();
	}
}
