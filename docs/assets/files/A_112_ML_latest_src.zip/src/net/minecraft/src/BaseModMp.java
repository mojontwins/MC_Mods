package net.minecraft.src;

import java.util.logging.Logger;

public abstract class BaseModMp extends BaseMod {
	public final int getId() {
		return this.toString().hashCode();
	}

	public void modsLoaded() {
		ModLoaderMp.initialize();
		super.modsLoaded();
	}

	public void handlePacket(Packet230ModLoader packet230modloader) {
	}
	
	public void handlePacket(Packet230ModLoader packet230modloader, EntityPlayerMP entityplayermp) {
	}
	
	public void handleLogin(EntityPlayerMP entityplayermp) {
	}
	
	public void handleSendKey(EntityPlayerMP entityplayermp, int i) {
	}

	public void handleTileEntityPacket(int i, int j, int k, int l, int[] ai, float[] af, String[] as) {
	}
	
	public boolean handleCommand(String s, String s1, Logger logger, boolean flag) {
		return false;
	}
	
	public void getCommandInfo(ICommandListener icommandlistener) {
	}

	public GuiScreen handleGUI(int i) {
		return null;
	}
	
	public boolean hasClientSide() {
		return true;
	}
}
