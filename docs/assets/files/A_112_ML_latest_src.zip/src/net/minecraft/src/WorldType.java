package net.minecraft.src;

public enum WorldType {
	ALPHA(1, "ALPHA", "Alpha", ChunkProviderGenerate.class, Block.sand.blockID),
	INFDEV(2, "INFDEV", "Infdev 415", ChunkProviderInfdev.class, Block.sand.blockID),
	SKY(3, "SKY", "Beta Sky", ChunkProviderSky.class, Block.grass.blockID);
	
	public final int id;
	public final String name;
	public final String desc;
	public final Class<? extends IChunkProvider> generator;
	public final int spawnOnThisBlockID;
	
	private WorldType(int id, String name, String desc, Class<? extends IChunkProvider> generator, int spawnOnThisBlockID) {
		this.id = id;
		this.name = name;
		this.desc = desc;
		this.generator = generator;
		this.spawnOnThisBlockID = spawnOnThisBlockID;
	}
	
	public static WorldType fromID(int id) {
		for(WorldType type : values()) {
			if(type.id == id) return type; 
		}
		
		return WorldType.ALPHA;
	}
	
	public static WorldType fromName(String name) {
		for(WorldType type : values()) {
			if(type.name.equals(name)) return type; 
		}
		
		return WorldType.ALPHA;
	}
}
