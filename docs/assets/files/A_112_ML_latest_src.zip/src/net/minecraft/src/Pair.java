package net.minecraft.src;

public class Pair {
	private final Object left;
	private final Object right;

	public Pair(Object left, Object right) {
		this.left = left;
		this.right = right;
	}

	public Object getLeft() {
		return this.left;
	}

	public Object getRight() {
		return this.right;
	}

	public int hashCode() {
		return this.left.hashCode() ^ this.right.hashCode();
	}

	public boolean equals(Object o) {
		if(o == null) {
			return false;
		} else if(!(o instanceof Pair)) {
			return false;
		} else {
			Pair pairo = (Pair)o;
			return this.left.equals(pairo.getLeft()) && this.right.equals(pairo.getRight());
		}
	}
}
