package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

public class ChunkLoader implements IChunkLoader {
	private File saveDir;

	public ChunkLoader(File var1, boolean var2) {
		this.saveDir = var1;
	}

	private File chunkFileForXZ(int var1, int var2) {
		String fileName = "c." + Integer.toString(var1, 36) + "." + Integer.toString(var2, 36) + ".dat";
		String dir1 = Integer.toString(var1 & 63, 36);
		String dir2 = Integer.toString(var2 & 63, 36);
		File file = new File(this.saveDir, dir1);
		file = new File(file, dir2);
		file = new File(file, fileName);
		return file;
	}

	public Chunk loadChunk(World world, int x, int z) throws IOException {
		DataInputStream regionChunkInputStream = RegionFileCache.getChunkDataInputStream(this.saveDir, x, z);
		File chunkFile = this.chunkFileForXZ(x, z);
		NBTTagCompound nbt;
		if(regionChunkInputStream != null) {
			nbt = CompressedStreamTools.read(regionChunkInputStream);
		} else {
			if(!chunkFile.exists()) {
				return null;
			}

			try {
				FileInputStream var7 = new FileInputStream(chunkFile);
				nbt = CompressedStreamTools.readCompressed(var7);
			} catch (Exception exception10) {
				exception10.printStackTrace();
				return null;
			}
		}

		if(!nbt.hasKey("Level")) {
			System.out.println("Chunk file at " + x + "," + z + " is missing level data, skipping");
			return null;
		} else if(!nbt.getCompoundTag("Level").hasKey("Blocks")) {
			System.out.println("Chunk file at " + x + "," + z + " is missing block data, skipping");
			return null;
		} else {
			Chunk var71 = loadChunkIntoWorldFromCompound(world, nbt.getCompoundTag("Level"));
			
			if(!var71.isAtLocation(x, z)) {
				System.out.println("Chunk file at " + x + "," + z + " is in the wrong location; relocating. (Expected " + x + ", " + z + ", got " + var71.xPosition + ", " + var71.zPosition + ")");
				nbt.setInteger("xPos", x);
				nbt.setInteger("zPos", z);
				var71 = loadChunkIntoWorldFromCompound(world, nbt.getCompoundTag("Level"));
			}

			try {
				if(regionChunkInputStream != null) {
					regionChunkInputStream.close();
				}
			} catch (IOException iOException9) {
			}

			return var71;
		}
	}

	public void saveChunk(World world, Chunk chunk) throws IOException {
		world.checkSessionLock();
		DataOutputStream output = RegionFileCache.getChunkDataOutputStream(this.saveDir, chunk.xPosition, chunk.zPosition);
		NBTTagCompound var6 = new NBTTagCompound();
		NBTTagCompound var7 = new NBTTagCompound();
		var6.setTag("Level", var7);
		this.storeChunkInCompound(chunk, world, var7);

		CompressedStreamTools.write(var6, output);

		try {
			output.close();
		} catch (IOException iOException7) {
			iOException7.printStackTrace();
		}

		world.sizeOnDisk += (long)RegionFileCache.getSizeDelta(this.saveDir, chunk.xPosition, chunk.zPosition);
	}

	public void storeChunkInCompound(Chunk chunk, World world, NBTTagCompound nbtCompound) {
		world.checkSessionLock();
		nbtCompound.setInteger("xPos", chunk.xPosition);
		nbtCompound.setInteger("zPos", chunk.zPosition);
		nbtCompound.setLong("LastUpdate", world.worldTime);
		nbtCompound.setByteArray("Blocks", chunk.blocks);
		nbtCompound.setByteArray("Data", chunk.data.data);
		nbtCompound.setByteArray("SkyLight", chunk.skylightMap.data);
		nbtCompound.setByteArray("BlockLight", chunk.blocklightMap.data);
		nbtCompound.setByteArray("HeightMap", chunk.heightMap);
		nbtCompound.setBoolean("TerrainPopulated", chunk.isTerrainPopulated);
		chunk.hasEntities = false;
		
		NBTTagCompound nBTTagCompound8;		
		{
			NBTTagList nBTTagList4 = new NBTTagList();
			Iterator<Entity> iterator6;
			
			for(int i5 = 0; i5 < chunk.entities.length; ++i5) {
				iterator6 = chunk.entities[i5].iterator();
	
				while(iterator6.hasNext()) {
					Entity entity7 = (Entity)iterator6.next();
					chunk.hasEntities = true;
					nBTTagCompound8 = new NBTTagCompound();
					if(entity7.addEntityID(nBTTagCompound8)) {
						nBTTagList4.setTag(nBTTagCompound8);
					}
				}
			}
		
			nbtCompound.setTag("Entities", nBTTagList4);
		}
		
		NBTTagList nBTTagList9 = new NBTTagList();
		{
			Iterator<TileEntity>iterator6 = chunk.chunkTileEntityMap.values().iterator();
	
			while(iterator6.hasNext()) {
				TileEntity tileEntity10 = (TileEntity)iterator6.next();
				nBTTagCompound8 = new NBTTagCompound();
				tileEntity10.writeToNBT(nBTTagCompound8);
				nBTTagList9.setTag(nBTTagCompound8);
			}
		}
		
		nbtCompound.setTag("TileEntities", nBTTagList9);
	}
	
	public static Chunk loadChunkIntoWorldFromCompound(World var0, NBTTagCompound var1) {
		int var2 = var1.getInteger("xPos");
		int var3 = var1.getInteger("zPos");
		Chunk var4 = new Chunk(var0, var2, var3);
		var4.blocks = var1.getByteArray("Blocks");
		var4.data = new NibbleArray(var1.getByteArray("Data"));
		var4.skylightMap = new NibbleArray(var1.getByteArray("SkyLight"));
		var4.blocklightMap = new NibbleArray(var1.getByteArray("BlockLight"));
		var4.heightMap = var1.getByteArray("HeightMap");
		var4.isTerrainPopulated = var1.getBoolean("TerrainPopulated");
		if(!var4.data.isValid()) {
			var4.data = new NibbleArray(var4.blocks.length);
		}

		if(var4.heightMap == null || !var4.skylightMap.isValid()) {
			var4.heightMap = new byte[256];
			var4.skylightMap = new NibbleArray(var4.blocks.length);
			var4.generateSkylightMap();
		}

		if(!var4.blocklightMap.isValid()) {
			var4.blocklightMap = new NibbleArray(var4.blocks.length);
			var4.doNothing();
		}

		NBTTagList var5 = var1.getTagList("Entities");
		if(var5 != null) {
			for(int var6 = 0; var6 < var5.tagCount(); ++var6) {
				NBTTagCompound var7 = (NBTTagCompound)var5.tagAt(var6);
				Entity var8 = EntityList.createEntityFromNBT(var7, var0);
				var4.hasEntities = true;
				if(var8 != null) {
					var4.addEntity(var8);
				}
			}
		}

		NBTTagList var10 = var1.getTagList("TileEntities");
		if(var10 != null) {
			for(int var11 = 0; var11 < var10.tagCount(); ++var11) {
				NBTTagCompound var12 = (NBTTagCompound)var10.tagAt(var11);
				TileEntity var9 = TileEntity.createAndLoadEntity(var12);
				if(var9 != null) {
					var4.addTileEntity(var9);
				}
			}
		}

		return var4;
	}

	public void chunkTick() {
	}

	public void saveExtraData() {
	}

	public void saveExtraChunkData(World var1, Chunk var2) {
	}
}
