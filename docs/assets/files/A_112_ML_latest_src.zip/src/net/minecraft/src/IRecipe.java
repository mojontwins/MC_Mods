package net.minecraft.src;

public interface IRecipe {
	public boolean matches(ItemStack[] var1);

	public ItemStack getCraftingResult(ItemStack[] var1);

	public int getRecipeSize();

	public ItemStack getRecipeOutput();
	
	public ItemStack[] getRecipeItems();
	
	public int getWidth();

	public int getHeight();
	
}
