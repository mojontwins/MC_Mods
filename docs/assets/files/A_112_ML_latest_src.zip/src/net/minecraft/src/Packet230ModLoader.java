package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Packet230ModLoader extends Packet {
	//private static final int MAX_DATA_LENGTH = 65535;
	public int modId;
	public int packetType;
	public int[] dataInt = new int[0];
	public float[] dataFloat = new float[0];
	public double[] dataDouble = new double[0];
	public String[] dataString = new String[0];
	private static Map playerMap = new HashMap();

	public void readPacketData(DataInputStream datainputstream) throws IOException {
		this.modId = datainputstream.readInt();
		this.packetType = datainputstream.readInt();
		int i = datainputstream.readInt();
		if(i > 65535) {
			throw new IOException(String.format("Integer data size of %d is higher than the max (%d).", new Object[]{i, 65535}));
		} else {
			this.dataInt = new int[i];

			int k;
			for(k = 0; k < i; ++k) {
				this.dataInt[k] = datainputstream.readInt();
			}

			k = datainputstream.readInt();
			if(k > 65535) {
				throw new IOException(String.format("Float data size of %d is higher than the max (%d).", new Object[]{k, 65535}));
			} else {
				this.dataFloat = new float[k];

				int q;
				for(q = 0; q < k; ++q) {
					this.dataFloat[q] = datainputstream.readFloat();
				}

				q = datainputstream.readInt();
				if(q > 65535) {
					throw new IOException(String.format("Double data size of %d is higher than the max (%d).", new Object[]{q, 65535}));
				} else {
					this.dataDouble = new double[q];

					int i1;
					for(i1 = 0; i1 < q; ++i1) {
						this.dataDouble[i1] = datainputstream.readDouble();
					}

					i1 = datainputstream.readInt();
					if(i1 > 65535) {
						throw new IOException(String.format("String data size of %d is higher than the max (%d).", new Object[]{i1, 65535}));
					} else {
						this.dataString = new String[i1];

						for(int j1 = 0; j1 < i1; ++j1) {
							int k1 = datainputstream.readInt();
							if(k1 > 65535) {
								throw new IOException(String.format("String length of %d is higher than the max (%d).", new Object[]{k1, 65535}));
							}

							byte[] abyte0 = new byte[k1];

							for(int l1 = 0; l1 < k1; l1 += datainputstream.read(abyte0, l1, k1 - l1)) {
							}

							this.dataString[j1] = new String(abyte0);
						}

					}
				}
			}
		}
	}

	public void writePacket(DataOutputStream dataoutputstream) throws IOException {
		if(this.dataInt != null && this.dataInt.length > 65535) {
			throw new IOException(String.format("Integer data size of %d is higher than the max (%d).", new Object[]{this.dataInt.length, 65535}));
		} else if(this.dataFloat != null && this.dataFloat.length > 65535) {
			throw new IOException(String.format("Float data size of %d is higher than the max (%d).", new Object[]{this.dataFloat.length, 65535}));
		} else if(this.dataDouble != null && this.dataDouble.length > 65535) {
			throw new IOException(String.format("Double data size of %d is higher than the max (%d).", new Object[]{this.dataDouble.length, 65535}));
		} else if(this.dataString != null && this.dataString.length > 65535) {
			throw new IOException(String.format("String data size of %d is higher than the max (%d).", new Object[]{this.dataString.length, 65535}));
		} else {
			dataoutputstream.writeInt(this.modId);
			dataoutputstream.writeInt(this.packetType);
			int k;
			if(this.dataInt == null) {
				dataoutputstream.writeInt(0);
			} else {
				dataoutputstream.writeInt(this.dataInt.length);

				for(k = 0; k < this.dataInt.length; ++k) {
					dataoutputstream.writeInt(this.dataInt[k]);
				}
			}

			if(this.dataFloat == null) {
				dataoutputstream.writeInt(0);
			} else {
				dataoutputstream.writeInt(this.dataFloat.length);

				for(k = 0; k < this.dataFloat.length; ++k) {
					dataoutputstream.writeFloat(this.dataFloat[k]);
				}
			}

			if(this.dataDouble == null) {
				dataoutputstream.writeInt(0);
			} else {
				dataoutputstream.writeInt(this.dataDouble.length);

				for(k = 0; k < this.dataDouble.length; ++k) {
					dataoutputstream.writeDouble(this.dataDouble[k]);
				}
			}

			if(this.dataString == null) {
				dataoutputstream.writeInt(0);
			} else {
				dataoutputstream.writeInt(this.dataString.length);

				for(k = 0; k < this.dataString.length; ++k) {
					if(this.dataString[k].length() > 65535) {
						throw new IOException(String.format("String length of %d is higher than the max (%d).", new Object[]{this.dataString[k].length(), 65535}));
					}

					dataoutputstream.writeInt(this.dataString[k].length());
					dataoutputstream.writeBytes(this.dataString[k]);
				}
			}

		}
	}

	public void processPacket(NetHandler nethandler) {
		if(ModLoader.isThisClient()) {
			ModLoaderMp.handleAllPackets(this);
		} else {
			EntityPlayerMP entityplayermp = null;
			if(playerMap.containsKey(nethandler)) {
				entityplayermp = (EntityPlayerMP)playerMap.get(nethandler);
			} else if(nethandler instanceof NetServerHandler) {
				try {
					entityplayermp = (EntityPlayerMP)ModLoader.getPrivateValue(NetServerHandler.class, nethandler, 4);
					playerMap.put(nethandler, entityplayermp);
				} catch (NoSuchFieldException noSuchFieldException4) {
					System.out.println("Error getting player from NetServerHandler.");
					noSuchFieldException4.printStackTrace();
				}
			}

			ModLoaderMp.handleAllPackets(this, entityplayermp);
		}
	}

	public int getPacketSize() {
		byte i = 0;
		int i3 = i + 4;
		i3 += 4;
		i3 += 4;
		i3 += this.dataInt != null ? this.dataInt.length * 4 : 0;
		i3 += 4;
		i3 = this.dataFloat != null ? this.dataFloat.length * 4 : 0;
		i3 += 4;
		i3 = this.dataDouble != null ? this.dataDouble.length * 8 : 0;
		i3 += 4;
		if(this.dataString != null) {
			for(int j = 0; j < this.dataString.length; ++j) {
				i3 += 4;
				i3 += this.dataString[j].length();
			}
		}

		return i3;
	}
}
