package net.minecraft.src;

public class ItemSpade extends ItemTool {
	private static BlockState[] blocksEffectiveAgainst = new BlockState[]{
			new BlockState(Block.grass, -1),  
			new BlockState(Block.dirt, -1),  
			new BlockState(Block.sand, -1),  
			new BlockState(Block.gravel, -1),  
			new BlockState(Block.snow, -1),  
			new BlockState(Block.blockSnow, -1),  
			new BlockState(Block.blockClay, -1)
	};

	public ItemSpade(int var1, int var2) {
		super(var1, 1, var2, blocksEffectiveAgainst);
	}

	public boolean canHarvestBlock(Block var1) {
		return var1 == Block.snow ? true : var1 == Block.blockSnow;
	}
}
