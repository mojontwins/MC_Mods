package net.minecraft.src;

public class ItemPickaxe extends ItemTool {
	private static BlockState[] blocksEffectiveAgainst = new BlockState[]{
			new BlockState(Block.cobblestone, -1),  
			new BlockState(Block.stairDouble, 0),  
			new BlockState(Block.stairSingle, 0),  
			new BlockState(Block.stone, -1),  
			new BlockState(Block.cobblestoneMossy, -1),  
			new BlockState(Block.oreIron, -1),  
			new BlockState(Block.blockSteel, -1),  
			new BlockState(Block.oreCoal, -1),  
			new BlockState(Block.blockGold, -1),  
			new BlockState(Block.oreGold, -1),  
			new BlockState(Block.oreDiamond, -1),  
			new BlockState(Block.blockDiamond, -1),  
			new BlockState(Block.ice, -1), 
			new BlockState(Block.brick, -1), 
			new BlockState(Block.obsidian, -1), 
			new BlockState(Block.mobSpawner, -1), 
			new BlockState(Block.stoneOvenActive, -1), 
			new BlockState(Block.stoneOvenIdle, -1), 
			new BlockState(Block.minecartTrack, -1), 
			new BlockState(Block.stairCompactStone, -1), 
			new BlockState(Block.lever, -1), 
			new BlockState(Block.pressurePlateStone, -1), 
			new BlockState(Block.doorSteel, -1), 
			new BlockState(Block.oreRedstone, -1), 
			new BlockState(Block.oreRedstoneGlowing, -1)
	};
	private int harvestLevel;

	public ItemPickaxe(int var1, int var2) {
		super(var1, 2, var2, blocksEffectiveAgainst);
		this.harvestLevel = var2;
	}

	public boolean canHarvestBlock(Block var1) {
		return var1 == Block.obsidian ? this.harvestLevel == 3 : (var1 != Block.blockDiamond && var1 != Block.oreDiamond ? (var1 != Block.blockGold && var1 != Block.oreGold ? (var1 != Block.blockSteel && var1 != Block.oreIron ? (var1 != Block.oreRedstone && var1 != Block.oreRedstoneGlowing ? (var1.material == Material.rock ? true : var1.material == Material.iron) : this.harvestLevel >= 2) : this.harvestLevel >= 1) : this.harvestLevel >= 2) : this.harvestLevel >= 2);
	}
}
