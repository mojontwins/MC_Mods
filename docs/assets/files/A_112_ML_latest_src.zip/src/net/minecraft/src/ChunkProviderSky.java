package net.minecraft.src;

public class ChunkProviderSky extends ChunkProviderGenerate {

	public ChunkProviderSky(World world, long seed) {
		super(world, seed);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void generateTerrain(final int par1, final int par2, final byte[] par3ArrayOfByte) {
		final byte var5 = 2;
		final int var6 = var5 + 1;
		final byte var7 = 33;
		final int var8 = var5 + 1;
		this.noiseArray = this.initializeNoiseField(this.noiseArray, par1 * var5, 0, par2 * var5, var6, var7, var8);
		for (int var9 = 0; var9 < var5; ++var9) {
			for (int var10 = 0; var10 < var5; ++var10) {
				for (int var11 = 0; var11 < 32; ++var11) {
					final double var12 = 0.25;
					double var13 = this.noiseArray[((var9 + 0) * var8 + var10 + 0) * var7 + var11 + 0];
					double var14 = this.noiseArray[((var9 + 0) * var8 + var10 + 1) * var7 + var11 + 0];
					double var15 = this.noiseArray[((var9 + 1) * var8 + var10 + 0) * var7 + var11 + 0];
					double var16 = this.noiseArray[((var9 + 1) * var8 + var10 + 1) * var7 + var11 + 0];
					final double var17 = (this.noiseArray[((var9 + 0) * var8 + var10 + 0) * var7 + var11 + 1] - var13)
							* var12;
					final double var18 = (this.noiseArray[((var9 + 0) * var8 + var10 + 1) * var7 + var11 + 1] - var14)
							* var12;
					final double var19 = (this.noiseArray[((var9 + 1) * var8 + var10 + 0) * var7 + var11 + 1] - var15)
							* var12;
					final double var20 = (this.noiseArray[((var9 + 1) * var8 + var10 + 1) * var7 + var11 + 1] - var16)
							* var12;
					for (int var21 = 0; var21 < 4; ++var21) {
						final double var22 = 0.125;
						double var23 = var13;
						double var24 = var14;
						final double var25 = (var15 - var13) * var22;
						final double var26 = (var16 - var14) * var22;
						for (int var27 = 0; var27 < 8; ++var27) {
							int var28 = var27 + var9 * 8 << 11 | 0 + var10 * 8 << 7 | var11 * 4 + var21;
							final short var29 = 128;
							final double var30 = 0.125;
							double var31 = var23;
							final double var32 = (var24 - var23) * var30;
							for (int var33 = 0; var33 < 8; ++var33) {
								int var34 = 0;
								if (var31 > 0.0) {
									var34 = Block.stone.blockID;
								}
								par3ArrayOfByte[var28] = (byte) var34;
								var28 += var29;
								var31 += var32;
							}
							var23 += var25;
							var24 += var26;
						}
						var13 += var17;
						var14 += var18;
						var15 += var19;
						var16 += var20;
					}
				}
			}
		}
	}

	@Override
	public void replaceSurfaceBlocks(final int par1, final int par2, final byte[] abyte0) {
		for (int var5 = 0; var5 < 16; ++var5) {
			for (int var6 = 0; var6 < 16; ++var6) {
				final byte var7 = 1;
				int var8 = -1;
				byte var9 = (byte) Block.grass.blockID;
				byte var10 = (byte) Block.dirt.blockID;
				for (int var11 = 127; var11 >= 0; --var11) {
					final int var12 = (var6 * 16 + var5) * 128 + var11;
					final byte var13 = abyte0[var12];
					if (var13 == 0) {
						var8 = -1;
					} else if (var13 == Block.stone.blockID) {
						if (var8 == -1) {
							var8 = var7;
							abyte0[var12] = var9;
						} else if (var8 > 0) {
							--var8;
							abyte0[var12] = var10;
						}
					}
				}
			}
		}
	}

	@Override
	protected double[] initializeNoiseField(double[] par1ArrayOfDouble, int par2, int par3, int par4, int par5,
			int par6, int par7) {
		if (par1ArrayOfDouble == null) {
			par1ArrayOfDouble = new double[par5 * par6 * par7];
		}
		final float[] adFloat = new float[par1ArrayOfDouble.length];
		for (int i2 = 0; i2 < par1ArrayOfDouble.length; ++i2) {
			adFloat[i2] = (float) par1ArrayOfDouble[i2];
		}
		double var8 = 684.412;
		final double var9 = 684.412;
		this.noise6 = this.noiseGen6.generateNoiseOctaves(this.noise6, par2, par3, par4, par5, par6, par7, 1.121, 1.121,
				0.5);
		this.noise7 = this.noiseGen7.generateNoiseOctaves(this.noise7, par2, par3, par4, par5, par6, par7, 200.0, 200.0,
				0.5);
		var8 *= 2.0;
		this.noise3 = this.noiseGen3.generateNoiseOctaves(this.noise3, par2, par3, par4, par5, par6, par7, var8 / 80.0,
				var9 / 160.0, var8 / 80.0);
		this.noise1 = this.noiseGen1.generateNoiseOctaves(this.noise1, par2, par3, par4, par5, par6, par7, var8, var9,
				var8);
		this.noise2 = this.noiseGen2.generateNoiseOctaves(this.noise2, par2, par3, par4, par5, par6, par7, var8, var9,
				var8);
		int k1 = 0;
		int l1 = 0;
		final int i3 = 16 / par5;
		for (int j2 = 0; j2 < par5; ++j2) {
			final int k2 = j2 * i3 + i3 / 2;
			for (int l2 = 0; l2 < par7; ++l2) {
				final int i4 = l2 * i3 + i3 / 2;
				final double d2 = k2 * 16 + i4;
				final double d3 = (k2 * 16 + i4) * d2;
				double d4 = 1.0 - d3;
				d4 *= d4;
				d4 *= d4;
				d4 = 1.0 - d4;
				double d5 = (this.noise6[l1] + 256.0) / 512.0;
				d5 *= d4;
				if (d5 > 1.0) {
					d5 = 1.0;
				}
				double d6 = this.noise7[l1] / 8000.0;
				if (d6 < 0.0) {
					d6 = -d6 * 0.3;
				}
				d6 = d6 * 3.0 - 2.0;
				if (d6 > 1.0) {
					d6 = 1.0;
				}
				d6 /= 8.0;
				d6 = 0.0;
				if (d5 < 0.0) {
					d5 = 0.0;
				}
				d5 += 0.5;
				d6 = d6 * par6 / 16.0;
				++l1;
				final double d7 = par6 / 2.0;
				for (int j3 = 0; j3 < par6; ++j3) {
					double d8 = 0.0;
					double d9 = (j3 - d7) * 8.0 / d5;
					if (d9 < 0.0) {
						d9 *= -1.0;
					}
					final double d10 = this.noise1[k1] / 512.0;
					final double d11 = this.noise2[k1] / 512.0;
					final double d12 = (this.noise3[k1] / 10.0 + 1.0) / 2.0;
					if (d12 < 0.0) {
						d8 = d10;
					} else if (d12 > 1.0) {
						d8 = d11;
					} else {
						d8 = d10 + (d11 - d10) * d12;
					}
					d8 -= 8.0;
					int k3 = 32;
					if (j3 > par6 - k3) {
						final double d13 = (j3 - (par6 - k3)) / (k3 - 1.0f);
						d8 = d8 * (1.0 - d13) + -30.0 * d13;
					}
					k3 = 8;
					if (j3 < k3) {
						final double d14 = (k3 - j3) / (k3 - 1.0f);
						d8 = d8 * (1.0 - d14) + -30.0 * d14;
					}
					par1ArrayOfDouble[k1] = d8;
					++k1;
				}
			}
		}
		return par1ArrayOfDouble;
	}
	
	@Override
	protected void genStructures(IChunkProvider world, int chunkX, int chunkZ) {
		int i, x, y, z;
		int x0 = chunkX * 16;
		int z0 = chunkZ * 16;
		
		for(i = 0; i < 8; ++i) {
			x = x0 + this.rand.nextInt(16) + 8;
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenDungeons()).generate(this.worldObj, this.rand, x, y, z);
		}
		
		for(i = 0; i < 8; ++i) {
			x = x0 + this.rand.nextInt(16) + 8;
			y = this.rand.nextInt(65536);
			z = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenFloatingDungeons()).generate(this.worldObj, this.rand, x, y, z);
		}
	}

	@Override
	protected void genMinable(IChunkProvider world, int chunkX, int chunkZ) {
		int i, x, y, z;
		int x0 = chunkX * 16;
		int z0 = chunkZ * 16;
		
		for(i = 0; i < 20; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.dirt.blockID, 32)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 16; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.sand.blockID, 32)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 16; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.gravel.blockID, 32)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 20; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreCoal.blockID, 16)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 20; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(64);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreIron.blockID, 8)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 2; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(32);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreGold.blockID, 8)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 8; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(32);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreRedstone.blockID, 7)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 1; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(32);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreDiamond.blockID, 7)).generate(this.worldObj, this.rand, x, y, z);
		}

	}
}
