package net.minecraft.src;

public class Globals {
	public static int maxLightingRecursion = 8;
}
