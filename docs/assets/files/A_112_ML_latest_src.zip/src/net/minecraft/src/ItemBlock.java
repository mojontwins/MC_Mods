package net.minecraft.src;

public class ItemBlock extends Item {
	private int blockID;

	public ItemBlock(int id) {
		super(id);
		this.blockID = id + 256;
		this.setIconIndex(Block.blocksList[id + 256].getBlockTextureFromSide(2));
	}

	public boolean onItemUse(ItemStack theStack, EntityPlayer thePlayer, World theWorld, int x, int y, int z, int side) {
		if(theWorld.getBlockId(x, y, z) == Block.snow.blockID) {
			side = 0;
		} else {
			if(side == 0) {
				--y;
			}

			if(side == 1) {
				++y;
			}

			if(side == 2) {
				--z;
			}

			if(side == 3) {
				++z;
			}

			if(side == 4) {
				--x;
			}

			if(side == 5) {
				++x;
			}
		}

		if(theStack.stackSize == 0) {
			return false;
		} else {
			if(theWorld.canBlockBePlacedAt(this.blockID, x, y, z, false)) {
				Block var8 = Block.blocksList[this.blockID];
				if(theWorld.setBlockAndMetadataWithNotify(x, y, z, this.blockID, this.getPlacedBlockMetadata(theStack.getItemDamage()))) {
					Block.blocksList[this.blockID].onBlockPlaced(theWorld, x, y, z, side);
					theWorld.playSoundEffect((double)((float)x + 0.5F), (double)((float)y + 0.5F), (double)((float)z + 0.5F), var8.stepSound.getStepSound(), (var8.stepSound.getVolume() + 1.0F) / 2.0F, var8.stepSound.getPitch() * 0.8F);
					--theStack.stackSize;
				}
			}

			return true;
		}
	}
}
