package net.minecraft.src;

public enum EnumCreatureType {
	monster(EntityMob.class, false),
	creature(EntityAnimal.class, true);

	private final Class creatureClass;
	private final boolean isPeacefulCreature;

	private EnumCreatureType(Class class3,  boolean z6) {
		this.creatureClass = class3;
		this.isPeacefulCreature = z6;
	}

	public Class getCreatureClass() {
		return this.creatureClass;
	}

	public boolean getPeacefulCreature() {
		return this.isPeacefulCreature;
	}
}
