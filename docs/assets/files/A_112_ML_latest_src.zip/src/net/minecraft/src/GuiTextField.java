package net.minecraft.src;

public class GuiTextField extends Gui {
	private final FontRenderer fontRenderer;
	private final int xPos;
	private final int yPos;
	private final int width;
	private final int height;
	private String text;
	private int maxStringLength;
	private int cursorCounter;
	public boolean isFocused = false;
	public boolean isEnabled = true;
	private GuiScreen parentGuiScreen;

	public GuiTextField(GuiScreen guiScreen1, FontRenderer fontRenderer2, int i3, int i4, int i5, int i6, String string7) {
		this.setParentGuiScreen(guiScreen1);
		this.fontRenderer = fontRenderer2;
		this.xPos = i3;
		this.yPos = i4;
		this.width = i5;
		this.height = i6;
		this.setText(string7);
	}

	public void setText(String string1) {
		this.text = string1;
	}

	public String getText() {
		return this.text;
	}

	public void updateCursorCounter() {
		++this.cursorCounter;
	}

	public void textboxKeyTyped(char c1, int i2) {
		if(this.isEnabled && this.isFocused) {
			if(c1 == 22) {
				String string3 = GuiScreen.getClipboardString();
				if(string3 == null) {
					string3 = "";
				}

				int i4 = 32 - this.text.length();
				if(i4 > string3.length()) {
					i4 = string3.length();
				}

				if(i4 > 0) {
					this.text = this.text + string3.substring(0, i4);
				}
			}

			if(i2 == 14 && this.text.length() > 0) {
				this.text = this.text.substring(0, this.text.length() - 1);
			}

			if(" !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_\'abcdefghijklmnopqrstuvwxyz{|}~\u2302\u00c7\u00fc\u00e9\u00e2\u00e4\u00e0\u00e5\u00e7\u00ea\u00eb\u00e8\u00ef\u00ee\u00ec\u00c4\u00c5\u00c9\u00e6\u00c6\u00f4\u00f6\u00f2\u00fb\u00f9\u00ff\u00d6\u00dc\u00f8\u00a3\u00d8\u00d7\u0192\u00e1\u00ed\u00f3\u00fa\u00f1\u00d1\u00aa\u00ba\u00bf\u00ae\u00ac\u00bd\u00bc\u00a1\u00ab\u00bb".indexOf(c1) >= 0 && (this.text.length() < this.maxStringLength || this.maxStringLength == 0)) {
				this.text = this.text + c1;
			}

		}
	}

	public void mouseClicked(int i1, int i2, int i3) {
		boolean z4 = this.isEnabled && i1 >= this.xPos && i1 < this.xPos + this.width && i2 >= this.yPos && i2 < this.yPos + this.height;
		this.setFocused(z4);
	}

	public void setFocused(boolean z1) {
		if(z1 && !this.isFocused) {
			this.cursorCounter = 0;
		}

		this.isFocused = z1;
	}

	public void drawTextBox() {
		this.drawRect(this.xPos - 1, this.yPos - 1, this.xPos + this.width + 1, this.yPos + this.height + 1, -6250336);
		this.drawRect(this.xPos, this.yPos, this.xPos + this.width, this.yPos + this.height, 0xFF000000);
		if(this.isEnabled) {
			boolean z1 = this.isFocused && this.cursorCounter / 6 % 2 == 0;
			this.drawString(this.fontRenderer, this.text + (z1 ? "_" : ""), this.xPos + 4, this.yPos + (this.height - 8) / 2, 14737632);
		} else {
			this.drawString(this.fontRenderer, this.text, this.xPos + 4, this.yPos + (this.height - 8) / 2, 7368816);
		}

	}

	public void setMaxStringLength(int i1) {
		this.maxStringLength = i1;
	}

	public GuiScreen getParentGuiScreen() {
		return parentGuiScreen;
	}

	public void setParentGuiScreen(GuiScreen parentGuiScreen) {
		this.parentGuiScreen = parentGuiScreen;
	}
}
