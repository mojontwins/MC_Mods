package net.minecraft.src;

public class SlotFurnace extends SlotInventory {
	private EntityPlayer thePlayer;
	
	public SlotFurnace(EntityPlayer thePlayer, GuiContainer var1, IInventory var2, int var3, int var4, int var5) {
		super(var1, var2, var3, var4, var5);
	}
	
	public void onPickupFromSlot(ItemStack stack) {
		ModLoader.takenFromFurnace(this.thePlayer, stack);
		super.onPickupFromSlot(stack);
	}
}
