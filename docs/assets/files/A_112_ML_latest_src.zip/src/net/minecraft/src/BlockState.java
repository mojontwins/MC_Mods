package net.minecraft.src;

public class BlockState {
	public Block block;
	public int meta;
	
	public BlockState(Block b, int meta) {
		this.block = b;
		this.meta = meta;
	}
	
	public BlockState(int id, int meta) {
		this.block = Block.blocksList[id];
		this.meta = meta;
	}
}
