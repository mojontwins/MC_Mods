package net.minecraft.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class RegionFileCache {
	private static final Map<File, SoftReference<RegionFile>> cache = new HashMap<File, SoftReference<RegionFile>>();

	public static synchronized RegionFile getRegionFile(File basePath, int x, int z) {
		File regionDir = new File(basePath, "region");
		File file = new File(regionDir, "r." + (x >> 5) + "." + (z >> 5) + ".data");
		Reference<RegionFile> ref = (Reference<RegionFile>)cache.get(file);
		if(ref != null && ref.get() != null) {
			return (RegionFile)ref.get();
		} else {
			if(!regionDir.exists()) {
				regionDir.mkdirs();
			}

			RegionFile reg = new RegionFile(file);
			cache.put(file, new SoftReference<RegionFile>(reg));
			return reg;
		}
	}

	public static synchronized void clear() {
		Iterator<SoftReference<RegionFile>> i$ = cache.values().iterator();

		while(i$.hasNext()) {
			Reference<RegionFile> ref = (Reference<RegionFile>)i$.next();

			try {
				if(ref.get() != null) {
					((RegionFile)ref.get()).close();
				}
			} catch (IOException iOException3) {
				iOException3.printStackTrace();
			}
		}

		cache.clear();
	}

	public static int getSizeDelta(File basePath, int x, int z) {
		RegionFile r = getRegionFile(basePath, x, z);
		return r.getSizeDelta();
	}

	public static DataInputStream getChunkDataInputStream(File basePath, int x, int z) {
		RegionFile r = getRegionFile(basePath, x, z);
		return r.getChunkDataInputStream(x & 31, z & 31);
	}

	public static DataOutputStream getChunkDataOutputStream(File basePath, int x, int z) {
		RegionFile r = getRegionFile(basePath, x, z);
		return r.getChunkDataOutputStream(x & 31, z & 31);
	}
}
