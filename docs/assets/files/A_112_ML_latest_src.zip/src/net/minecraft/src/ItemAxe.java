package net.minecraft.src;

public class ItemAxe extends ItemTool {
	private static BlockState[] blocksEffectiveAgainst = new BlockState[]{
			new BlockState(Block.planks, -1),  
			new BlockState(Block.bookshelf, -1),  
			new BlockState(Block.wood, -1),  
			new BlockState(Block.chest, -1), 
			new BlockState(Block.sapling, -1), 
			new BlockState(Block.sponge, -1), 
			new BlockState(Block.cloth, -1), 
			new BlockState(Block.tnt, -1), 
			new BlockState(Block.torch, -1), 
			new BlockState(Block.stairCompactWood, -1), 
			new BlockState(Block.workbench, -1), 
			new BlockState(Block.signStanding, -1), 
			new BlockState(Block.signWall, -1), 
			new BlockState(Block.doorWood, -1), 
			new BlockState(Block.pressurePlateWood, -1), 
			new BlockState(Block.jukebox, -1), 
			new BlockState(Block.fence, -1),
			new BlockState(Block.stairSingle, 1),
			new BlockState(Block.stairDouble, 1),
	};

	public ItemAxe(int var1, int var2) {
		super(var1, 3, var2, blocksEffectiveAgainst);
	}
}
