package net.minecraft.src;

import org.mojontwins.retroterrain.ChunkProviderGenerateAlpha;
import org.mojontwins.retroterrain.ChunkProviderGenerateBeta;
import org.mojontwins.retroterrain.ChunkProviderGenerateInfdev;
import org.mojontwins.retroterrain.WorldChunkManagerBeta;

public abstract class WorldProvider {
	public World worldObj;
	public EnumWorldType field_46120_b;
	public WorldChunkManager worldChunkMgr;
	public boolean canSleepInWorld = false;
	public boolean isHellWorld = false;
	public boolean hasNoSky = false;
	public float[] lightBrightnessTable = new float[16];
	public int worldType = 0;
	private float[] colorsSunriseSunset = new float[4];

	public final void registerWorld(World world1) {
		this.worldObj = world1;
		this.field_46120_b = world1.getWorldInfo().func_46069_q();
		this.registerWorldChunkManager();
		this.generateLightBrightnessTable();
	}

	protected void generateLightBrightnessTable() {
		float f1 = 0.0F;

		for(int i2 = 0; i2 <= 15; ++i2) {
			float f3 = 1.0F - (float)i2 / 15.0F;
			this.lightBrightnessTable[i2] = (1.0F - f3) / (f3 * 3.0F + 1.0F) * (1.0F - f1) + f1;
		}

	}

	protected void registerWorldChunkManager() {
		if(this.worldObj.getWorldInfo().func_46069_q() == EnumWorldType.FLAT) {
			this.worldChunkMgr = new WorldChunkManagerHell(BiomeGenBase.plains, 0.5F, 0.5F);
		} else if(this.worldObj.getWorldInfo().func_46069_q() == EnumWorldType.BETA || this.worldObj.getWorldInfo().func_46069_q() == EnumWorldType.ALPHA || this.worldObj.getWorldInfo().func_46069_q() == EnumWorldType.INFDEV) {
			this.worldChunkMgr = new WorldChunkManagerBeta (this.worldObj);
		} else {
			this.worldChunkMgr = new WorldChunkManager(this.worldObj);
		}

	}

	public IChunkProvider getChunkProvider() {
		if (this.field_46120_b == EnumWorldType.FLAT) {
			return new ChunkProviderFlat(this.worldObj, this.worldObj.getRandomSeed(), this.worldObj.getWorldInfo().isMapFeaturesEnabled());
		} else if (this.field_46120_b == EnumWorldType.BETA) {
			return new ChunkProviderGenerateBeta(this.worldObj, this.worldObj.getRandomSeed(), this.worldObj.getWorldInfo().isMapFeaturesEnabled());
		} else if (this.field_46120_b == EnumWorldType.ALPHA) {
			return new ChunkProviderGenerateAlpha(this.worldObj, this.worldObj.getRandomSeed(), this.worldObj.getWorldInfo().isMapFeaturesEnabled());
		} else if (this.field_46120_b == EnumWorldType.INFDEV) {
			return new ChunkProviderGenerateInfdev(this.worldObj, this.worldObj.getRandomSeed(), this.worldObj.getWorldInfo().isMapFeaturesEnabled());	
		} else {
			return new ChunkProviderGenerate(this.worldObj, this.worldObj.getRandomSeed(), this.worldObj.getWorldInfo().isMapFeaturesEnabled()); 
		}
	}

	public boolean canCoordinateBeSpawn(int i1, int i2) {
		int i3 = this.worldObj.getFirstUncoveredBlock(i1, i2);
		return i3 == Block.grass.blockID;
	}

	public float calculateCelestialAngle(long j1, float f3) {
		int i4 = (int)(j1 % 24000L);
		float f5 = ((float)i4 + f3) / 24000.0F - 0.25F;
		if(f5 < 0.0F) {
			++f5;
		}

		if(f5 > 1.0F) {
			--f5;
		}

		float f6 = f5;
		f5 = 1.0F - (float)((Math.cos((double)f5 * Math.PI) + 1.0D) / 2.0D);
		f5 = f6 + (f5 - f6) / 3.0F;
		return f5;
	}

	public boolean canRespawnHere() {
		return true;
	}

	public static WorldProvider getProviderForDimension(int i0) {
		return (WorldProvider)(i0 == -1 ? new WorldProviderHell() : (i0 == 0 ? new WorldProviderSurface() : (i0 == 1 ? new WorldProviderEnd() : null)));
	}

	public ChunkCoordinates getEntrancePortalLocation() {
		return null;
	}

	public int func_46119_e() {
		return this.field_46120_b == EnumWorldType.FLAT ? 4 : this.worldObj.worldHeight / 2;
	}
}
