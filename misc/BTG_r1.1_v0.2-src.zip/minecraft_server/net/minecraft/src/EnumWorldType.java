package net.minecraft.src;

public enum EnumWorldType {
	DEFAULT("default"),
	FLAT("flat"),
	BETA("beta"),
	ALPHA("alpha"),
	INFDEV("infdev");

	public String name;

	private EnumWorldType(String string3) {
		this.name = string3;
	}

	public static EnumWorldType func_46049_a(String string0) {
		EnumWorldType[] enumWorldType1 = values();
		int i2 = enumWorldType1.length;

		for(int i3 = 0; i3 < i2; ++i3) {
			EnumWorldType enumWorldType4 = enumWorldType1[i3];
			if(enumWorldType4.name().equals(string0)) {
				return enumWorldType4;
			}
		}

		return null;
	}
}
