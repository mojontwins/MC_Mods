package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WorldChunkManager {
	private GenLayer field_34907_a;
	private GenLayer field_34906_b;
	private GenLayer temperatureLayer;
	private GenLayer rainfallLayer;
	public BiomeCache biomeCache;
	private List biomesToSpawnIn;
	public float[] temperatureCache;

	protected WorldChunkManager() {
		this.biomeCache = new BiomeCache(this);
		this.biomesToSpawnIn = new ArrayList();
		this.biomesToSpawnIn.add(BiomeGenBase.forest);
		this.biomesToSpawnIn.add(BiomeGenBase.plains);
		this.biomesToSpawnIn.add(BiomeGenBase.taiga);
		this.biomesToSpawnIn.add(BiomeGenBase.field_46081_u);
		this.biomesToSpawnIn.add(BiomeGenBase.field_46082_t);
	}

	public WorldChunkManager(World world1) {
		this();
		GenLayer[] genLayer2 = GenLayer.func_35019_a(world1.getRandomSeed());
		this.field_34907_a = genLayer2[0];
		this.field_34906_b = genLayer2[1];
		this.temperatureLayer = genLayer2[2];
		this.rainfallLayer = genLayer2[3];
	}

	public List getBiomesToSpawnIn() {
		return this.biomesToSpawnIn;
	}

	public BiomeGenBase getBiomeGenAtChunkCoord(ChunkCoordIntPair chunkCoordIntPair1) {
		return this.getBiomeGenAt(chunkCoordIntPair1.chunkXPos << 4, chunkCoordIntPair1.chunkZPos << 4);
	}

	public BiomeGenBase getBiomeGenAt(int i1, int i2) {
		return this.biomeCache.getBiomeGenAt(i1, i2);
	}

	public float[] getRainfall(float[] f1, int i2, int i3, int i4, int i5) {
		IntCache.resetIntCache();
		if(f1 == null || f1.length < i4 * i5) {
			f1 = new float[i4 * i5];
		}

		int[] i6 = this.rainfallLayer.getInts(i2, i3, i4, i5);

		for(int i7 = 0; i7 < i4 * i5; ++i7) {
			float f8 = (float)i6[i7] / 65536.0F;
			if(f8 > 1.0F) {
				f8 = 1.0F;
			}

			f1[i7] = f8;
		}

		return f1;
	}

	public float getTemperature(int i1, int i2, int i3) {
		return this.getTemperatureAtHeight(this.biomeCache.getTemperature(i1, i3), i2);
	}

	public float getTemperatureAtHeight(float f1, int i2) {
		return f1;
	}

	public float[] initTemperatureCache(int i1, int i2, int i3, int i4) {
		this.temperatureCache = this.getTemperatures(this.temperatureCache, i1, i2, i3, i4);
		return this.temperatureCache;
	}

	public float[] getTemperatures(float[] f1, int i2, int i3, int i4, int i5) {
		IntCache.resetIntCache();
		if(f1 == null || f1.length < i4 * i5) {
			f1 = new float[i4 * i5];
		}

		int[] i6 = this.temperatureLayer.getInts(i2, i3, i4, i5);

		for(int i7 = 0; i7 < i4 * i5; ++i7) {
			float f8 = (float)i6[i7] / 65536.0F;
			if(f8 > 1.0F) {
				f8 = 1.0F;
			}

			f1[i7] = f8;
		}

		return f1;
	}

	public BiomeGenBase[] func_35142_b(BiomeGenBase[] biomeGenBase1, int i2, int i3, int i4, int i5) {
		IntCache.resetIntCache();
		if(biomeGenBase1 == null || biomeGenBase1.length < i4 * i5) {
			biomeGenBase1 = new BiomeGenBase[i4 * i5];
		}

		int[] i6 = this.field_34907_a.getInts(i2, i3, i4, i5);

		for(int i7 = 0; i7 < i4 * i5; ++i7) {
			biomeGenBase1[i7] = BiomeGenBase.biomeList[i6[i7]];
		}

		return biomeGenBase1;
	}

	public BiomeGenBase[] loadBlockGeneratorData(BiomeGenBase[] biomeGenBase1, int i2, int i3, int i4, int i5) {
		return this.getBiomeGenAt(biomeGenBase1, i2, i3, i4, i5, true);
	}

	public BiomeGenBase[] getBiomeGenAt(BiomeGenBase[] biomeGenBase1, int i2, int i3, int i4, int i5, boolean z6) {
		IntCache.resetIntCache();
		if(biomeGenBase1 == null || biomeGenBase1.length < i4 * i5) {
			biomeGenBase1 = new BiomeGenBase[i4 * i5];
		}

		if(z6 && i4 == 16 && i5 == 16 && (i2 & 15) == 0 && (i3 & 15) == 0) {
			BiomeGenBase[] biomeGenBase9 = this.biomeCache.getCachedBiomes(i2, i3);
			System.arraycopy(biomeGenBase9, 0, biomeGenBase1, 0, i4 * i5);
			return biomeGenBase1;
		} else {
			int[] i7 = this.field_34906_b.getInts(i2, i3, i4, i5);

			for(int i8 = 0; i8 < i4 * i5; ++i8) {
				biomeGenBase1[i8] = BiomeGenBase.biomeList[i7[i8]];
			}

			return biomeGenBase1;
		}
	}

	public boolean areBiomesViable(int i1, int i2, int i3, List list4) {
		int i5 = i1 - i3 >> 2;
		int i6 = i2 - i3 >> 2;
		int i7 = i1 + i3 >> 2;
		int i8 = i2 + i3 >> 2;
		int i9 = i7 - i5 + 1;
		int i10 = i8 - i6 + 1;
		int[] i11 = this.field_34907_a.getInts(i5, i6, i9, i10);

		for(int i12 = 0; i12 < i9 * i10; ++i12) {
			BiomeGenBase biomeGenBase13 = BiomeGenBase.biomeList[i11[i12]];
			if(!list4.contains(biomeGenBase13)) {
				return false;
			}
		}

		return true;
	}

	public ChunkPosition func_35139_a(int i1, int i2, int i3, List list4, Random random5) {
		int i6 = i1 - i3 >> 2;
		int i7 = i2 - i3 >> 2;
		int i8 = i1 + i3 >> 2;
		int i9 = i2 + i3 >> 2;
		int i10 = i8 - i6 + 1;
		int i11 = i9 - i7 + 1;
		int[] i12 = this.field_34907_a.getInts(i6, i7, i10, i11);
		ChunkPosition chunkPosition13 = null;
		int i14 = 0;

		for(int i15 = 0; i15 < i12.length; ++i15) {
			int i16 = i6 + i15 % i10 << 2;
			int i17 = i7 + i15 / i10 << 2;
			BiomeGenBase biomeGenBase18 = BiomeGenBase.biomeList[i12[i15]];
			if(list4.contains(biomeGenBase18) && (chunkPosition13 == null || random5.nextInt(i14 + 1) == 0)) {
				chunkPosition13 = new ChunkPosition(i16, 0, i17);
				++i14;
			}
		}

		return chunkPosition13;
	}

	public void cleanupCache() {
		this.biomeCache.cleanupCache();
	}
}
