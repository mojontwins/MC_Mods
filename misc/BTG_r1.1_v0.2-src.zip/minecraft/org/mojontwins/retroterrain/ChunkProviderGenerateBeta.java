package org.mojontwins.retroterrain;

import net.minecraft.src.World;

public class ChunkProviderGenerateBeta extends ChunkProviderGenerateRetro {

	public ChunkProviderGenerateBeta(World world1, long j2, boolean z4) {
		super(world1, j2, z4);

		System.out.println ("Chunk Provider Beta");
	}

}
