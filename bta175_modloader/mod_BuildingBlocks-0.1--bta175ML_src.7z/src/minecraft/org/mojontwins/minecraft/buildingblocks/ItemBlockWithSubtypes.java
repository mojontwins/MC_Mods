package org.mojontwins.minecraft.buildingblocks;

import net.minecraft.src.Block;
import net.minecraft.src.ItemBlock;
import net.minecraft.src.ItemStack;

public class ItemBlockWithSubtypes extends ItemBlock {
	IBlockWithSubtypes refBlock = null;
	
	// Id is set so it substitutes the ItemBlock
	public ItemBlockWithSubtypes(int id) {
		super(id);
		this.refBlock = (IBlockWithSubtypes) Block.blocksList[id + 256];
		
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	// Placed block metadata as is
	@Override
	public int getPlacedBlockMetadata(int damage) {
		return damage;
	}
	
	// Icon from damage depends on the block type
	@Override
	public int getIconFromDamage(int damage) {
		return refBlock.getIndexInTextureFromMeta(damage);
	}
	
	@Override
	public String getItemNameIS(ItemStack stack) {
		return this.refBlock.getNameFromMeta(stack.getItemDamage());
	}

}
