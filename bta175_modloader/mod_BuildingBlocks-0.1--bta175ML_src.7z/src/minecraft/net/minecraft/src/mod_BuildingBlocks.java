package net.minecraft.src;

import org.mojontwins.minecraft.buildingblocks.BlockCement;
import org.mojontwins.minecraft.buildingblocks.BlockCementPowder;
import org.mojontwins.minecraft.buildingblocks.BlockMoreStones;
import org.mojontwins.minecraft.buildingblocks.BlockSpecialGlass;
import org.mojontwins.minecraft.buildingblocks.EntityFallingCementPowder;
import org.mojontwins.minecraft.buildingblocks.ItemBlockWithSubtypes;

public class mod_BuildingBlocks extends BaseModMp {
	
	@MLProp(name="blockMoreStonesID")
	public static int blockMoreStonesID = 140;
	
	@MLProp(name="blockCementPowderID")
	public static int blockCementPowderID = 141;
	
	@MLProp(name="blockCementID")
	public static int blockCementID = 142;
	
	@MLProp(name="blockSpecialGlassID")
	public static int blockSpecialGlassID = 143;
	
	@MLProp(name="itemIronWireID")
	public static int itemIronWireID = 128;
	
	@MLProp(name="entityFallingCementVehicleID")
	public static int entityFallingCementVehicleID = 128;
	
	public static BlockMoreStones blockMoreStones;
	public static Block blockCementPowder;
	public static BlockCement blockCement;
	public static BlockSpecialGlass blockSpecialGlass;
	
	public static Item itemIronWire;
	
	public mod_BuildingBlocks() {
		
		// Block instantiation
		
		blockMoreStones = (BlockMoreStones) new BlockMoreStones(blockMoreStonesID, Material.rock)
				.withTextures(new int[] {
						0,
						ModLoader.addOverride("/terrain.png", "/mojontwins/stonebricks1.png"),
						109
				})
				.setBlockName("stoneBrick")
				.setHardness(2.0F)
				.setResistance(10.0F)
				.setStepSound(Block.soundStoneFootstep);
		
		ModLoader.RegisterBlock(blockMoreStones, ItemBlockWithSubtypes.class);
		ModLoader.AddLocalization("moreStones.small.name", "Small stone bricks");
		ModLoader.AddLocalization("moreStones.packedCobble.name", "Packed Cobblestone");
		
		blockCementPowder = new BlockCementPowder(
				blockCementPowderID, 
				ModLoader.addOverride("/terrain.png", "/mojontwins/cementpowder0.png"))
				.setBlockName("cementPowder")
				.setHardness(0.8F)
				.setStepSound(Block.soundGravelFootstep);
		
		ModLoader.RegisterBlock(blockCementPowder);
		ModLoader.AddName(blockCementPowder, "Cement Powder");
		
		blockCement = (BlockCement) new BlockCement(blockCementID, Material.sand)
				.withTextures(new int[] {
						ModLoader.addOverride("/terrain.png", "/mojontwins/cement0.png"),
						ModLoader.addOverride("/terrain.png", "/mojontwins/cement1.png"),
						ModLoader.addOverride("/terrain.png", "/mojontwins/cement2.png")
				})
				.setHardness(2.0F)
				.setResistance(10.0F)
				.setStepSound(Block.soundStoneFootstep)
				.setBlockName("cement");
		
		ModLoader.RegisterBlock(blockCement, ItemBlockWithSubtypes.class);
		ModLoader.AddLocalization("cement.normal.name", "Cement");
		ModLoader.AddLocalization("cement.wooden.name", "Cement with wooden frame");
		ModLoader.AddLocalization("cement.metal.name", "Cement with metal frame");
		
		blockSpecialGlass = (BlockSpecialGlass) new BlockSpecialGlass(blockSpecialGlassID)
				.withTextures(new int[] {
						49,
						ModLoader.addOverride("/terrain.png", "/mojontwins/glass1.png"),
						ModLoader.addOverride("/terrain.png", "/mojontwins/glass2.png")
				})
				.setHardness(0.8F)
				.setStepSound(Block.soundGlassFootstep)
				.setBlockName("glass");
		
		ModLoader.RegisterBlock(blockSpecialGlass, ItemBlockWithSubtypes.class);
		ModLoader.AddName(blockSpecialGlass, "Glass");
		ModLoader.AddLocalization("glass.wooden.name", "Glass with wooden frame");
		ModLoader.AddLocalization("glass.metal.name", "Glass with metal frame");
		
		// Item instantiation
		
		itemIronWire = new Item(itemIronWireID)
				.setIconIndex(ModLoader.addOverride("/gui/items.png", "/mojontwins/ironwire.png"))
				.setItemName("ironWire");
		
		ModLoader.AddName(itemIronWire, "Iron wire");
		
		// Recipes
		
		ModLoader.AddRecipe(new ItemStack(blockMoreStones, 4, 1), new Object[]{"##", "##", '#', Block.stoneBrick});
		ModLoader.AddRecipe(new ItemStack(Block.cobblestone, 4, 1), new Object[]{"##", "##", '#', new ItemStack(blockMoreStones, 1, 1)});
		ModLoader.AddRecipe(new ItemStack(blockMoreStones, 4, 2), new Object[]{"##", "##", '#', Block.cobblestone});
		
		ModLoader.AddShapelessRecipe(new ItemStack(blockCementPowder, 2), new Object[] {Block.sand, Block.gravel});
		ModLoader.AddShapelessRecipe(new ItemStack(blockCement, 2, 0), new Object[] {Block.sand, Block.blockClay});
		
		ModLoader.AddShapelessRecipe(new ItemStack(itemIronWire, 4), new Object[] {Item.ingotIron, Item.ingotIron});
		
		ModLoader.AddRecipe(new ItemStack(blockCement, 1, 1), new Object[] {" # ", "#G#", " # ", '#', Item.stick, 'G', new ItemStack(blockCement, 1, 0)});
		ModLoader.AddRecipe(new ItemStack(blockCement, 1, 2), new Object[] {" # ", "#G#", " # ", '#', itemIronWire, 'G', new ItemStack(blockCement, 1, 0)});
		
		ModLoader.AddRecipe(new ItemStack(blockSpecialGlass, 1, 1), new Object[] {" # ", "#G#", " # ", '#', Item.stick, 'G', Block.glass});
		ModLoader.AddRecipe(new ItemStack(blockSpecialGlass, 1, 2), new Object[] {" # ", "#G#", " # ", '#', itemIronWire, 'G', Block.glass});
		
		// Entity Tracker entities
		
		// This is done to place a hook when Packet23VehicleSpawn arrives from the server, so it makes a new
		// EntityFallingCementPowder(world, x, y, z) when the vehicle ID is entityFallingCementVehicleID
		
		ModLoaderMp.RegisterNetClientHandlerEntity(EntityFallingCementPowder.class, false, entityFallingCementVehicleID);
	}

	@Override
	public String Version() {
		return "v1.0.0.0";
	}

}
