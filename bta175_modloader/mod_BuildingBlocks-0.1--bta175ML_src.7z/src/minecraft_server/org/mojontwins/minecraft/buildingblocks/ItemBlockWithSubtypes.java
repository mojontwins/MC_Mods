package org.mojontwins.minecraft.buildingblocks;

import net.minecraft.src.Block;
import net.minecraft.src.ItemBlock;

public class ItemBlockWithSubtypes extends ItemBlock {
	IBlockWithSubtypes refBlock = null;
	
	// Id is set so it substitutes the ItemBlock
	public ItemBlockWithSubtypes(int id) {
		super(id);
		this.refBlock = (IBlockWithSubtypes) Block.blocksList[id + 256];
		
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	// Placed block metadata as is
	@Override
	//public int getPlacedBlockMetadata(int damage) {
	public int getMetadata(int damage) {
		return damage;
	}

}
