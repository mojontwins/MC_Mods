package org.mojontwins.minecraft.buildingblocks;

import net.minecraft.src.EntityFallingSand;
import net.minecraft.src.World;
import net.minecraft.src.mod_BuildingBlocks;

public class EntityFallingCementPowder extends EntityFallingSand {

	public EntityFallingCementPowder(World world) {
		super(world);
	}

	public EntityFallingCementPowder(World world, double x, double y, double z) {
		super(world, x, y, z, mod_BuildingBlocks.blockCementPowder.blockID);
	}

}
