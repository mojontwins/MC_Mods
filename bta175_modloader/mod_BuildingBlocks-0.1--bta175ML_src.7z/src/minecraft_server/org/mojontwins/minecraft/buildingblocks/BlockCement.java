package org.mojontwins.minecraft.buildingblocks;

import net.minecraft.src.Block;
import net.minecraft.src.Material;

public class BlockCement extends Block implements IBlockWithSubtypes {
	private int[] cementTextures = { 11*16, 10*16+15, 10*16+14 };
	private String[] cementNames = {"normal", "wooden", "metal"};

	public BlockCement(int i1, Material material2) {
		super(i1, material2);
	}

	@Override
	public int getBlockTextureFromSideAndMetadata(int side, int meta) {
		return this.cementTextures [meta];
	}

	@Override
	public String getNameFromMeta(int meta) {
		return "cement." + this.cementNames[meta];
	}

	@Override
	public int getIndexInTextureFromMeta(int meta) {
		return this.getBlockTextureFromSideAndMetadata(2, meta);
	}

	@Override
	public Block withTextures(int[] textures) {
		this.cementTextures = textures;
		return this;
	}
	
	@Override
	public int damageDropped(int meta) {
		return meta;
	}
}
