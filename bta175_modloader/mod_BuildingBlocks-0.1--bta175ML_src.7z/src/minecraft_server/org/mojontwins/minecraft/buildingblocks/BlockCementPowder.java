package org.mojontwins.minecraft.buildingblocks;

import java.util.Random;

import net.minecraft.src.BlockSand;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_BuildingBlocks;

public class BlockCementPowder extends BlockSand {

	public BlockCementPowder(int id, int blockIndex) {
		super(id, blockIndex);
	}

	@Override
	public void onBlockAdded(World world, int x, int y, int z) {
		if (!this.tryToBecomeCement(world, x, y, z)) super.onBlockAdded(world, x, y, z);
	}
	
	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, int id) {
		if (!this.tryToBecomeCement(world, x, y, z)) super.onNeighborBlockChange(world, x, y, z, id);
	}
	
	@Override
	public void updateTick(World world, int x, int y, int z, Random rand) {
		if(canFallBelow(world, x, y - 1, z) && y >= 0) {
			byte radius = 32;
			if(!fallInstantly && world.checkChunksExist(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius)) {
				EntityFallingCementPowder entityCementPowder = new EntityFallingCementPowder(world, (double)((float)x + 0.5F), (double)((float)y + 0.5F), (double)((float)z + 0.5F));
				world.entityJoinedWorld(entityCementPowder);
			} else {
				world.setBlockWithNotify(x, y, z, 0);

				while(canFallBelow(world, x, y - 1, z) && y > 0) {
					--y;
				}

				if(y > 0) {
					world.setBlockWithNotify(x, y, z, this.blockID);
				}
			}
		}

	}
	
	public boolean tryToBecomeCement(World world, int x, int y, int z) {
		if (this.isTouchingWater(world, x, y, z)) {
			world.setBlock (x, y, z, mod_BuildingBlocks.blockCement.blockID);
			return true;
		}
		
		return false;
	}
	
	public boolean isTouchingWater(World world, int x, int y, int z) {
		return (
				world.getBlockMaterial(x - 1, y, z) == Material.water || 
				world.getBlockMaterial(x + 1, y, z) == Material.water || 
				world.getBlockMaterial(x, y, z - 1) == Material.water || 
				world.getBlockMaterial(x, y, z + 1) == Material.water ||
				//world.getBlockMaterial(x, y - 1, z) == Material.water ||
				world.getBlockMaterial(x, y + 1, z) == Material.water 
		);
	}
}
