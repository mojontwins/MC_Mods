package org.mojontwins.minecraft.buildingblocks;

import net.minecraft.src.Block;

public interface IBlockWithSubtypes {
	public String getNameFromMeta(int meta);
	public int getIndexInTextureFromMeta(int meta);
	public Block withTextures(int[] textures);
}
