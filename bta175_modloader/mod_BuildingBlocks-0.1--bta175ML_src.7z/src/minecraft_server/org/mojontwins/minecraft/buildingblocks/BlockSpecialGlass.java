package org.mojontwins.minecraft.buildingblocks;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.BlockGlass;
import net.minecraft.src.Item;
import net.minecraft.src.Material;
import net.minecraft.src.mod_BuildingBlocks;

public class BlockSpecialGlass extends BlockGlass implements IBlockWithSubtypes {
	private int[] glassTextures = { 11*16, 10*16+15, 10*16+14 };
	private String[] glassNames = {"normal", "wooden", "metal"};
	
	public BlockSpecialGlass(int i) {
		super(i, Block.glass.blockID, Material.glass, false);
	}

	@Override
	public int idDropped(int meta, Random random) {
		switch(meta) {
		case 1: return Item.stick.shiftedIndex;
		case 2: return mod_BuildingBlocks.itemIronWire.shiftedIndex;
		}
		
		return -1;
	}
	
	@Override
	public int quantityDropped(int meta, Random random) {
		return 4;
	}

	@Override
	public int getBlockTextureFromSideAndMetadata(int side, int meta) {
		return this.glassTextures [meta];
	}

	@Override
	public String getNameFromMeta(int meta) {
		return "glass." + this.glassNames[meta];
	}

	@Override
	public int getIndexInTextureFromMeta(int meta) {
		return this.getBlockTextureFromSideAndMetadata(2, meta);
	}

	@Override
	public Block withTextures(int[] textures) {
		this.glassTextures = textures;
		return this;
	}
	
}
