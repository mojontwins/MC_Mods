package org.mojontwins.minecraft.buildingblocks;

import net.minecraft.src.Block;
import net.minecraft.src.Material;

public class BlockMoreStones extends Block implements IBlockWithSubtypes {

	public String names[] = new String[] {
			"normal", "small", "packedCobble"
	};
	public int[] brickTextures;

	public BlockMoreStones(int i1, Material material2) {
		super(i1, material2);
	}

	@Override
	public int getBlockTextureFromSideAndMetadata(int side, int meta) {
		if(meta >= this.brickTextures.length) meta = 0;
		return this.brickTextures [meta];
	}

	@Override
	public String getNameFromMeta(int meta) {
		return "moreStones." + this.names[meta];
	}

	@Override
	public int getIndexInTextureFromMeta(int meta) {
		return this.getBlockTextureFromSideAndMetadata(2, meta);
	}

	@Override
	public Block withTextures(int[] textures) {
		this.brickTextures = textures;
		return this;
	}

}
