package net.minecraft.src;

import org.mojontwins.minecraft.more176blocks.BlockLamp;
import org.mojontwins.minecraft.more176blocks.BlockMarble;
import org.mojontwins.minecraft.more176blocks.BlockPaintablePlanks;
import org.mojontwins.minecraft.more176blocks.BlockTintedGlass;
import org.mojontwins.minecraft.more176blocks.BlockTrommel;
import org.mojontwins.minecraft.more176blocks.ItemLamp;
import org.mojontwins.minecraft.more176blocks.ItemMarble;
import org.mojontwins.minecraft.more176blocks.ItemPaintablePlanks;
import org.mojontwins.minecraft.more176blocks.TileEntityTrommel;

public class mod_more176Blocks extends BaseModMp {

	@MLProp(name="blockPaintablePlanksID")
	public static int blockPaintablePlanksID = 144;
	
	@MLProp(name="blockLampActiveID")
	public static int blockLampActiveID = 145;
	
	@MLProp(name="blockLampIdleID")
	public static int blockLampIdleID = 146;
	
	@MLProp(name="blockMarbleID")
	public static int blockMarbleID = 147;
	
	@MLProp(name="blockTintedGlassID")
	public static int blockTintedGlassID = 148;
	
	@MLProp(name="blockTrapDoorIron")
	public static int blockTrapDoorIronID = 149;
	
	@MLProp(name="blockTrommelIdleID")
	public static int blockTrommelIdleID = 150;
	
	@MLProp(name="blockTrommelActiveID")
	public static int blockTrommelActiveID = 151;
	
	@MLProp(name="itemQuartzID")
	public static int itemQuartzID = 129;
	
	@MLProp(name="itemOlivineID")
	public static int itemOlivineID = 130;
	
	@MLProp(name="itemIronNuggetID")
	public static int itemIronNuggetID = 131;
	
	@MLProp(name="itemGoldNuggetID")
	public static int itemGoldNuggetID = 132;
	
	@MLProp(name="guiTrommelID", info="ID for the Trommel GUI")
	public static int guiTrommelID = 102;
	
	public static Block blockPaintablePlanks;
	public static Block blockLampActive;
	public static Block blockLampIdle;
	public static BlockMarble blockMarble;
	public static Block blockTintedGlass;
	public static Block blockTrapDoorIron;
	public static BlockTrommel blockTrommelIdle;
	public static BlockTrommel blockTrommelActive;
	
	public static Item itemQuartz;
	public static Item itemOlivine;
	public static Item itemIronNugget;
	public static Item itemGoldNugget;

	public mod_more176Blocks() {
		
		// Blocks
		
		blockPaintablePlanks = new BlockPaintablePlanks(
				blockPaintablePlanksID,
				ModLoader.addOverride("/terrain.png", "/mojontwins/paintableplanks0.png"))
				.setHardness(2.0F)
				.setResistance(5.0F)
				.setStepSound(Block.soundWoodFootstep);
		
		ModLoader.RegisterBlock(blockPaintablePlanks, ItemPaintablePlanks.class);
		
		blockLampActive = new BlockLamp(
				blockLampActiveID,
				ModLoader.addOverride("/terrain.png", "/mojontwins/lamp0.png"),
				true)
				.setHardness(0.5F)
				.setStepSound(Block.soundGlassFootstep)
				.disableStats()
				.setLightValue(1.0F)
				.setBlockName("lampActive");
		
		ModLoader.RegisterBlock(blockLampActive);
		
		blockLampIdle = new BlockLamp(
				blockLampIdleID,
				ModLoader.addOverride("/terrain.png", "/mojontwins/lamp1.png"),
				false)
				.setHardness(0.5F)
				.setStepSound(Block.soundGlassFootstep)
				.disableStats()
				.setBlockName("lampIdle");
		
		ModLoader.RegisterBlock(blockLampIdle, ItemLamp.class);
		
		blockMarble = (BlockMarble) new BlockMarble(blockMarbleID)
				.withTextures(new int[] {
						ModLoader.addOverride("/terrain.png", "/mojontwins/marble0.png"),
						ModLoader.addOverride("/terrain.png", "/mojontwins/marble1.png"),
						ModLoader.addOverride("/terrain.png", "/mojontwins/marble2.png"),
						ModLoader.addOverride("/terrain.png", "/mojontwins/marble3.png"),
				})
				.setHardness(1.0F)
				.setStepSound(Block.soundStoneFootstep)
				.setBlockName("marble");
		
		ModLoader.RegisterBlock(blockMarble, ItemMarble.class);
		
		blockTintedGlass = new BlockTintedGlass(
				blockTintedGlassID,
				ModLoader.addOverride("/terrain.png", "/mojontwins/tintedglass0.png"))
				.setHardness(0.5F)
				.setStepSound(Block.soundGlassFootstep)
				.disableStats()
				.setBlockName("tintedGlass");
		
		ModLoader.RegisterBlock(blockTintedGlass);
		
		blockTrapDoorIron = new BlockTrapDoor(blockTrapDoorIronID, Material.iron)
				.setHardness(3.0F)
				.setStepSound(Block.soundMetalFootstep)
				.disableStats()
				.setBlockName("trapdoorIron");
		blockTrapDoorIron.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/mojontwins/trapdooriron0.png");
		
		ModLoader.RegisterBlock(blockTrapDoorIron);
		
		int trommel0 = ModLoader.addOverride("/terrain.png", "/mojontwins/trommel0.png");
		int trommel1 = ModLoader.addOverride("/terrain.png", "/mojontwins/trommel1.png");
		int trommel2 = ModLoader.addOverride("/terrain.png", "/mojontwins/trommel2.png");
		int trommel3 = ModLoader.addOverride("/terrain.png", "/mojontwins/trommel3.png");
		
		blockTrommelIdle = (BlockTrommel) new BlockTrommel(blockTrommelIdleID, false)
				.withTextures(trommel0, trommel1, trommel2)
				.setHardness(3.5f)
				.setStepSound(Block.soundStoneFootstep)
				.setBlockName("trommelIdle");
		
		ModLoader.RegisterBlock(blockTrommelIdle);
		
		blockTrommelActive = (BlockTrommel) new BlockTrommel(blockTrommelActiveID, true)
				.withTextures(trommel0, trommel1, trommel3)
				.setHardness(3.5f)
				.setStepSound(Block.soundStoneFootstep)
				.setBlockName("trommelActive");
		
		ModLoader.RegisterBlock(blockTrommelActive);
				
		// Items
		
		itemQuartz = new Item(itemQuartzID)
				.setIconIndex(ModLoader.addOverride("/gui/items.png", "/mojontwins/quartz0.png"))
				.setItemName("quartz");
		
		itemOlivine = new Item(itemOlivineID)
				.setIconIndex(ModLoader.addOverride("/gui/items.png", "/mojontwins/olivine0.png"))
				.setItemName("olivine");
		
		itemIronNugget = new Item(itemIronNuggetID)
				.setIconIndex(ModLoader.addOverride("/gui/items.png", "/mojontwins/ironnugget0.png"))
				.setItemName("ironNugget");
		
		itemGoldNugget = new Item(itemGoldNuggetID)
				.setIconIndex(ModLoader.addOverride("/gui/items.png", "/mojontwins/goldnugget0.png"))
				.setItemName("goldNugget");
		
		// Recipes
		
		for (int i = 0; i < 16; ++i) {
			ModLoader.AddShapelessRecipe(
					new ItemStack(blockPaintablePlanks, 1, i), 
					new Object[] {
						new ItemStack(Item.dyePowder, 1, ~i & 15), 
						Block.planks
			});
			
			ModLoader.AddShapelessRecipe(
					new ItemStack(blockPaintablePlanks, 1, i), 
					new Object[] {
						new ItemStack(Item.dyePowder, 1, i), 
						new ItemStack(blockPaintablePlanks, 1, -1)
			});
		}
	
		// Replicate all recipes that involve planks
		
		ModLoader.AddRecipe(new ItemStack(Block.jukebox, 1), new Object[]{"###", "#X#", "###", '#', blockPaintablePlanks, 'X', Item.diamond});
		ModLoader.AddRecipe(new ItemStack(Block.musicBlock, 1), new Object[]{"###", "#X#", "###", '#', blockPaintablePlanks, 'X', Item.redstone});
		ModLoader.AddRecipe(new ItemStack(Block.bookShelf, 1), new Object[]{"###", "XXX", "###", '#', blockPaintablePlanks, 'X', Item.book});
		ModLoader.AddRecipe(new ItemStack(Block.slabPlanks, 3), new Object[]{"###", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Item.doorWood, 1), new Object[]{"##", "##", "##", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Block.trapdoor, 2), new Object[]{"###", "###", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Item.sign, 1), new Object[]{"###", "###", " X ", '#', blockPaintablePlanks, 'X', Item.stick});
		ModLoader.AddRecipe(new ItemStack(Item.stick, 4), new Object[]{"#", "#", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Item.bowlEmpty, 4), new Object[]{"# #", " # ", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Item.boat, 1), new Object[]{"# #", "###", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Block.stairCompactPlanks, 4), new Object[]{"#  ", "## ", "###", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Block.pressurePlatePlanks, 1), new Object[]{"##", '#', blockPaintablePlanks});
		ModLoader.AddRecipe(new ItemStack(Item.bed, 1), new Object[]{"YY#", "XXX", '#', Block.cloth, 'X', blockPaintablePlanks, 'Y', Item.cloth});
		ModLoader.AddRecipe(new ItemStack(Block.fenceGate, 1), new Object[]{"#X#", "#X#", '#', blockPaintablePlanks, 'X', Item.stick});
		
		ModLoader.AddBlastSmelting(Block.graniteCobble.blockID, new ItemStack(itemQuartz));
		ModLoader.AddRecipe(new ItemStack(blockLampIdle, 4), new Object[] {"###", "#O#", "#X#", '#', Block.glass, 'O', itemQuartz, 'X', Item.redstone});
		
		ModLoader.AddBlastSmelting(Block.limestoneCobble.blockID, new ItemStack(blockMarble, 1, 0));
		ModLoader.AddRecipe(new ItemStack(blockMarble, 1, 1), new Object[]{"##", "##", '#', new ItemStack(blockMarble, 4, 0)});
		ModLoader.AddRecipe(new ItemStack(blockMarble, 1, 3), new Object[]{"##", "##", '#', new ItemStack(blockMarble, 4, 2)});
		ModLoader.AddRecipe(new ItemStack(blockMarble, 1, 2), new Object[]{"#", "#", '#', new ItemStack(blockMarble, 2, 0)});
		
		ModLoader.AddBlastSmelting(Block.basaltCobble.blockID, new ItemStack(itemOlivine));
		ModLoader.AddRecipe(new ItemStack(blockTintedGlass, 4), new Object[]{"#o", "o#", '#', Block.glass, 'o', itemOlivine});
		
		ModLoader.AddRecipe(new ItemStack(blockTrapDoorIron), new Object[]{"###", "###", '#', Item.ingotIron});
		
		ModLoader.AddRecipe(new ItemStack(blockTrommelIdle), new Object[]{"CCC", "CMC", "LLL", 'C', Block.cobblestone, 'M', Block.mesh, 'L', Block.wood});
		
		ModLoader.AddRecipe(new ItemStack(Item.ingotIron, 1), new Object[] { "##", '#', itemIronNugget });
		ModLoader.AddRecipe(new ItemStack(Item.ingotGold, 1), new Object[] { "##", '#', itemGoldNugget });
		
		// Tile entities
		
		ModLoader.RegisterTileEntity(TileEntityTrommel.class, "trommel");
				
	}

	@Override 
	public int AddFuel(int id) {
		return id == itemOlivine.shiftedIndex ? 200 : 0;
	}

	@Override
	public String Version() {
		return "v1.0.0.0";
	}

}
