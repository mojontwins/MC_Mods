package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.Block;
import net.minecraft.src.Material;

public class BlockPaintablePlanks extends Block {

	public BlockPaintablePlanks(int i, int j) {
		super(i, j, Material.wood);	
	}

	@Override
	protected int damageDropped(int meta) {
		return meta;
	}

}
