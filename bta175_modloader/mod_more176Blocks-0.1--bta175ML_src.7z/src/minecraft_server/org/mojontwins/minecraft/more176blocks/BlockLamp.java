package org.mojontwins.minecraft.more176blocks;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_more176Blocks;

public class BlockLamp extends Block {
	boolean powered;

	public BlockLamp(int id, int tex, final boolean active) {
		super(id, tex, Material.rock);
		this.powered = active;
	}

	@Override
	public int tickRate() {
		return 2;
	}
	
	@Override
	public int idDropped(int i, Random random) {
		return mod_more176Blocks.blockLampIdle.blockID;
	}
	
	@Override
	protected int damageDropped(int meta) {
		return meta;
	}
	
	@Override
	public void onBlockAdded(World world, int x, int y, int z) {
		if(!world.singleplayerWorld) {
			if(this.powered && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.scheduleUpdateTick(x, y, z, this.blockID, 4);
			} else if(!this.powered && world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.setBlockWithNotify(x, y, z, mod_more176Blocks.blockLampActive.blockID);
			}
		}

	}

	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, int id) {
		if(!world.singleplayerWorld) {
			if(this.powered && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.scheduleUpdateTick(x, y, z, this.blockID, 4);
			} else if(!this.powered && world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.setBlockWithNotify(x, y, z, mod_more176Blocks.blockLampActive.blockID);
			}
		}

	}

	@Override
	public void updateTick(World world, int x, int y, int z, Random random5) {
		if(!world.singleplayerWorld && this.powered && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
			world.setBlockWithNotify(x, y, z, mod_more176Blocks.blockLampIdle.blockID);
		}

	}
}
