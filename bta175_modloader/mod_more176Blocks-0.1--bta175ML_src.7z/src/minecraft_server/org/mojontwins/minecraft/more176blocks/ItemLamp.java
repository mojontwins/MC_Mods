package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.ItemBlock;

public class ItemLamp extends ItemBlock {

	public ItemLamp(int i) {
		super(i);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	@Override
	public int getMetadata(int meta) {
		return meta;
	}
}
