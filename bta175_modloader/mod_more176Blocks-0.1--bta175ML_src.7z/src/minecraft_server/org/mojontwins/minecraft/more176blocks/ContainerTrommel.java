package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.Container;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ICrafting;
import net.minecraft.src.InventoryPlayer;
import net.minecraft.src.Slot;

public class ContainerTrommel extends Container
{
    private TileEntityTrommel trommel;
    private int cookTime;
    private int burnTime;
    private int itemBurnTime;
    
    public ContainerTrommel(final InventoryPlayer inventoryplayer, final TileEntityTrommel tileEntityTrommel) {
        this.cookTime = 0;
        this.burnTime = 0;
        this.itemBurnTime = 0;
        this.trommel = tileEntityTrommel;
        this.addSlot(new Slot(tileEntityTrommel, 0, 105, 30));
        this.addSlot(new Slot(tileEntityTrommel, 1, 125, 50));
        this.addSlot(new Slot(tileEntityTrommel, 2, 105, 70));
        this.addSlot(new Slot(tileEntityTrommel, 3, 85, 50));
        this.addSlot(new Slot(tileEntityTrommel, 4, 33, 50));
        for (int i = 0; i < 3; ++i) {
            for (int k = 0; k < 9; ++k) {
                this.addSlot(new Slot(inventoryplayer, k + i * 9 + 9, 8 + k * 18, 110 + i * 18));
            }
        }
        for (int j = 0; j < 9; ++j) {
            this.addSlot(new Slot(inventoryplayer, j, 8 + j * 18, 168));
        }
    }
    
    @Override
    public void updateCraftingMatrix() {
        super.updateCraftingMatrix();
        for (int i = 0; i < this.crafters.size(); ++i) {
            final ICrafting icrafting = (ICrafting) this.crafters.get(i);
            if (this.cookTime != this.trommel.itemPopTime) {
                icrafting.updateCraftingInventoryInfo(this, 0, this.trommel.itemPopTime);
            }
            if (this.burnTime != this.trommel.burnTime) {
                icrafting.updateCraftingInventoryInfo(this, 1, this.trommel.burnTime);
            }
            if (this.itemBurnTime != this.trommel.currentItemBurnTime) {
                icrafting.updateCraftingInventoryInfo(this, 2, this.trommel.currentItemBurnTime);
            }
        }
        this.cookTime = this.trommel.itemPopTime;
        this.burnTime = this.trommel.burnTime;
        this.itemBurnTime = this.trommel.currentItemBurnTime;
    }
    
    @Override
    public boolean canInteractWith(final EntityPlayer entityplayer) {
        return this.trommel.canInteractWith(entityplayer);
    }
    
}
