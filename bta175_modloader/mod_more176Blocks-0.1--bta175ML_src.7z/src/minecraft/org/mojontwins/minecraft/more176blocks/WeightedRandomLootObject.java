package org.mojontwins.minecraft.more176blocks;

import java.util.Random;

import net.minecraft.src.ItemStack;

public class WeightedRandomLootObject
{
    private ItemStack itemStack;
    private int yieldMin;
    private int yieldMax;
    private int yieldFixed;
    private boolean isRandomYield;
    private final Random random;
    
    public WeightedRandomLootObject(final ItemStack itemStack, final int yieldMin, final int yieldMax) {
        this.random = new Random();
        this.itemStack = itemStack;
        this.yieldMin = yieldMin;
        this.yieldMax = yieldMax;
        this.isRandomYield = true;
    }
    
    public WeightedRandomLootObject(final ItemStack itemStack, final int yieldFixed) {
        this.random = new Random();
        this.itemStack = itemStack;
        this.yieldFixed = yieldFixed;
        this.isRandomYield = false;
    }
    
    public WeightedRandomLootObject(final ItemStack itemStack) {
        this.random = new Random();
        this.itemStack = itemStack;
        this.yieldFixed = 1;
        this.isRandomYield = false;
    }
    
    public ItemStack getItemStack() {
        int amount;
        if (this.isRandomYield) {
            amount = this.random.nextInt(this.yieldMax - this.yieldMin) + this.yieldMin;
        }
        else {
            amount = this.yieldFixed;
        }
        final ItemStack newItemStack = new ItemStack(this.itemStack.itemID, amount, this.itemStack.getItemDamage());
        return newItemStack;
    }
}
