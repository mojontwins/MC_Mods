package org.mojontwins.minecraft.more176blocks;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.BlockChest;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntitySlime;
import net.minecraft.src.IInventory;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.TileEntity;
import net.minecraft.src.TileEntityChest;
import net.minecraft.src.mod_more176Blocks;

public class TileEntityTrommel extends TileEntity implements IInventory
{
    private ItemStack[] itemStacks;
    public int burnTime;
    public int currentItemBurnTime;
    public int itemPopTime;
    private final int maxBurnTime;
    private int nextToSieve;
    private final Random rand;
    private static final WeightedRandomBag<WeightedRandomLootObject> trommelDropsDirt;
    private static final WeightedRandomBag<WeightedRandomLootObject> trommelDropsGravel;
    private static final WeightedRandomBag<WeightedRandomLootObject> trommelDropsClay;
    private static final WeightedRandomBag<WeightedRandomLootObject> trommelDropsSand;
    private static final WeightedRandomBag<WeightedRandomLootObject> trommelDropsRichDirt;
    private static final WeightedRandomBag<WeightedRandomLootObject> trommelDropsslowSand;
    
    public TileEntityTrommel() {
        this.itemStacks = new ItemStack[5];
        this.burnTime = 0;
        this.currentItemBurnTime = 0;
        this.itemPopTime = 0;
        this.maxBurnTime = 50;
        this.rand = new Random();
        this.nextToSieve = 1;
    }
    
    @Override
    public int getSizeInventory() {
        return this.itemStacks.length;
    }
    
    @Override
    public ItemStack getStackInSlot(final int i) {
        return this.itemStacks[i];
    }
    
    @Override
    public ItemStack decrStackSize(final int i, final int j) {
        if (this.itemStacks[i] == null) {
            return null;
        }
        if (this.itemStacks[i].stackSize <= j) {
            final ItemStack itemstack = this.itemStacks[i];
            this.itemStacks[i] = null;
            return itemstack;
        }
        final ItemStack itemstack2 = this.itemStacks[i].splitStack(j);
        if (this.itemStacks[i].stackSize == 0) {
            this.itemStacks[i] = null;
        }
        return itemstack2;
    }
    
    @Override
    public void setInventorySlotContents(final int i, final ItemStack itemstack) {
        this.itemStacks[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
    }
    
    @Override
    public String getInvName() {
        return "Trommel";
    }
    
    @Override
    public void readFromNBT(final NBTTagCompound nbttagcompound) {
        super.readFromNBT(nbttagcompound);
        final NBTTagList nbttaglist = nbttagcompound.getTagList("Items");
        this.itemStacks = new ItemStack[this.getSizeInventory()];
        for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.tagAt(i);
            final byte byte0 = nbttagcompound2.getByte("Slot");
            if (byte0 >= 0 && byte0 < this.itemStacks.length) {
                this.itemStacks[byte0] = new ItemStack(nbttagcompound2);
            }
        }
        this.burnTime = nbttagcompound.getShort("BurnTime");
        this.itemPopTime = nbttagcompound.getShort("CookTime");
        this.currentItemBurnTime = this.getItemBurnTime(this.itemStacks[1]);
    }
    
    @Override
    public void writeToNBT(final NBTTagCompound nbttagcompound) {
        super.writeToNBT(nbttagcompound);
        nbttagcompound.setShort("BurnTime", (short)this.burnTime);
        nbttagcompound.setShort("CookTime", (short)this.itemPopTime);
        final NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.itemStacks.length; ++i) {
            if (this.itemStacks[i] != null) {
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                nbttagcompound2.setByte("Slot", (byte)i);
                this.itemStacks[i].writeToNBT(nbttagcompound2);
                nbttaglist.setTag(nbttagcompound2);
            }
        }
        nbttagcompound.setTag("Items", nbttaglist);
    }
    
    @Override
    public int getInventoryStackLimit() {
        return 64;
    }
    
    public float getCookProgressPercent(final int i) {
        return this.itemPopTime / (float)this.maxBurnTime * i;
    }
    
    public int getBurnTimeRemainingScaled(final int i) {
        if (this.currentItemBurnTime == 0) {
            this.currentItemBurnTime = this.maxBurnTime;
        }
        return this.burnTime * i / this.currentItemBurnTime;
    }
    
    public boolean isBurning() {
        return this.burnTime > 0;
    }
    
    @Override
    public void updateEntity() {
        if (this.nextToSieve > 4) {
            this.nextToSieve = 1;
        }
        final boolean isBurning = this.burnTime > 0;
        boolean flag1 = false;
        if (isBurning) {
            --this.burnTime;
        }
        if (!this.worldObj.multiplayerWorld) {
            if (this.worldObj.getBlockId(this.xCoord, this.yCoord, this.zCoord) == mod_more176Blocks.blockTrommelIdle.blockID && 
            		this.currentItemBurnTime == 0 && 
            		this.itemStacks[0] == null && 
            		this.itemStacks[4] != null && 
            		this.itemStacks[4].itemID == Block.netherrack.blockID) {
                final ItemStack itemStack = this.itemStacks[4];
                --itemStack.stackSize;
                if (this.itemStacks[4].stackSize == 0) {
                    this.itemStacks[4] = null;
                }
                BlockTrommel.updateTrommelBlockState(true, this.worldObj, this.xCoord, this.yCoord, this.zCoord);
                flag1 = true;
            }
            
            if (!this.canProduce(this.nextToSieve)) {
                this.nextToSieve = (this.nextToSieve + 1) % 4;
            }

            if (this.burnTime == 0 && this.canProduce(this.nextToSieve)) {
                final int itemBurnTime = this.getItemBurnTime(this.itemStacks[4]);

                this.burnTime = itemBurnTime;
                this.currentItemBurnTime = itemBurnTime;
                if (this.burnTime > 0) {
                    flag1 = true;
                    if (this.itemStacks[4] != null) {
                        final ItemStack itemStack2 = this.itemStacks[4];
                        --itemStack2.stackSize;
                        if (this.itemStacks[4].stackSize == 0) {
                            this.itemStacks[4] = null;
                        }
                    }
                }
            }
            
            if (this.isBurning() && this.canProduce(this.nextToSieve)) {
                ++this.itemPopTime;
                if (this.itemPopTime == this.maxBurnTime) {
                    this.itemPopTime = 0;
                    this.sieveItem(this.nextToSieve);
                    this.nextToSieve = (this.nextToSieve + 1) % 4;
                    flag1 = true;
                }
            } else {
                this.itemPopTime = 0;
            }
            
            if (isBurning != this.burnTime > 0) {
                flag1 = true;
                BlockTrommel.updateTrommelBlockState(this.burnTime > 0, this.worldObj, this.xCoord, this.yCoord, this.zCoord);
            }
        }
        if (flag1) {
            this.onInventoryChanged();
        }
    }
    
    private boolean canProduce(final int slotIndex) {
        return this.itemStacks[slotIndex] != null && this.canItemBeTrommeled(this.itemStacks[slotIndex]);
    }
    
    public void sieveItem(final int slotIndex) {
        if (!this.canProduce(slotIndex)) {
            return;
        }
        final ItemStack itemResult = this.getItemResult(this.itemStacks[slotIndex]);
        final ItemStack itemStack = this.itemStacks[slotIndex];
        --itemStack.stackSize;
        if (this.itemStacks[slotIndex].stackSize <= 0) {
            this.itemStacks[slotIndex] = null;
        }
        if (itemResult != null) {
            int xOffset = 0;
            int zOffset = 0;
            final int meta = this.worldObj.getBlockMetadata(this.xCoord, this.yCoord, this.zCoord) & 0x7;
            if (meta == 2) {
                xOffset = -1;
            }
            else if (meta == 5) {
                zOffset = -1;
            }
            else if (meta == 3) {
                xOffset = 1;
            }
            else if (meta == 4) {
                zOffset = 1;
            }
            final int adjacentId = this.worldObj.getBlockId(this.xCoord + xOffset, this.yCoord, this.zCoord + zOffset);
            TileEntityChest chest = null;
            if (Block.blocksList[adjacentId] instanceof BlockChest) {
                chest = (TileEntityChest)this.worldObj.getBlockTileEntity(this.xCoord + xOffset, this.yCoord, this.zCoord + zOffset);
            }
            if (chest != null) {
                for (int i = 0; i < chest.getSizeInventory(); ++i) {
                    final ItemStack slot = chest.getStackInSlot(i);
                    if (slot != null && slot.itemID == itemResult.itemID && slot.getItemDamage() == itemResult.getItemDamage()) {
                        while (slot.stackSize + 1 <= slot.getMaxStackSize()) {
                            final ItemStack itemStack2 = slot;
                            ++itemStack2.stackSize;
                            chest.setInventorySlotContents(i, slot);
                            if (itemResult.stackSize <= 0) {
                                return;
                            }
                            final ItemStack itemStack3 = itemResult;
                            --itemStack3.stackSize;
                        }
                    }
                }
                if (itemResult.stackSize <= 0) {
                    return;
                }
                for (int i = 0; i < chest.getSizeInventory(); ++i) {
                    final ItemStack slot = chest.getStackInSlot(i);
                    if (slot == null) {
                        chest.setInventorySlotContents(i, itemResult);
                        return;
                    }
                }
            }
            if (itemResult.stackSize > 0) {
                final float f = this.rand.nextFloat() * 0.8f + 0.1f;
                final float f2 = this.rand.nextFloat() * 0.8f + 0.1f;
                final float f3 = this.rand.nextFloat() * 0.8f + 0.1f;
                final EntityItem entityitem = new EntityItem(this.worldObj, this.xCoord + f, this.yCoord + f2, this.zCoord + f3, itemResult);
                final float f4 = 0.05f;
                entityitem.motionX = (float)this.rand.nextGaussian() * f4;
                entityitem.motionY = (float)this.rand.nextGaussian() * f4 + 0.2f;
                entityitem.motionZ = (float)this.rand.nextGaussian() * f4;
                this.worldObj.entityJoinedWorld(entityitem);
            }
        }
        if (this.rand.nextInt(4000) == 0) {
            final float f5 = 0.125f;
            final float f6 = 0.125f;
            final EntitySlime entityslime = new EntitySlime(this.worldObj);
            entityslime.setSlimeSize(1);
            entityslime.setLocationAndAngles(this.xCoord + (double)f5, this.yCoord + 1.0, this.zCoord + (double)f6, this.rand.nextFloat() * 360.0f, 0.0f);
            final float f7 = 0.05f;
            entityslime.motionX = (float)this.rand.nextGaussian() * f7;
            entityslime.motionY = (float)this.rand.nextGaussian() * f7 + 0.2f;
            entityslime.motionZ = (float)this.rand.nextGaussian() * f7;
            this.worldObj.entityJoinedWorld(entityslime);
        }
    }
    
    private ItemStack getItemResult(final ItemStack slotItem) {
        final int i = slotItem.getItem().shiftedIndex;
        if (i == Block.dirt.blockID ||i == Block.grass.blockID || i == Block.grass.blockID || i == Block.dirtPath.blockID || i == Block.tilledField.blockID) {
            return TileEntityTrommel.trommelDropsDirt.getRandom().getItemStack();
        }
        if (i == Block.sand.blockID) {
            return TileEntityTrommel.trommelDropsSand.getRandom().getItemStack();
        }
        if (i == Block.gravel.blockID) {
            return TileEntityTrommel.trommelDropsGravel.getRandom().getItemStack();
        }
        if (i == Block.blockClay.blockID) {
            return TileEntityTrommel.trommelDropsClay.getRandom().getItemStack();
        }
        
        if (i == Block.slowSand.blockID) {
            return TileEntityTrommel.trommelDropsslowSand.getRandom().getItemStack();
        }
        return null;
    }
    
    private boolean canItemBeTrommeled(final ItemStack itemstack) {
        if (itemstack == null) {
            return false;
        }
        final int i = itemstack.getItem().shiftedIndex;
        return i == Block.dirt.blockID || i == Block.grass.blockID || i == Block.grass.blockID || i == Block.dirtPath.blockID || i == Block.tilledField.blockID || i == Block.sand.blockID || i == Block.slowSand.blockID || i == Block.gravel.blockID;
    }
    
    private int getItemBurnTime(final ItemStack itemStack) {
        if (itemStack == null) {
            return 0;
        }
        return LookupFuelFurnace.fuelFurnace().getFuelYield(itemStack.getItem().shiftedIndex);
    }
    
    @Override
    public boolean canInteractWith(final EntityPlayer entityplayer) {
        return this.worldObj.getBlockTileEntity(this.xCoord, this.yCoord, this.zCoord) == this && entityplayer.getDistanceSq(this.xCoord + 0.5, this.yCoord + 0.5, this.zCoord + 0.5) <= 64.0;
    }
    
    static {
    	(trommelDropsDirt = new WeightedRandomBag<WeightedRandomLootObject>()).addEntry(new WeightedRandomLootObject(new ItemStack(Item.seeds), 1, 3), 50.0);
        TileEntityTrommel.trommelDropsDirt.addEntry(new WeightedRandomLootObject(new ItemStack(Item.clay), 1, 5), 20.0);
        TileEntityTrommel.trommelDropsDirt.addEntry(new WeightedRandomLootObject(new ItemStack(Item.flint), 1, 3), 10.0);
        TileEntityTrommel.trommelDropsDirt.addEntry(new WeightedRandomLootObject(new ItemStack(Item.gunpowder)), 2.0);
        TileEntityTrommel.trommelDropsDirt.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemIronNugget), 1, 3), 0.5);
        TileEntityTrommel.trommelDropsDirt.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemOlivine)), 0.25);
        TileEntityTrommel.trommelDropsDirt.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemQuartz)), 0.25);
        (trommelDropsGravel = new WeightedRandomBag<WeightedRandomLootObject>()).addEntry(new WeightedRandomLootObject(new ItemStack(Item.flint), 1, 5), 50.0);
        TileEntityTrommel.trommelDropsGravel.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemOlivine), 1, 3), 30.0);
        TileEntityTrommel.trommelDropsGravel.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemIronNugget), 2, 4), 10.0);
        TileEntityTrommel.trommelDropsGravel.addEntry(new WeightedRandomLootObject(new ItemStack(Item.dyePowder, 1, 4), 2, 6), 5.0);
        TileEntityTrommel.trommelDropsGravel.addEntry(new WeightedRandomLootObject(new ItemStack(Item.gunpowder)), 5.0);
        TileEntityTrommel.trommelDropsGravel.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemQuartz)), 0.5);
        (trommelDropsClay = new WeightedRandomBag<WeightedRandomLootObject>()).addEntry(new WeightedRandomLootObject(new ItemStack(Item.clay), 4, 8), 30.0);
        TileEntityTrommel.trommelDropsClay.addEntry(new WeightedRandomLootObject(new ItemStack(Item.gunpowder)), 10.0);
        TileEntityTrommel.trommelDropsClay.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemGoldNugget), 1, 3), 5.0);
        (trommelDropsSand = new WeightedRandomBag<WeightedRandomLootObject>()).addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemQuartz), 1, 3), 50.0);
        TileEntityTrommel.trommelDropsSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.clay), 4, 8), 30.0);
        TileEntityTrommel.trommelDropsSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.bone), 1, 3), 10.0);
        TileEntityTrommel.trommelDropsSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.flint), 1, 3), 10.0);
        TileEntityTrommel.trommelDropsSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.gunpowder)), 5.0);
        TileEntityTrommel.trommelDropsSand.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemGoldNugget), 4, 8), 5.0);
        TileEntityTrommel.trommelDropsSand.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemOlivine)), 5.0);
        (trommelDropsRichDirt = new WeightedRandomBag<WeightedRandomLootObject>()).addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemGoldNugget), 1, 6), 40.0);
        TileEntityTrommel.trommelDropsRichDirt.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemIronNugget), 1, 6), 40.0);
        TileEntityTrommel.trommelDropsRichDirt.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemQuartz), 1, 4), 25.0);
        TileEntityTrommel.trommelDropsRichDirt.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemOlivine), 1, 4), 25.0);
        TileEntityTrommel.trommelDropsRichDirt.addEntry(new WeightedRandomLootObject(new ItemStack(Item.dyePowder, 1, 4), 2, 8), 20.0);
        TileEntityTrommel.trommelDropsRichDirt.addEntry(new WeightedRandomLootObject(new ItemStack(Item.clay), 4, 8), 10.0);
        (trommelDropsslowSand = new WeightedRandomBag<WeightedRandomLootObject>()).addEntry(new WeightedRandomLootObject(new ItemStack(Item.flint), 1, 3), 20.0);
        TileEntityTrommel.trommelDropsslowSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.bone), 1, 6), 10.0);
        TileEntityTrommel.trommelDropsslowSand.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemGoldNugget), 1, 5), 10.0);
        TileEntityTrommel.trommelDropsslowSand.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemIronNugget), 1, 5), 5.0);
        TileEntityTrommel.trommelDropsslowSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.lightStoneDust), 1, 6), 5.0);
        TileEntityTrommel.trommelDropsslowSand.addEntry(new WeightedRandomLootObject(new ItemStack(mod_more176Blocks.itemQuartz), 1, 3), 5.0);
        TileEntityTrommel.trommelDropsslowSand.addEntry(new WeightedRandomLootObject(new ItemStack(Item.netherCoal)), 0.5);
    }
}
