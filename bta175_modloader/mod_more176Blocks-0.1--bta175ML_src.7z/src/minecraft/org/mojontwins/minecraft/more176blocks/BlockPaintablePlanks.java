package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;

public class BlockPaintablePlanks extends Block {

	private static final int[] PlankPaintColors = {
		0xFFFFFF, 0xF0B06C, 0xC08BD6, 0x99B7FF, 0xFFF89D, 0xB4FFAC, 0xFCDDE6, 0x797979, 
		0xBABABA, 0x64A7C4, 0x997DC9, 0x7081E0, 0x7A5E40, 0x79A472, 0xFF6864, 0x5B5A5A
	};

	public BlockPaintablePlanks(int i, int j) {
		super(i, j, Material.wood);	
	}

	@Override
	protected int damageDropped(int meta) {
		return meta;
	}

	@Override
	public int getRenderColor(int meta) {
		return PlankPaintColors[meta & 15];
	}
	
	@Override
	public int colorMultiplier(IBlockAccess world, int x, int y, int z) {
		return this.getRenderColor(world.getBlockMetadata(x, y, z));
	}
}
