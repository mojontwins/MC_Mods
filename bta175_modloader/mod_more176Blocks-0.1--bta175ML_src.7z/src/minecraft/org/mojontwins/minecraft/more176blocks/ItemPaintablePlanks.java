package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.ItemBlock;

public class ItemPaintablePlanks extends ItemBlock {

	public ItemPaintablePlanks(int i) {
		super(i);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	public int getPlacedBlockMetadata(int meta) {
		return meta;
	}
}
