package org.mojontwins.minecraft.more176blocks;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.ModLoader;
import net.minecraft.src.TileEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_more176Blocks;

public class BlockTrommel extends BlockContainerRotatable
{
    private boolean isActive;
    protected static boolean keepTrommelInventory;
    private Random random;
	private int texTopBottom;
	private int texFront;
	private int texSides;
    
    public BlockTrommel(final int i, final boolean isActive) {
        super(i, Material.rock);
        this.isActive = isActive;
        this.random = new Random();
    }
    
    public Block withTextures(int texTopBottom, int texSides, int texFront) {
    	this.texTopBottom = texTopBottom;
    	this.texFront = texFront;
    	this.texSides = texSides;
    	return this;
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        super.onBlockAdded(world, i, j, k);
        this.setDefaultDirection(world, i, j, k);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer thePlayer) {
        if (!world.multiplayerWorld) {
            final TileEntityTrommel tileEntityTrommel = (TileEntityTrommel)world.getBlockTileEntity(i, j, k);
            if(tileEntityTrommel != null) {
				ModLoader.OpenGUI(thePlayer, new GuiTrommel(thePlayer.inventory, tileEntityTrommel));
			}
        }
        return true;
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (!this.isActive) {
            return;
        }
        final float f = i + random.nextFloat();
        final float f2 = j + random.nextFloat() * 0.5f + 1.0f;
        final float f3 = k + random.nextFloat();
        world.spawnParticle("smoke", f, f2, f3, 0.0, 0.0, 0.0);
    }
    
    public static void updateTrommelBlockState(final boolean flag, final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        final TileEntity tileentity = world.getBlockTileEntity(i, j, k);
        BlockTrommel.keepTrommelInventory = true;
        if (flag) {
            world.setBlockWithNotify(i, j, k,mod_more176Blocks.blockTrommelActive.blockID);
        }
        else {
            world.setBlockWithNotify(i, j, k, mod_more176Blocks.blockTrommelIdle.blockID);
        }
        BlockTrommel.keepTrommelInventory = false;
        world.setBlockMetadataWithNotify(i, j, k, l);
        tileentity.validate();
        world.setBlockTileEntity(i, j, k, tileentity);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return mod_more176Blocks.blockTrommelIdle.blockID;
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        if (!BlockTrommel.keepTrommelInventory && world.getBlockTileEntity(i, j, k) != null) {
            final TileEntityTrommel tileentitytrommel = (TileEntityTrommel)world.getBlockTileEntity(i, j, k);
            for (int l = 0; l < tileentitytrommel.getSizeInventory(); ++l) {
                final ItemStack itemstack = tileentitytrommel.getStackInSlot(l);
                if (itemstack != null) {
                    final float f = this.random.nextFloat() * 0.8f + 0.1f;
                    final float f2 = this.random.nextFloat() * 0.8f + 0.1f;
                    final float f3 = this.random.nextFloat() * 0.8f + 0.1f;
                    while (itemstack.stackSize > 0) {
                        int i2 = this.random.nextInt(21) + 10;
                        if (i2 > itemstack.stackSize) {
                            i2 = itemstack.stackSize;
                        }
                        final ItemStack itemStack = itemstack;
                        itemStack.stackSize -= i2;
                        final EntityItem entityitem = new EntityItem(world, i + f, j + f2, k + f3, new ItemStack(itemstack.itemID, i2, itemstack.getItemDamage()));
                        final float f4 = 0.05f;
                        entityitem.motionX = (float)this.random.nextGaussian() * f4;
                        entityitem.motionY = (float)this.random.nextGaussian() * f4 + 0.2f;
                        entityitem.motionZ = (float)this.random.nextGaussian() * f4;
                        world.entityJoinedWorld(entityitem);
                    }
                }
            }
        }
        super.onBlockRemoval(world, i, j, k);
    }
    
    @Override public int getBlockTextureFromSideAndMetadata(int side, int meta) {
    	switch(side) {
    	case 0:
    	case 1:
    		return this.texTopBottom;
    	default:
    		if(side == meta) return this.texFront;
    		return this.texSides;
    	}
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        return new TileEntityTrommel();
    }
    
    static {
        BlockTrommel.keepTrommelInventory = false;
    }
}
