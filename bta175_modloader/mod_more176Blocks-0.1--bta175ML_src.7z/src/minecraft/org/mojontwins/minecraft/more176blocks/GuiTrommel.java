package org.mojontwins.minecraft.more176blocks;

import org.lwjgl.opengl.GL11;

import net.minecraft.src.GuiContainer;
import net.minecraft.src.InventoryPlayer;

public class GuiTrommel extends GuiContainer
{
    private TileEntityTrommel trommelInventory;
    
    public GuiTrommel(final InventoryPlayer inventoryplayer, final TileEntityTrommel tileentitytrommel) {
        super(new ContainerTrommel(inventoryplayer, tileentitytrommel));
        this.ySize = 192;
        this.trommelInventory = tileentitytrommel;
    }
    
    @Override
    protected void drawGuiContainerForegroundLayer() {
        this.fontRenderer.drawString("Trommel", 60, 6, 4210752);
        this.fontRenderer.drawString("Inventory", 8, this.ySize - 96 + 2, 4210752);
    }
    
    @Override
    protected void drawGuiContainerBackgroundLayer(final float f) {
        final int guiTexture = this.mc.renderEngine.getTexture("/mojontwins/guitrommel.png");
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.renderEngine.bindTexture(guiTexture);
        final int j = (this.width - this.xSize) / 2;
        final int k = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(j, k, 0, 0, this.xSize, this.ySize);
        if (this.trommelInventory.isBurning()) {
            final int l = this.trommelInventory.getBurnTimeRemainingScaled(12);
            this.drawTexturedModalRect(j + 33, k + 33 + 12 - l, 176, 12 - l, 14, l + 2);
        }
        final int i1 = (int)this.trommelInventory.getCookProgressPercent(8) % 4;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(j + 105), (float)(k + 50), 0.0f);
        this.drawTexturedModalRect(0, 0, 176 + i1 * 16, 16, 16, 16);
        GL11.glPopMatrix();
    }
}
