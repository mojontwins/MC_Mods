package org.mojontwins.minecraft.more176blocks;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;

public class BlockTintedGlass extends Block {

	public BlockTintedGlass(int i, int j) {
		super(i, j, Material.glass);
		this.setLightOpacity(255);
	}

	@Override
	public int quantityDropped(int metadata, Random random) {
		return 0;
	}
	
	@Override
	public int getRenderBlockPass() {
		return 1;
	}
	
	@Override
	public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int x, int y, int z, int s) {
		return super.shouldSideBeRendered(iblockaccess, x, y, z, 1 - s);
	}
	
	@Override
	public boolean isOpaqueCube() {
		return false;
	}
}
