package org.mojontwins.minecraft.more176blocks;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_more176Blocks;

public class BlockLamp extends Block {
	boolean powered;
	private static final int[] LampColors = {
		0xFFFFFF, 0xFF7424, 0xD281D9, 0xA8BDFF, 0xFFED29, 0x2DFF1A, 0xFF429E, 0x7D7D7D, 
		0xBBC9C9, 0x4DC9FF, 0x941DFC, 0x0A12FF, 0x663300, 0x68B300, 0xFF170F, 0x363636
	};

	public BlockLamp(int id, int tex, final boolean active) {
		super(id, tex, Material.rock);
		this.powered = active;
	}

	@Override
	public int tickRate() {
		return 2;
	}
	
	@Override
	public int getRenderColor(int meta) {
		return LampColors[meta & 15];
	}
	
	@Override
	public int colorMultiplier(IBlockAccess world, int x, int y, int z) {
		return this.getRenderColor(world.getBlockMetadata(x, y, z));
	}
	
	@Override
	public int idDropped(int i, Random random) {
		return mod_more176Blocks.blockLampIdle.blockID;
	}
	
	@Override
	protected int damageDropped(int meta) {
		return meta;
	}
	
	@Override
	public void onBlockAdded(World world, int x, int y, int z) {
		if(!world.multiplayerWorld) {
			if(this.powered && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.scheduleBlockUpdate(x, y, z, this.blockID, 4);
			} else if(!this.powered && world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.setBlockWithNotify(x, y, z, mod_more176Blocks.blockLampActive.blockID);
			}
		}

	}

	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, int id) {
		if(!world.multiplayerWorld) {
			if(this.powered && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.scheduleBlockUpdate(x, y, z, this.blockID, 4);
			} else if(!this.powered && world.isBlockIndirectlyGettingPowered(x, y, z)) {
				world.setBlockWithNotify(x, y, z, mod_more176Blocks.blockLampActive.blockID);
			}
		}

	}

	@Override
	public void updateTick(World world, int x, int y, int z, Random random5) {
		if(!world.multiplayerWorld && this.powered && !world.isBlockIndirectlyGettingPowered(x, y, z)) {
			world.setBlockWithNotify(x, y, z, mod_more176Blocks.blockLampIdle.blockID);
		}

	}
}
