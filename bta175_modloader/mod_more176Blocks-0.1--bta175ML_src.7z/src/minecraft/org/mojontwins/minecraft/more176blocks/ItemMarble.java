package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.Block;
import net.minecraft.src.ItemBlock;
import net.minecraft.src.ItemStack;

public class ItemMarble extends ItemBlock {

	public ItemMarble(int i) {
		super(i);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	public int getPlacedBlockMetadata(int meta) {
		return meta;
	}
	
	public int getIconFromDamage(int damage) {
		return Block.cloth.getBlockTextureFromSideAndMetadata(2, damage);
	}

	public String getItemNameIS(ItemStack itemStack) {
		switch(itemStack.getItemDamage()) {
		case 1: return "marbleBricks";
		case 2: return "marblePillar";
		case 3: return "marbleChiseled";
		default: return "marble";
		}
	}
}
