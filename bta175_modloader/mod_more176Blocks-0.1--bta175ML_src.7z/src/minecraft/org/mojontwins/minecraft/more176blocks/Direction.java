package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.*;

public enum Direction
{
    NORTH(0, false), 
    EAST(1, false), 
    SOUTH(2, false), 
    WEST(3, false), 
    UP(4, true), 
    DOWN(5, true);
    
    public final int index;
    private Direction opposite;
    public final boolean vertical;
    
    private Direction(final int index, final boolean vertical) {
        this.index = index;
        this.vertical = vertical;
    }
    
    public static Direction getDirection(final int index) {
        return values()[index];
    }
    
    public static Direction getVerticalDirection(final double rotationPitch) {
        if (rotationPitch < 0.0) {
            return Direction.UP;
        }
        return Direction.DOWN;
    }
    
    public static Direction getVerticalDirection(final EntityLiving entity) {

        return getVerticalDirection(entity.rotationPitch);
    }
    
    public static Direction getHorizontalDirection(final double rotationYaw) {
        return getDirection(MathHelper.floor_double(rotationYaw / 90.0 + 0.5) & 0x3);
    }
    
    public static Direction getHorizontalDirection(final EntityLiving entity) {

        return getHorizontalDirection(entity.rotationYaw);
    }
    
    public static Direction getDirection(final EntityLiving entity) {
        return getDirection(entity.rotationYaw, entity.rotationPitch);
    }
    
    public static Direction getDirection(final double rotationYaw, final double rotationPitch) {
        if (rotationPitch < -45.0) {
            return Direction.UP;
        }
        if (rotationPitch > 45.0) {
            return Direction.DOWN;
        }
        return getHorizontalDirection(rotationYaw);
    }
    
    public static Direction getHorizontalDirectionForSide(final int side) {
        return Direction.NORTH;
    }
    
    public Direction getOpposite() {
        return this.opposite;
    }
    
    public int getIndex() {
        return this.index;
    }
    
    public Direction rotate(final int i) {
        if (this == Direction.UP) {
            return Direction.UP;
        }
        if (this == Direction.DOWN) {
            return Direction.DOWN;
        }
        return getDirection(this.getIndex() + i & 0x3);
    }
    
    public boolean isVertical() {
        return this.vertical;
    }
    
    public boolean isHorizontal() {
        return !this.vertical;
    }
    
    public static int getLegacySide(final Direction dir) {
        if (dir == Direction.UP) {
            return 0;
        }
        if (dir == Direction.DOWN) {
            return 1;
        }
        if (dir == Direction.NORTH) {
            return 2;
        }
        if (dir == Direction.EAST) {
            return 5;
        }
        if (dir == Direction.SOUTH) {
            return 3;
        }
        if (dir == Direction.WEST) {
            return 4;
        }
        return -1;
    }
    
    public static int getLegacySide2(final Direction dir) {
        if (dir == Direction.NORTH) {
            return 1;
        }
        if (dir == Direction.EAST) {
            return 2;
        }
        if (dir == Direction.SOUTH) {
            return 0;
        }
        if (dir == Direction.WEST) {
            return 3;
        }
        return -1;
    }
    
    public int meta() {
        return getLegacySide(this);
    }
    
    public static Direction getDirectionForLegacySide(final int l) {
        if (l == 0) {
            return Direction.UP;
        }
        if (l == 1) {
            return Direction.DOWN;
        }
        if (l == 2) {
            return Direction.NORTH;
        }
        if (l == 3) {
            return Direction.SOUTH;
        }
        if (l == 4) {
            return Direction.WEST;
        }
        if (l == 5) {
            return Direction.EAST;
        }
        return null;
    }
    
    static {
        Direction.NORTH.opposite = Direction.SOUTH;
        Direction.SOUTH.opposite = Direction.NORTH;
        Direction.EAST.opposite = Direction.WEST;
        Direction.WEST.opposite = Direction.EAST;
        Direction.UP.opposite = Direction.DOWN;
        Direction.DOWN.opposite = Direction.UP;
    }
}
