package org.mojontwins.minecraft.more176blocks;

import java.util.*;

public class WeightedRandomBag<T>
{
    private final List<Entry> entries;
    private double accumulatedWeight;
    private final Random rand;
    
    public WeightedRandomBag() {
        this.entries = new ArrayList<Entry>();
        this.rand = new Random();
    }
    
    public void addEntry(final T object, final double weight) {
        this.accumulatedWeight += weight;
        final Entry e = new Entry();
        e.object = object;
        e.accumulatedWeight = this.accumulatedWeight;
        this.entries.add(e);
    }
    
    public T getRandom() {
        final double r = this.rand.nextDouble() * this.accumulatedWeight;
        for (final Entry entry : this.entries) {
            if (entry.accumulatedWeight >= r) {
                return entry.object;
            }
        }
        return null;
    }
    
    private class Entry
    {
        double accumulatedWeight;
        T object;
    }
}
