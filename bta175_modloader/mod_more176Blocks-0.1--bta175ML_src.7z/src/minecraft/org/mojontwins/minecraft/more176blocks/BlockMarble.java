package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.Block;
import net.minecraft.src.Material;

public class BlockMarble extends Block {
	public static int[] marbleTexturePool = new int[4];
	
	public BlockMarble(int id) {
		super(id, Material.rock);
	}

	public Block withTextures(int [] textures) {
		marbleTexturePool = textures;
		return this;
	}

	@Override
	public int getBlockTextureFromSideAndMetadata(int side, int meta) {
		if(meta < 2 || side > 1) return marbleTexturePool[meta];
		return marbleTexturePool[3];
	}
	
	@Override
	protected int damageDropped(int meta) {
		return meta;
	}
}
