package org.mojontwins.minecraft.more176blocks;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.src.Block;
import net.minecraft.src.Item;
import net.minecraft.src.mod_more176Blocks;

public class LookupFuelFurnace
{
    private static final LookupFuelFurnace fuelBase;
    protected Map<Integer, Integer> fuelList;
    
    public static LookupFuelFurnace fuelFurnace() {
        return LookupFuelFurnace.fuelBase;
    }
    
    protected LookupFuelFurnace() {
        this.fuelList = new HashMap<Integer, Integer>();
        this.addFuelEntry(Block.planks.blockID, 300);
        this.addFuelEntry(mod_more176Blocks.blockPaintablePlanks.blockID, 300);
        this.addFuelEntry(Block.stairCompactPlanks.blockID, 300);
        this.addFuelEntry(Block.slabPlanks.blockID, 150);
        this.addFuelEntry(Block.wood.blockID, 300);
        this.addFuelEntry(Block.sapling.blockID, 10);
        this.addFuelEntry(Block.deadBush.blockID, 10);
        this.addFuelEntry(Item.stick.shiftedIndex, 100);
        this.addFuelEntry(Item.pickaxeWood.shiftedIndex, 500);
        this.addFuelEntry(Item.swordWood.shiftedIndex, 500);
        this.addFuelEntry(Item.axeWood.shiftedIndex, 500);
        this.addFuelEntry(Item.shovelWood.shiftedIndex, 500);
        this.addFuelEntry(Item.hoeWood.shiftedIndex, 500);
        this.addFuelEntry(Item.bow.shiftedIndex, 300);
        this.addFuelEntry(Item.fishingRod.shiftedIndex, 300);
        this.addFuelEntry(Item.boat.shiftedIndex, 300);
        this.addFuelEntry(Item.doorWood.shiftedIndex, 300);
        this.addFuelEntry(Item.sign.shiftedIndex, 300);
        this.addFuelEntry(Item.bowlEmpty.shiftedIndex, 300);
        this.addFuelEntry(Item.coal.shiftedIndex, 1600);
        this.addFuelEntry(Item.netherCoal.shiftedIndex, 6400);
        this.addFuelEntry(Item.bucketLava.shiftedIndex, 20000);
    }
    
    public void addFuelEntry(final int id, final int fuelYield) {
        this.fuelList.put(id, fuelYield);
    }
    
    public int getFuelYield(final int id) {
        return (this.fuelList.get(id) == null) ? 0 : this.fuelList.get(id);
    }
    
    public Map<Integer, Integer> getFuelList() {
        return this.fuelList;
    }
    
    static {
        fuelBase = new LookupFuelFurnace();
    }
}
