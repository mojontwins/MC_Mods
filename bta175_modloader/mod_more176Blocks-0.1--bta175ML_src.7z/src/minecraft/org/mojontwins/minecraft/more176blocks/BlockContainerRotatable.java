package org.mojontwins.minecraft.more176blocks;

import net.minecraft.src.Block;
import net.minecraft.src.BlockContainer;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.World;

public abstract class BlockContainerRotatable extends BlockContainer
{
	public final static int[] orientationLookUp = new int[] { 0, 1, 2, 3, 4, 5, 1, 0, 4, 5, 2, 3, 0, 1, 4, 5, 2, 3, 0, 1, 5, 4, 3, 2, 0, 1, 3, 2, 4, 5, 0, 1, 2, 3, 5, 4 };
	
    public BlockContainerRotatable(final int i, final Material material) {
        super(i, material);
    }
    
    public void setDefaultDirection(final World world, final int i, final int j, final int k) {
        if (world.multiplayerWorld) {
            return;
        }
        final int l = world.getBlockId(i, j, k - 1);
        final int i2 = world.getBlockId(i, j, k + 1);
        final int j2 = world.getBlockId(i - 1, j, k);
        final int k2 = world.getBlockId(i + 1, j, k);
        byte byte0 = 3;
        if (Block.opaqueCubeLookup[l] && !Block.opaqueCubeLookup[i2]) {
            byte0 = 3;
        }
        if (Block.opaqueCubeLookup[i2] && !Block.opaqueCubeLookup[l]) {
            byte0 = 2;
        }
        if (Block.opaqueCubeLookup[j2] && !Block.opaqueCubeLookup[k2]) {
            byte0 = 5;
        }
        if (Block.opaqueCubeLookup[k2] && !Block.opaqueCubeLookup[j2]) {
            byte0 = 4;
        }
        world.setBlockMetadataWithNotify(i, j, k, byte0);
    }
    
    @Override
	public void onBlockPlacedBy(World world1, int i2, int i3, int i4, EntityLiving entityLiving5) {
		int i6 = MathHelper.floor_double((double)(entityLiving5.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3;
		if(i6 == 0) {
			world1.setBlockMetadataWithNotify(i2, i3, i4, 2);
		}

		if(i6 == 1) {
			world1.setBlockMetadataWithNotify(i2, i3, i4, 5);
		}

		if(i6 == 2) {
			world1.setBlockMetadataWithNotify(i2, i3, i4, 3);
		}

		if(i6 == 3) {
			world1.setBlockMetadataWithNotify(i2, i3, i4, 4);
		}

	}
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        super.onBlockAdded(world, i, j, k);
        this.setDefaultDirection(world, i, j, k);
    }
}
