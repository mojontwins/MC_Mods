package net.minecraft.src;

public class ItemRecipeBook extends Item {
	public ItemRecipeBook(int id) {
		super(id);
		this.setHasSubtypes(true);
		this.setMaxDamage(0);
	}

	public ItemStack onItemRightClick(ItemStack item, World world, EntityPlayer player) {
		if(!world.singleplayerWorld) {
			player.triggerAchievement(StatList.field_25107_A[this.shiftedIndex]);
			ModLoader.OpenGUI(player, mod_RecipeBook.RecipeBookGuiID, player.inventory, new CraftingInventoryRecipeBookCB(new InventoryRecipeBook(item)));
		}
		return item;
	}

	public int getColorFromDamage(int paramInt) {
		return 16752800;
	}
}
