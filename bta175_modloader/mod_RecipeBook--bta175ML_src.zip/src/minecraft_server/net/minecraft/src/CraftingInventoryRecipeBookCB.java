package net.minecraft.src;

public class CraftingInventoryRecipeBookCB extends Container {
	private IInventory inv;

	public CraftingInventoryRecipeBookCB(IInventory inventory) {
		this.inv = inventory;
		int slot = 0;

		for(int r = 0; r < 3; ++r) {
			for(int c = 0; c < 2; ++c) {
				this.addSlot(new Slot(inventory, slot++, 99 + c * 117, 24 + r * 55));

				for(int y = 0; y < 3; ++y) {
					for(int x = 0; x < 3; ++x) {
						this.addSlot(new Slot(inventory, slot++, 5 + x * 18 + c * 117, 6 + y * 18 + r * 55));
					}
				}
			}
		}

	}

	public boolean canInteractWith(EntityPlayer player) {
		return this.inv.canInteractWith(player);
	}

	public ItemStack getStackInSlot(int paramInt) {
		return null;
	}
}
