package net.minecraft.src;

import java.util.List;

public class InventoryRecipeBook implements IInventory {
	private static List<IRecipe> recipes = null;
	private final ItemStack book;
	private int index = -1;
	public ItemStack[][] items = new ItemStack[6][];

	@SuppressWarnings("unchecked")
	public InventoryRecipeBook(ItemStack item) {
		if(recipes == null) {
			try {
				recipes = (List<IRecipe>)ModLoader.getPrivateValue(CraftingManager.class, CraftingManager.getInstance(), 1);
			} catch (Throwable throwable3) {
				throw new RuntimeException(throwable3);
			}
		}

		this.book = item;

		this.index = this.setIndex(this.book != null ? this.book.getItemDamage() : 0);
	}

	public void decIndex() {
		this.index = this.setIndex(this.index - 6);
	}

	public void incIndex() {
		this.index = this.setIndex(this.index + 6);
	}

	public int setIndex(int i) {
		if(this.index == i) {
			return i;
		} else {
			if(i < 0) {
				i = recipes.size() - 1;
			} else if(i >= recipes.size()) {
				i = 0;
			}

			this.items = new ItemStack[6][];

			for(int p = 0; p < 6; ++p) {
				this.items[p] = new ItemStack[10];
				int ip = i + p;
				if(ip < recipes.size()) {
					IRecipe recipe = (IRecipe)recipes.get(ip);

					try {
						int o;
						if(recipe instanceof RecipeShaped) {
							int i12 = ((Integer)ModLoader.getPrivateValue(RecipeShaped.class, (RecipeShaped)recipe, 0)).intValue();
							o = ((Integer)ModLoader.getPrivateValue(RecipeShaped.class, (RecipeShaped)recipe, 1)).intValue();
							if(i12 * o > 9) {
								return this.setIndex(i + 1);
							}

							ItemStack[] temp = (ItemStack[])ModLoader.getPrivateValue(RecipeShaped.class, (RecipeShaped)recipe, 2);
							this.items[p][0] = (ItemStack)ModLoader.getPrivateValue(RecipeShaped.class, (RecipeShaped)recipe, 3);

							for(int o1 = 0; o1 < temp.length; ++o1) {
								int x = o1 % i12;
								int y = o1 / i12;
								this.items[p][x + y * 3 + 1] = temp[o1];
							}
						} else if(recipe instanceof RecipeShapeless) {
							@SuppressWarnings("unchecked")
							List<ItemStack> e = (List<ItemStack>)ModLoader.getPrivateValue(RecipeShapeless.class, (RecipeShapeless)recipe, 1);
							if(e.size() > 9) {
								return this.setIndex(i + 1);
							}

							this.items[p][0] = (ItemStack)ModLoader.getPrivateValue(RecipeShapeless.class, (RecipeShapeless)recipe, 0);

							for(o = 0; o < e.size(); ++o) {
								this.items[p][o + 1] = (ItemStack)e.get(o);
							}
						}
					} catch (Throwable throwable11) {
						ModLoader.getLogger().throwing("RecipeInventory", "setIndex", throwable11);
						ModLoader.ThrowException("Exception in RecipeInventory", throwable11);
					}
				}
			}

			//this.book.setItemDamage(i);
			return i;
		}
	}

	public int getSizeInventory() {
		return 60;
	}

	public ItemStack decrStackSize(int paramInt1, int paramInt2) {
		return null;
	}

	public void setInventorySlotContents(int paramInt, ItemStack item) {
		this.items[paramInt / 10][paramInt % 10] = item;
	}

	public boolean canInteractWith(EntityPlayer player) {
		return true;
	}

	public String getInvName() {
		return String.format("%d / %d", new Object[]{this.index / 6, (recipes.size() - 1) / 6});
	}

	public ItemStack getStackInSlot(int paramInt) {
		return this.items[paramInt / 10][paramInt % 10];
	}

	public int getInventoryStackLimit() {
		return 64;
	}

	public void onInventoryChanged() {
	}
}
