package net.minecraft.src;

public class mod_RecipeBook extends BaseModMp {
	public static Item book;
	
	@MLProp(name="RecipeBookID")
	public static int RecipeBookID = 397;
	
	@MLProp(name="RecipeBookGuiID")
	public static int RecipeBookGuiID = 103;

	public mod_RecipeBook() {
		book = (new ItemRecipeBook(RecipeBookID - 256)).setIconIndex(Item.book.iconIndex).setItemName("recipeBook");
		ModLoader.AddShapelessRecipe(new ItemStack(book, 1), new Object[]{Item.book, new ItemStack(Item.dyePowder, 1, 0)});
	}

	public String Version() {
		return "BTA 1.7.5_01";
	}
}
