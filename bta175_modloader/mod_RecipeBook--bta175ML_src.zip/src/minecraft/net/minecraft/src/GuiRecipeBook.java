package net.minecraft.src;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class GuiRecipeBook extends GuiContainer {
	private InventoryRecipeBook recipes;
	public static final int BORDER = 4;
	public static final int ROWS = 3;
	public static final int COLUMNS = 2;
	public static final int ENTRIES = 6;
	public static final int GRIDX = 5;
	public static final int GRIDY = 6;
	public static final int CRAFTX = 99;
	public static final int CRAFTY = 24;
	public static final int IMGWIDTH = 176;
	public static final int IMGHEIGHT = 166;
	public static final int IMGMIDX = 29;
	public static final int IMGMIDY = 15;
	public static final int MIDWIDTH = 117;
	public static final int MIDHEIGHT = 55;
	private final InventoryRecipeBook inv;

	public GuiRecipeBook(InventoryRecipeBook inventory) {
		super(new CraftingInventoryRecipeBookCB(inventory));
		this.inv = inventory;
		this.xSize = 242;
		this.ySize = 173;
		this.recipes = this.inv;
	}

	protected void drawGuiContainerForegroundLayer() {
		this.fontRenderer.drawString(this.inv.getInvName(), this.xSize - 50, 6, 4210752);
	}

	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
		super.mouseClicked(mouseX, mouseY, mouseButton);
		if(Mouse.isButtonDown(0)) {
			this.recipes.incIndex();
		} else if(Mouse.isButtonDown(1)) {
			this.recipes.decIndex();
		}

	}

	protected void drawGuiContainerBackgroundLayer(float paramFloat) {
		int image = this.mc.renderEngine.getTexture("/gui/crafting.png");
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.mc.renderEngine.bindTexture(image);
		int x = this.width - this.xSize >> 1;
		int y = this.height - this.ySize >> 1;
		int w = (this.xSize - 8) / 2;

		int h;
		for(h = 0; h < 2; ++h) {
			this.drawTexturedModalRect(x + 4 + h * w, y, 4, 0, w, 4);
			this.drawTexturedModalRect(x + 4 + h * w, y + this.ySize - 4, 4, 162, w, 4);
		}

		h = (this.ySize - 8) / 3;

		int i;
		for(i = 0; i < 3; ++i) {
			this.drawTexturedModalRect(x, y + 4 + i * h, 0, 4, 4, h);
			this.drawTexturedModalRect(x + this.xSize - 4, y + 4 + i * h, 172, 4, 4, h);
		}

		this.drawTexturedModalRect(x, y, 0, 0, 4, 4);
		this.drawTexturedModalRect(x + 238, y, 172, 0, 4, 4);
		this.drawTexturedModalRect(x, y + this.ySize - 4, 0, 162, 4, 4);
		this.drawTexturedModalRect(x + this.xSize - 4, y + this.ySize - 4, 172, 162, 4, 4);

		for(i = 0; i < 2; ++i) {
			for(int j = 0; j < 3; ++j) {
				this.drawTexturedModalRect(x + 4 + i * 117, y + 4 + j * 55, 29, 15, 117, 55);
			}
		}

	}

	public boolean doesGuiPauseGame() {
		return true;
	}

	protected void keyTyped(char arg0, int arg1) {
		super.keyTyped(arg0, arg1);
		switch(arg1) {
		case 203:
			this.recipes.decIndex();
		case 204:
		default:
			break;
		case 205:
			this.recipes.incIndex();
		}

	}
}
