package net.minecraft.src;

public class ItemRecipeBook extends Item {
	public ItemRecipeBook(int id) {
		super(id);
		this.setHasSubtypes(true);
		this.setMaxDamage(0);
	}

	public ItemStack onItemRightClick(ItemStack item, World world, EntityPlayer player) {
		if(!world.multiplayerWorld) {
			player.triggerAchievement(StatList.field_25172_A[this.shiftedIndex]);
			ModLoader.OpenGUI(player, new GuiRecipeBook(new InventoryRecipeBook(item)));
		}
		return item;
	}

	public int getColorFromDamage(int paramInt) {
		return 16752800;
	}
}
