package net.minecraft.src;

import java.util.Map;
import java.util.Random;

import com.benimatic.twilightforest.BlockTFHedge;
import com.benimatic.twilightforest.BlockTFMazestone;
import com.benimatic.twilightforest.DimensionTwilightForest;
import com.benimatic.twilightforest.EntityTFHostileWolf;
import com.benimatic.twilightforest.EntityTFPenguin;
import com.benimatic.twilightforest.EntityTFRedcap;
import com.benimatic.twilightforest.EntityTwilightBighorn;
import com.benimatic.twilightforest.EntityTwilightBoar;
import com.benimatic.twilightforest.EntityTwilightDeer;
import com.benimatic.twilightforest.ModelBighornFur;
import com.benimatic.twilightforest.ModelTFPenguin;
import com.benimatic.twilightforest.ModelTFRedcap;
import com.benimatic.twilightforest.ModelTwilightBighorn;
import com.benimatic.twilightforest.ModelTwilightBoar;
import com.benimatic.twilightforest.ModelTwilightDeer;
import com.benimatic.twilightforest.TwlightForestWorld;
import com.benimatic.twilightforest.WorldProviderTwilightForest;

import net.minecraft.client.Minecraft;

public class mod_TwilightForest extends BaseModMp {

	@MLProp(name="dimensionTwilightID")
	public static int dimensionTwilightID = 7;
	
	@MLProp(name="biomeTwilightForestID")
	public static int biomeTwilightForestID = 16;

	@MLProp(name="biomeTwilightClearingsID")
	public static int biomeTwilightClearingsID = 17;
	
	@MLProp(name="biomeTwilightHighlandsID")
	public static int biomeTwilightHighlandsID = 18;
	
	@MLProp(name="biomeTwilightMushroomID")
	public static int biomeTwilightMushroomID = 19;
	
	@MLProp(name="biomeTwilightSwampID")
	public static int biomeTwilightSwampID = 20;
	
	@MLProp(name="biomeTwilightSnowID")
	public static int biomeTwilightSnowID = 21;
	
	@MLProp(name="biomeTwilightGlacierID")
	public static int biomeTwilightGlacierID = 22;
	
	@MLProp(name="blockMazestoneID")
	public static int blockMazestoneID = 152;
	
	@MLProp(name="blockHedgeID")
	public static int blockHedgeID = 153;

	@MLProp(name="entityWildBoarID")
	public static int entityWildBoarID = 2000;

	@MLProp(name="entityBigHornSheepID")
	public static int entityBigHornSheepID = 2001;

	@MLProp(name="entityWildDeerID")
	public static int entityWildDeerID = 2002;

	@MLProp(name="entityHostileWolfID")
	public static int entityWildDeerID = 2003;

	@MLProp(name="entityRedcapID")
	public static int entityRedcapID = 2004;

	@MLProp(name="entityRedcapID")
	public static int entityPenguinID = 2005;

	// Next free 2018
	
	@MLProp(
		name = "generateSupplyChest",
		info = "Sets whether should Twilight Forest generate supply chest on creating a new world or shouldn\'t",
		min = 0.0D,
		max = 1.0D
	)
	public static boolean generateSupplyChest = true;
	
	public static Block blockMazestone;
	public static Block blockHedge;
	public static Dimension dimensionTwilightForest = new DimensionTwilightForest();
	
	public mod_TwilightForest() {
		ModLoader.SetInGameHook(this, true, true);
		ModLoader.SetInGUIHook(this, true, true);
		
		ModLoader.RegisterEntityID(EntityTwilightBoar.class, "Wild Boar", entityWildBoarID);
		ModLoader.RegisterEntityID(EntityTwilightBighorn.class, "Bighorn Sheep", entityBigHornSheepID);
		ModLoader.RegisterEntityID(EntityTwilightDeer.class, "Wild Deer", entityWildDeerID);
		ModLoader.RegisterEntityID(EntityTFHostileWolf.class, "Hostile Wolf", entityHostileWolfID);
		ModLoader.RegisterEntityID(EntityTFRedcap.class, "Redcap", entityRedcapID);
		ModLoader.RegisterEntityID(EntityTFPenguin.class, "Penguin", entityPenguinID);

		blockMazestone = (new BlockTFMazestone(blockMazestoneID))
				.setHardness(20.0F)
				.setResistance(5.0F)
				.setStepSound(Block.soundMetalFootstep).setBlockName("blockMazestone");
		
		ModLoader.RegisterBlock(blockMazestone);

		blockHedge = (new BlockTFHedge(blockHedgeID))
				.setHardness(5.0F)
				.setResistance(10.0F)
				.setStepSound(Block.soundGrassFootstep).setBlockName("blockHedge");
		
		ModLoader.RegisterBlock(blockHedge);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void AddRenderer(Map map) {
		map.put(EntityTwilightBoar.class, new RenderPig(new ModelTwilightBoar(), new ModelPig(0.5F), 0.7F));
		map.put(EntityTwilightBighorn.class, new RenderSheep(new ModelTwilightBighorn(), new ModelBighornFur(), 0.7F));
		map.put(EntityTwilightDeer.class, new RenderCow(new ModelTwilightDeer(), 0.7F));
		map.put(EntityTFRedcap.class, new RenderBiped(new ModelTFRedcap(), 0.625F));
		map.put(EntityTFPenguin.class, new RenderChicken(new ModelTFPenguin(), 1.0F));
	}
	
	@Override
	public void GenerateSurface(World world, Random random, int i, int j) {
		if(generateSupplyChest) {
			int k = world.worldInfo.getSpawnX();
			int l = world.worldInfo.getSpawnZ();
			if(k != 0 && l != 0 && k >= i && k <= i + 16 && l >= j && l <= j + 16) {
				System.out.println("Making supply chest at " + k + ", " + l);
				int i1 = k + random.nextInt(8) - random.nextInt(8);
				int j1 = l + random.nextInt(8) - random.nextInt(8);
				int k1 = world.findTopSolidBlock(i1, j1);
				world.setBlockWithNotify(i1, k1, j1, Block.chest.blockID);
				TileEntityChest tileentitychest = (TileEntityChest)world.getBlockTileEntity(i1, k1, j1);
				if(tileentitychest != null && tileentitychest.getSizeInventory() > 0) {
					ItemStack itemstack = new ItemStack(Item.appleGold);
					tileentitychest.setInventorySlotContents(0, itemstack);
					ItemStack itemstack1 = new ItemStack(Item.pickaxeDiamond);
					tileentitychest.setInventorySlotContents(1, itemstack1);
					ItemStack itemstack2 = new ItemStack(Item.shovelDiamond);
					tileentitychest.setInventorySlotContents(2, itemstack2);
					ItemStack itemstack3 = new ItemStack(Item.axeDiamond);
					tileentitychest.setInventorySlotContents(3, itemstack3);
					ItemStack itemstack4 = new ItemStack(Item.swordSteel);
					tileentitychest.setInventorySlotContents(4, itemstack4);
					ItemStack itemstack5 = new ItemStack(Block.obsidian, 14);
					tileentitychest.setInventorySlotContents(5, itemstack5);
					ItemStack itemstack6 = new ItemStack(Item.flintAndSteel);
					tileentitychest.setInventorySlotContents(6, itemstack6);
					ItemStack itemstack7 = new ItemStack(Block.mushroomRed, 64);
					tileentitychest.setInventorySlotContents(7, itemstack7);
				}
			}
		}

	}

	@Override
	public boolean OnTickInGame(Minecraft minecraft) {
		if(!minecraft.theWorld.multiplayerWorld && minecraft.thePlayer != null && (double)minecraft.thePlayer.timeInPortal > 0.8D && minecraft.thePlayer.timeUntilPortal == 0) {
			this.interceptPortal(minecraft);
		}

		if(minecraft.thePlayer != null && minecraft.thePlayer.dimension == 7 && !(minecraft.theWorld.dimension.worldProvider instanceof WorldProviderTwilightForest)) {
			this.sendToTwilightForest(minecraft);
		}

		return true;
	}
	
	@Override
	public boolean OnTickInGUI(Minecraft minecraft, GuiScreen gui) {
		if(minecraft.thePlayer != null && minecraft.thePlayer.dimension == 7 && !(minecraft.theWorld.dimension.worldProvider instanceof WorldProviderTwilightForest)) {
			this.sendToTwilightForest(minecraft);
		}

		return true;
	}
	
	public void interceptPortal(Minecraft minecraft) {
		ItemStack itemstack = minecraft.thePlayer.inventory.getCurrentItem();
		if(minecraft.thePlayer.dimension == 7) {
			this.usePortal(minecraft, 0);
		} else if(minecraft.thePlayer.dimension == 0 && itemstack != null && itemstack.itemID == (byte)Block.mushroomRed.blockID) {
			this.usePortal(minecraft, 7);
		}

	}

	public void usePortal(Minecraft minecraft, int i) {
		Dimension oldDim = null;
		Dimension newDim = null;
		
		minecraft.thePlayer.timeUntilPortal = 10;
		minecraft.thePlayer.timeInPortal = 0.0F;
		if(i == 0) {
			this.sendToSurface(minecraft);
			oldDim = dimensionTwilightForest; newDim = Dimension.overworld;
		} else if(i == 7) {
			this.sendToTwilightForest(minecraft);
			oldDim = Dimension.overworld; newDim = dimensionTwilightForest;
		}

		if(minecraft.thePlayer.isEntityAlive()) {
			minecraft.thePlayer.setLocationAndAngles(minecraft.thePlayer.posX, minecraft.thePlayer.posY, minecraft.thePlayer.posZ, minecraft.thePlayer.rotationYaw, minecraft.thePlayer.rotationPitch);
			minecraft.theWorld.updateEntityWithOptionalForce(minecraft.thePlayer, false);
			(new Teleporter()).func_4107_a(minecraft.theWorld, minecraft.thePlayer, oldDim, newDim);
		}

	}

	public void sendToTwilightForest(Minecraft minecraft) {
		minecraft.theWorld.setEntityDead(minecraft.thePlayer);
		minecraft.thePlayer.isDead = false;
		double d = minecraft.thePlayer.posY;
		if(minecraft.thePlayer.dimension == 0) {
			d *= 0.25D;
		}

		minecraft.thePlayer.setLocationAndAngles(minecraft.thePlayer.posX, d, minecraft.thePlayer.posZ, minecraft.thePlayer.rotationYaw, minecraft.thePlayer.rotationPitch);
		if(minecraft.thePlayer.isEntityAlive()) {
			minecraft.theWorld.updateEntityWithOptionalForce(minecraft.thePlayer, false);
		}

		TwlightForestWorld twlightforestworld = null;
		twlightforestworld = new TwlightForestWorld(minecraft.theWorld, dimensionTwilightForest);
		minecraft.changeWorld(twlightforestworld, "Entering the Twilight Forest", minecraft.thePlayer);
		minecraft.thePlayer.worldObj = minecraft.theWorld;
		minecraft.thePlayer.dimension = 7;
	}

	public void sendToSurface(Minecraft minecraft) {
		minecraft.theWorld.setEntityDead(minecraft.thePlayer);
		minecraft.thePlayer.isDead = false;
		double d = minecraft.thePlayer.posY;
		if(minecraft.thePlayer.dimension == 0) {
			d *= 4.0D;
		}

		minecraft.thePlayer.setLocationAndAngles(minecraft.thePlayer.posX, d, minecraft.thePlayer.posZ, minecraft.thePlayer.rotationYaw, minecraft.thePlayer.rotationPitch);
		if(minecraft.thePlayer.isEntityAlive()) {
			minecraft.theWorld.updateEntityWithOptionalForce(minecraft.thePlayer, false);
		}

		World world = null;
		world = new World(minecraft.theWorld, Dimension.overworld);
		minecraft.changeWorld(world, "Leaving the Twilight Forest", minecraft.thePlayer);
		minecraft.thePlayer.worldObj = minecraft.theWorld;
		minecraft.thePlayer.dimension = 0;
	}
	
	@Override
	public String Version() {
		return "BTA 1.7.5_01 v0.1p3";
	}

}
