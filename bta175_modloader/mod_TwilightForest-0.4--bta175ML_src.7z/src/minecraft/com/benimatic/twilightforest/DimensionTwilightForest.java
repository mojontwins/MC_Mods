package com.benimatic.twilightforest;

import net.minecraft.src.Block;
import net.minecraft.src.Dimension;
import net.minecraft.src.mod_TwilightForest;

public class DimensionTwilightForest extends Dimension {
	public DimensionTwilightForest() {
		super(mod_TwilightForest.dimensionTwilightID, "twilightForest", overworld, new WorldProviderTwilightForest(), 1.0F, Block.portalNether.blockID);
	}
}
