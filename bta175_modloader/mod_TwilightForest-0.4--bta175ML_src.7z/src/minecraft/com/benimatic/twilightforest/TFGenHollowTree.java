package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.World;

public class TFGenHollowTree extends TFGenerator {
	private Random treeRNG;
	private int x;
	private int y;
	private int z;
	private int height;
	private int diameter;
	private byte treeBlock;
	private byte leafBlock;
	static int treesMade = 0;
	static long totalTime = 0L;
	int leafBlobsMade;
	int leavesMade;

	public boolean generate(World world, Random random, int treeX, int treeY, int treeZ) {
		long startTime = System.currentTimeMillis();
		this.worldObj = world;
		this.treeRNG = random;
		this.x = treeX;
		this.y = treeY;
		this.z = treeZ;
		this.treeBlock = (byte)Block.wood.blockID;
		this.leafBlock = (byte)Block.leaves.blockID;
		this.leafBlobsMade = 0;
		this.height = this.treeRNG.nextInt(64) + 32;
		this.diameter = this.treeRNG.nextInt(4) + 1;
		if(this.y >= 1 && this.y + this.height + this.diameter + 1 <= 128) {
			int crownRadius;
			int j1;
			int numBranches;
			int numFireflies;
			for(crownRadius = -this.diameter; crownRadius <= this.diameter; ++crownRadius) {
				for(j1 = -this.diameter; j1 <= this.diameter; ++j1) {
					for(numBranches = 0; numBranches <= this.y + this.height; ++numBranches) {
						numFireflies = this.worldObj.getBlockId(crownRadius + this.x, numBranches + this.y, j1 + this.z);
						if(numFireflies != 0 && numFireflies != Block.leaves.blockID) {
							return false;
						}
					}
				}
			}

			crownRadius = this.diameter * 4 + 8;

			int timeSpent;
			for(j1 = -crownRadius; j1 <= crownRadius; ++j1) {
				for(numBranches = -crownRadius; numBranches <= crownRadius; ++numBranches) {
					for(numFireflies = this.height - crownRadius; numFireflies <= this.height + crownRadius; ++numFireflies) {
						timeSpent = this.worldObj.getBlockId(j1 + this.x, numFireflies + this.y, numBranches + this.z);
						if(timeSpent != 0 && timeSpent != Block.leaves.blockID) {
							return false;
						}
					}
				}
			}

			j1 = world.getBlockId(this.x, this.y - 1, this.z);
			if((j1 == Block.grass.blockID || j1 == Block.dirt.blockID) && this.y < 128 - this.height - 1) {
				this.buildTrunk();
				this.buildFullCrown();
				numBranches = this.treeRNG.nextInt(3) + 3;

				for(numFireflies = 0; numFireflies <= numBranches; ++numFireflies) {
					timeSpent = (int)((double)this.height * this.treeRNG.nextDouble() * 0.9D) + this.height / 10;
					double fHeight = this.treeRNG.nextDouble();
					this.makeSmallBranch(timeSpent, 4.0D, fHeight, 0.35D, true);
				}

				this.buildBranchRing(3, 2, 6, 0, 0.75D, 0.0D, 3, 5, 3, false);
				numFireflies = this.treeRNG.nextInt(3) + 3;

				for(timeSpent = 0; timeSpent <= numFireflies; ++timeSpent) {
					int i17 = (int)((double)this.height * this.treeRNG.nextDouble() * 0.9D) + this.height / 10;
					double fAngle = this.treeRNG.nextDouble();
					this.addFirefly(i17, fAngle);
				}

				++treesMade;
				long j16 = System.currentTimeMillis() - startTime;
				totalTime += j16;
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private void buildFullCrown() {
		int crownRadius = this.diameter * 4 + 4;
		int bvar = this.diameter + 2;
		this.buildBranchRing(this.height - crownRadius, 0, crownRadius, 0, 0.35D, 0.0D, bvar, bvar + 2, 2, true);
		this.buildBranchRing(this.height - crownRadius / 2, 0, crownRadius, 0, 0.28D, 0.0D, bvar, bvar + 2, 1, true);
		this.buildBranchRing(this.height, 0, crownRadius, 0, 0.15D, 0.0D, 2, 4, 2, true);
		this.buildBranchRing(this.height, 0, crownRadius / 2, 0, 0.05D, 0.0D, bvar, bvar + 2, 1, true);
	}

	@SuppressWarnings("unused")
	private void buildWeakCrown() {
		byte crownRadius = 8;
		byte bvar = 2;
		this.buildBranchRing(this.height - crownRadius, 0, crownRadius, 0, 0.35D, 0.0D, bvar, bvar + 2, 1, true);
		this.buildBranchRing(this.height - crownRadius / 2, 0, crownRadius, 0, 0.28D, 0.0D, bvar, bvar + 2, 1, true);
		this.buildBranchRing(this.height, 0, crownRadius, 0, 0.15D, 0.0D, 2, 4, 1, true);
		this.buildBranchRing(this.height, 0, crownRadius / 2, 0, 0.05D, 0.0D, bvar, bvar + 2, 1, true);
	}

	private void buildBranchRing(int branchHeight, int heightVar, int length, int lengthVar, double tilt, double tiltVar, int minBranches, int maxBranches, int size, boolean leafy) {
		int numBranches = this.treeRNG.nextInt(maxBranches - minBranches) + minBranches;
		double branchRotation = 1.0D / (double)numBranches;
		double branchOffset = this.treeRNG.nextDouble();

		for(int i = 0; i <= numBranches; ++i) {
			int dHeight;
			if(heightVar > 0) {
				dHeight = branchHeight - heightVar + this.treeRNG.nextInt(2 * heightVar);
			} else {
				dHeight = branchHeight;
			}

			if(size == 2) {
				this.makeLargeBranch(dHeight, (double)length, (double)i * branchRotation + branchOffset, tilt, leafy);
			} else if(size == 1) {
				this.makeMedBranch(dHeight, (double)length, (double)i * branchRotation + branchOffset, tilt, leafy);
			} else if(size == 3) {
				this.makeRoot(dHeight, (double)length, (double)i * branchRotation + branchOffset, tilt);
			} else {
				this.makeSmallBranch(dHeight, (double)length, (double)i * branchRotation + branchOffset, tilt, leafy);
			}
		}

	}

	private void buildTrunk() {
		int hollow = this.diameter / 2;

		int dx;
		int dz;
		int dy;
		int ax;
		int az;
		int dist;
		for(dx = -this.diameter; dx <= this.diameter; ++dx) {
			for(dz = -this.diameter; dz <= this.diameter; ++dz) {
				for(dy = 0; dy <= this.height; ++dy) {
					ax = Math.abs(dx);
					az = Math.abs(dz);
					dist = (int)((double)Math.max(ax, az) + (double)Math.min(ax, az) * 0.5D);
					if(dist <= this.diameter && dist > hollow) {
						this.putBlock(dx + this.x, dy + this.y, dz + this.z, this.treeBlock, true);
					}

					if(dist <= hollow) {
						;
					}

					if(dist == hollow && dx == hollow) {
						this.putBlockAndMetadata(dx + this.x, dy + this.y, dz + this.z, Block.ladder.blockID, 4, true);
					}
				}
			}
		}

		for(dx = -this.diameter; dx <= this.diameter; ++dx) {
			for(dz = -this.diameter; dz <= this.diameter; ++dz) {
				for(dy = -4; dy < 0; ++dy) {
					ax = Math.abs(dx);
					az = Math.abs(dz);
					dist = (int)((double)Math.max(ax, az) + (double)Math.min(ax, az) * 0.5D);
					if(dist <= this.diameter && dist > hollow) {
						this.putBlock(dx + this.x, dy + this.y, dz + this.z, this.treeBlock, false);
					}
				}
			}
		}

	}

	private void makeMedBranch(int branchHeight, double length, double angle, double tilt, boolean leafy) {
		int sx = this.x;
		int sy = this.y + branchHeight;
		int sz = this.z;
		int[] src = this.translate(sx, sy, sz, (double)this.diameter, angle, 0.5D);
		this.makeMedBranch(src[0], src[1], src[2], length, angle, tilt, leafy);
	}

	private void makeMedBranch(int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
		int[] src = new int[]{sx, sy, sz};
		int[] dest = this.translate(src[0], src[1], src[2], length, angle, tilt);
		this.drawBresehnam(src[0], src[1], src[2], dest[0], dest[1], dest[2], this.treeBlock, true);
		if(leafy) {
			this.drawBlob(dest[0], dest[1], dest[2], (byte)2, this.leafBlock, false);
		}

		int numShoots = this.treeRNG.nextInt(2) + 1;
		double angleInc = 0.8D / (double)numShoots;

		for(int i = 0; i <= numShoots; ++i) {
			double angleVar = angleInc * (double)i - 0.4D;
			double outVar = this.treeRNG.nextDouble() * 0.8D + 0.2D;
			double tiltVar = this.treeRNG.nextDouble() * 0.75D + 0.15D;
			int[] bsrc = this.translate(src[0], src[1], src[2], length * outVar, angle, tilt);
			double slength = length * 0.4D;
			this.makeSmallBranch(bsrc[0], bsrc[1], bsrc[2], slength, angle + angleVar, tilt * tiltVar, leafy);
		}

	}

	private void makeSmallBranch(int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
		int[] src = new int[]{sx, sy, sz};
		int[] dest = this.translate(src[0], src[1], src[2], length, angle, tilt);
		this.drawBresehnam(src[0], src[1], src[2], dest[0], dest[1], dest[2], this.treeBlock, true);
		if(leafy) {
			byte leafRad = (byte)(this.treeRNG.nextInt(2) + 1);
			this.drawBlob(dest[0], dest[1], dest[2], leafRad, this.leafBlock, false);
		}

	}

	private void makeSmallBranch(int branchHeight, double length, double angle, double tilt, boolean leafy) {
		int sx = this.x;
		int sy = this.y + branchHeight;
		int sz = this.z;
		int[] src = this.translate(sx, sy, sz, (double)this.diameter, angle, 0.5D);
		this.makeSmallBranch(src[0], src[1], src[2], length, angle, tilt, leafy);
	}

	private void makeRoot(int branchHeight, double length, double angle, double tilt) {
		int[] src = this.translate(this.x, this.y + branchHeight, this.z, (double)this.diameter, angle, 0.5D);
		int[] dest = this.translate(src[0], src[1], src[2], length, angle, tilt);
		this.drawBresehnam(src[0], src[1], src[2], dest[0], dest[1], dest[2], this.treeBlock, true);
		this.drawBresehnam(src[0], src[1] - 1, src[2], dest[0], dest[1] - 1, dest[2], this.treeBlock, true);
	}

	private void makeLargeBranch(int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
		int[] src = new int[]{sx, sy, sz};
		int[] dest = this.translate(src[0], src[1], src[2], length, angle, tilt);
		this.drawBresehnam(src[0], src[1], src[2], dest[0], dest[1], dest[2], this.treeBlock, true);
		int reinforcements = this.treeRNG.nextInt(3);

		int numMedBranches;
		int numSmallBranches;
		int i;
		for(numMedBranches = 0; numMedBranches <= reinforcements; ++numMedBranches) {
			numSmallBranches = (numMedBranches & 2) == 0 ? 1 : 0;
			i = (numMedBranches & 1) == 0 ? 1 : -1;
			int outVar = (numMedBranches & 2) == 0 ? 0 : 1;
			this.drawBresehnam(src[0] + numSmallBranches, src[1] + i, src[2] + outVar, dest[0], dest[1], dest[2], this.treeBlock, true);
		}

		if(leafy) {
			this.drawBlob(dest[0], dest[1] + 1, dest[2], (byte)3, this.leafBlock, false);
		}

		numMedBranches = this.treeRNG.nextInt((int)(length / 6.0D)) + this.treeRNG.nextInt(2) + 1;

		for(numSmallBranches = 0; numSmallBranches <= numMedBranches; ++numSmallBranches) {
			double d22 = this.treeRNG.nextDouble() * 0.3D + 0.3D;
			double angleVar = this.treeRNG.nextDouble() * 0.225D * ((numSmallBranches & 1) == 0 ? 1.0D : -1.0D);
			int[] bsrc = this.translate(src[0], src[1], src[2], length * d22, angle, tilt);
			this.makeMedBranch(bsrc[0], bsrc[1], bsrc[2], length * 0.6D, angle + angleVar, tilt, leafy);
		}

		numSmallBranches = this.treeRNG.nextInt(2) + 1;

		for(i = 0; i <= numSmallBranches; ++i) {
			double d23 = this.treeRNG.nextDouble() * 0.25D + 0.25D;
			double angleVar1 = this.treeRNG.nextDouble() * 0.25D * ((i & 1) == 0 ? 1.0D : -1.0D);
			int[] bsrc1 = this.translate(src[0], src[1], src[2], length * d23, angle, tilt);
			this.makeSmallBranch(bsrc1[0], bsrc1[1], bsrc1[2], Math.max(length * 0.3D, 2.0D), angle + angleVar1, tilt, leafy);
		}

	}

	private void makeLargeBranch(int branchHeight, double length, double angle, double tilt, boolean leafy) {
		int sx = this.x;
		int sy = this.y + branchHeight;
		int sz = this.z;
		int[] src = this.translate(sx, sy, sz, (double)this.diameter, angle, 0.5D);
		this.makeLargeBranch(src[0], src[1], src[2], length, angle, tilt, leafy);
	}

	private void addFirefly(int fHeight, double fAngle) {
		int[] src = this.translate(this.x, this.y + fHeight, this.z, (double)(this.diameter + 1), fAngle, 0.5D);
		fAngle %= 1.0D;
		if(fAngle <= 0.875D && fAngle > 0.125D) {
			if(fAngle <= 0.125D && fAngle > 0.375D) {
				if(fAngle <= 0.375D && fAngle > 0.625D) {
					if((fAngle > 0.625D || fAngle <= 0.875D) && this.worldObj.isBlockNormalCube(src[0], src[1], src[2] - 1)) {
						this.putBlockAndMetadata(src[0], src[1], src[2], Block.torchWood.blockID, 4, false);
					}
				} else if(this.worldObj.isBlockNormalCube(src[0] - 1, src[1], src[2])) {
					this.putBlockAndMetadata(src[0], src[1], src[2], Block.torchWood.blockID, 1, false);
				}
			} else if(this.worldObj.isBlockNormalCube(src[0], src[1], src[2] - 1)) {
				this.putBlockAndMetadata(src[0], src[1], src[2], Block.torchWood.blockID, 3, false);
			}
		} else if(this.worldObj.isBlockNormalCube(src[0] + 1, src[1], src[2])) {
			this.putBlockAndMetadata(src[0], src[1], src[2], Block.torchWood.blockID, 2, false);
		}

	}

	private void drawBlob(int sx, int sy, int sz, byte rad, byte blockValue, boolean priority) {
		for(byte dx = 0; dx <= rad; ++dx) {
			for(byte dy = 0; dy <= rad; ++dy) {
				for(byte dz = 0; dz <= rad; ++dz) {
					byte b11;
					if(dx >= dy && dx >= dz) {
						b11 = (byte)(dx + (byte)((int)((double)Math.max(dy, dz) * 0.5D + (double)Math.min(dy, dz) * 0.25D)));
					} else if(dy >= dx && dy >= dz) {
						b11 = (byte)(dy + (byte)((int)((double)Math.max(dx, dz) * 0.5D + (double)Math.min(dx, dz) * 0.25D)));
					} else {
						b11 = (byte)(dz + (byte)((int)((double)Math.max(dx, dy) * 0.5D + (double)Math.min(dx, dy) * 0.25D)));
					}

					if(b11 <= rad) {
						this.putBlock(sx + dx, sy + dy, sz + dz, blockValue, priority);
						this.putBlock(sx + dx, sy + dy, sz - dz, blockValue, priority);
						this.putBlock(sx - dx, sy + dy, sz + dz, blockValue, priority);
						this.putBlock(sx - dx, sy + dy, sz - dz, blockValue, priority);
						this.putBlock(sx + dx, sy - dy, sz + dz, blockValue, priority);
						this.putBlock(sx + dx, sy - dy, sz - dz, blockValue, priority);
						this.putBlock(sx - dx, sy - dy, sz + dz, blockValue, priority);
						this.putBlock(sx - dx, sy - dy, sz - dz, blockValue, priority);
					}
				}
			}
		}

		++this.leafBlobsMade;
	}
}
