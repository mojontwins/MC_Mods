package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.EntityChicken;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.SpawnListEntry;
import net.minecraft.src.WorldGenBigTree;
import net.minecraft.src.WorldGenForest;
import net.minecraft.src.WorldGenTrees;
import net.minecraft.src.WorldGenerator;
import net.minecraft.src.mod_TwilightForest;

public class TFBiomeGenBase extends BiomeGenBase {
	private static BiomeGenBase[] biomeLookupTable = new BiomeGenBase[4096];
	public static final BiomeGenBase twilightForest = (new TFBiomeGenTwilightForest(mod_TwilightForest.biomeTwilightForestID)).setColor(30464).setBiomeName("TwilightForest");
	public static final BiomeGenBase twilightClearings = (new TFBiomeGenTwilightForest(mod_TwilightForest.biomeTwilightClearingsID)).setColor(10079385).setBiomeName("TwilightClearings");
	public static final BiomeGenBase twilightHighland = (new TFBiomeGenHighlands(mod_TwilightForest.biomeTwilightHighlandsID)).setColor(6710886).setBiomeName("TwilightHighland");
	public static final BiomeGenBase twilightMushroom = (new TFBiomeGenTwilightForest(mod_TwilightForest.biomeTwilightMushroomID)).setColor(10053171).setBiomeName("TwilightMushroom");
	public static final BiomeGenBase twilightSwamp = (new TFBiomeGenSwamp(mod_TwilightForest.biomeTwilightSwampID)).setColor(10066227).setBiomeName("TwilightSwamp");
	public static final BiomeGenBase twilightSnow = (new TFBiomeGenSnow(mod_TwilightForest.biomeTwilightSnowID)).setColor(13434879).setBiomeName("TwilightSnow");
	public static final BiomeGenBase twilightGlacier = (new TFBiomeGenGlacier(mod_TwilightForest.biomeTwilightGlacierID)).setColor(15658734).setBiomeName("TwilightGlacier");

	protected TFBiomeGenBase(int id) {
		super(id);
		
		this.spawnableMonsterList.clear();
		this.spawnableWaterCreatureList.clear();
		this.spawnableCreatureList.clear();
		this.spawnableCreatureList.add(new SpawnListEntry(EntityTwilightBighorn.class, 12));
		this.spawnableCreatureList.add(new SpawnListEntry(EntityTwilightBoar.class, 10));
		this.spawnableCreatureList.add(new SpawnListEntry(EntityChicken.class, 10));
		this.spawnableCreatureList.add(new SpawnListEntry(EntityTwilightDeer.class, 15));
		this.spawnableCreatureList.add(new SpawnListEntry(EntityWolf.class, 2));
	}

	public static void a() {
		for(int i = 0; i < 64; ++i) {
			for(int j = 0; j < 64; ++j) {
				biomeLookupTable[i + j * 64] = a((float)i / 63.0F, (float)j / 63.0F);
			}
		}

	}

	public static BiomeGenBase a(double temperature, double humidity) {
		int i = (int)(temperature * 63.0D);
		int j = (int)(humidity * 63.0D);
		return biomeLookupTable[i + j * 64];
	}

	public WorldGenerator getRandomWorldGenForTrees(Random random) {
		return (WorldGenerator)(random.nextInt(5) == 0 ? new TFGenCanopyTree() : (random.nextInt(10) == 0 ? new WorldGenForest() : (random.nextInt(7) == 0 ? new WorldGenBigTree() : new WorldGenTrees())));
	}

	public static BiomeGenBase a(float t, float h) {
		h *= t;
		return (double)h > 0.75D ? ((double)h > 0.825D ? twilightSwamp : twilightClearings) : ((double)h > 0.675D && (double)t < 0.75D ? twilightMushroom : ((double)t < 0.25D ? ((double)t < 0.1D ? twilightGlacier : twilightSnow) : ((double)t > 0.75D && (double)h < 1.0D - (double)t ? twilightHighland : twilightForest)));
	}

	static {
		a();
	}
}
