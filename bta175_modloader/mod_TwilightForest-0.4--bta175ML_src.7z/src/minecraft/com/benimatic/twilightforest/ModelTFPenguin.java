package com.benimatic.twilightforest;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelTFPenguin extends ModelBase {
	ModelRenderer body;
	ModelRenderer rightarm;
	ModelRenderer leftarm;
	ModelRenderer rightleg;
	ModelRenderer leftleg;
	ModelRenderer head;
	ModelRenderer beak;

	public ModelTFPenguin() {
		this.body = new ModelRenderer( 32, 0);
		this.body.addBox(-4.0F, 0.0F, -4.0F, 8, 9, 8);
		this.body.setRotationPoint(0.0F, 14.0F, 0.0F);
		this.rightarm = new ModelRenderer( 34, 18);
		this.rightarm.addBox(-1.0F, -1.0F, -2.0F, 1, 8, 4);
		this.rightarm.setRotationPoint(-4.0F, 15.0F, 0.0F);
		this.leftarm = new ModelRenderer( 24, 18);
		this.leftarm.addBox(0.0F, -1.0F, -2.0F, 1, 8, 4);
		this.leftarm.setRotationPoint(4.0F, 15.0F, 0.0F);
		this.leftarm.mirror = true;
		this.rightleg = new ModelRenderer( 0, 16);
		this.rightleg.addBox(-2.0F, 0.0F, -5.0F, 4, 1, 8);
		this.rightleg.setRotationPoint(-2.0F, 23.0F, 0.0F);
		this.leftleg = new ModelRenderer( 0, 16);
		this.leftleg.addBox(-2.0F, 0.0F, -5.0F, 4, 1, 8);
		this.leftleg.setRotationPoint(2.0F, 23.0F, 0.0F);
		this.head = new ModelRenderer( 0, 0);
		this.head.addBox(-3.5F, -4.0F, -3.5F, 7, 5, 7);
		this.head.setRotationPoint(0.0F, 13.0F, 0.0F);
		this.beak = new ModelRenderer( 0, 13);
		this.beak.addBox(-1.0F, 0.0F, -1.0F, 2, 1, 2);
		this.beak.setRotationPoint(0.0F, -1.0F, -4.0F);
	}

	@Override
	public void render(float par2, float par3, float par4, float par5, float par6, float par7) {
		this.setRotationAngles(par2, par3, par4, par5, par6, par7);

		this.head.render(par7);
		this.body.render(par7);
		this.rightleg.render(par7);
		this.leftleg.render(par7);
		this.rightarm.render(par7);
		this.leftarm.render(par7);

	}

	@Override
	public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6) {
		this.head.rotateAngleX = par5 / 57.295776F;
		this.head.rotateAngleY = par4 / 57.295776F;
		this.rightleg.rotateAngleX = MathHelper.cos(par1) * 0.7F * par2;
		this.leftleg.rotateAngleX = MathHelper.cos(par1 + (float)Math.PI) * 0.7F * par2;
		this.rightarm.rotateAngleZ = par3;
		this.leftarm.rotateAngleZ = -par3;
	}
}
