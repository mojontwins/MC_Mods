package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.WorldGenBigTree;
import net.minecraft.src.WorldGenForest;
import net.minecraft.src.WorldGenTrees;
import net.minecraft.src.WorldGenerator;

public class TFBiomeGenHighlands extends TFBiomeGenBase {
	protected TFBiomeGenHighlands(int id) {
		super(id);
	}

	public WorldGenerator getRandomWorldGenForTrees(Random random) {
		return (WorldGenerator)(random.nextInt(10) == 0 ? new WorldGenForest() : (random.nextInt(7) == 0 ? new WorldGenBigTree() : new WorldGenTrees()));
	}
}
