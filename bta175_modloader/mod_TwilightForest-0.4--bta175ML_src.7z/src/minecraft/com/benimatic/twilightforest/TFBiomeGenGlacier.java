package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.SpawnListEntry;
import net.minecraft.src.WorldGenTaiga1;
import net.minecraft.src.WorldGenTaiga2;
import net.minecraft.src.WorldGenerator;

public class TFBiomeGenGlacier extends TFBiomeGenBase {
	protected TFBiomeGenGlacier(int id) {
		super(id);
		
		this.spawnableCreatureList.add(new SpawnListEntry(EntityTFPenguin.class, 12));
	}

	public WorldGenerator getRandomWorldGenForTrees(Random random) {
		return (WorldGenerator)(random.nextInt(3) == 0 ? new WorldGenTaiga1() : new WorldGenTaiga2());
	}
}
