package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.WorldGenTaiga1;
import net.minecraft.src.WorldGenTaiga2;
import net.minecraft.src.WorldGenerator;

public class TFBiomeGenSnow extends TFBiomeGenBase {
	protected TFBiomeGenSnow(int id) {
		super(id);
	}

	public WorldGenerator getRandomWorldGenForTrees(Random random) {
		return (WorldGenerator)(random.nextInt(3) == 0 ? new WorldGenTaiga1() : new WorldGenTaiga2());
	}
}
