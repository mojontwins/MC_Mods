package com.benimatic.twilightforest;

import java.io.File;

import net.minecraft.src.ChunkLoader;
import net.minecraft.src.ChunkProvider;
import net.minecraft.src.Dimension;
import net.minecraft.src.IChunkLoader;
import net.minecraft.src.IChunkProvider;
import net.minecraft.src.McRegionChunkLoader;
import net.minecraft.src.SaveHandler;
import net.minecraft.src.SaveOldDir;
import net.minecraft.src.World;

public class TwlightForestWorld extends World {
	public TwlightForestWorld(World world, Dimension dimension) {
		super(world, dimension);
		this.chunkProvider = this.getChunkProvider();
	}

	protected IChunkProvider getChunkProvider() {
		System.out.println("Trying to give the secret directory");
		File saveDirectory = ((SaveHandler)this.saveHandler).getSaveDirectory();
		Object ichunkloader = null;
		File file1;
		if(this.saveHandler instanceof SaveOldDir) {
			file1 = new File(saveDirectory, "DIM7");
			file1.mkdirs();
			ichunkloader = new McRegionChunkLoader(file1);
		} else if(this.saveHandler instanceof SaveHandler) {
			file1 = new File(saveDirectory, "DIM7");
			file1.mkdirs();
			ichunkloader = new ChunkLoader(file1, true);
		}

		return new ChunkProvider(this, (IChunkLoader)ichunkloader, this.dimension.worldProvider.getChunkProvider());
	}
}
