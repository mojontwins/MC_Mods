package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.World;

public class TFGenStream extends TFGenerator {
	@SuppressWarnings("unused")
	public boolean generate(World world, Random random, int x, int y, int z) {
		this.worldObj = world;
		int streamLength = 80 + random.nextInt(20);
		double streamAngle = random.nextDouble();
		return false;
	}
}
