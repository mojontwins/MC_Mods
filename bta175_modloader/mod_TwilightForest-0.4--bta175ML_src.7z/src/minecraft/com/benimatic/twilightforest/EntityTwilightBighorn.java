package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.EntitySheep;
import net.minecraft.src.World;

public class EntityTwilightBighorn extends EntitySheep {
	public EntityTwilightBighorn(World world) {
		super(world);
		this.texture = "/twilightforest/bighorn.png";
		this.setSize(0.9F, 1.3F);
	}

	public static int a(Random random) {
		return random.nextInt(2) == 0 ? 12 : random.nextInt(15);
	}
}
