package com.benimatic.twilightforest;

import net.minecraft.src.Block;
import net.minecraft.src.EntityChicken;
import net.minecraft.src.MathHelper;
import net.minecraft.src.World;

public class EntityTFPenguin extends EntityChicken {
	public EntityTFPenguin(World world) {
		super(world);
		this.texture = "/twilightforest/penguin.png";
	
	}

	public EntityTFPenguin(World world, double x, double y, double z) {
		this(world);
		this.setPosition(x, y, z);
	}

	protected String getLivingSound() {
		return null;
	}

	@Override
	public boolean getCanSpawnHere() {
		int i = MathHelper.floor_double(this.posX);
		int j = MathHelper.floor_double(this.boundingBox.minY);
		int k = MathHelper.floor_double(this.posZ);
		return this.worldObj.getBlockId(i, j - 1, k) == Block.ice.blockID && 
				this.worldObj.getFullBlockLightValue(i, j, k) > 8 && 
				this.getBlockPathWeight(i, j, k) >= 0.0F && 
				this.worldObj.checkIfAABBIsClear(this.boundingBox) && 
				this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0 && 
				!this.worldObj.getIsAnyLiquid(this.boundingBox);
	}
}
