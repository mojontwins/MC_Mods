package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ItemTool;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockTFMazestone extends Block {
	
	static int[] mimicIDs = new int[]{
			Block.limestoneBricks.blockID, 
			Block.cobblestone.blockID, 
			Block.cobblestoneMossy.blockID
		};

	public BlockTFMazestone(int id) {
		super(id, 1, Material.rock);
	}

	@Override
	public int getBlockTextureFromSideAndMetadata(int side, int meta) {
		return Block.blocksList[mimicIDs[meta]].getBlockTextureFromSideAndMetadata (side, meta);
	}

	@Override
	public int quantityDropped(int meta, Random random) {
		return 0;
	}

	@Override
	public void harvestBlock(World world, EntityPlayer entityplayer, int x, int y, int z, int meta) {
		ItemStack itemStack = entityplayer.getCurrentEquippedItem();
		if(itemStack != null && itemStack.getItem() instanceof ItemTool) {
			itemStack.damageItem(8, entityplayer);
		}

		Block mimic = Block.blocksList[mimicIDs[meta]];
		if(mimic != null) {
			mimic.harvestBlock(world, entityplayer, x, y, z, 0);
		} else {
			super.harvestBlock(world, entityplayer, x, y, z, meta);
		}

	}
}
