package com.benimatic.twilightforest;

import net.minecraft.src.Block;
import net.minecraft.src.IChunkProvider;
import net.minecraft.src.WorldProvider;

public class WorldProviderTwilightForest extends WorldProvider {
	
	@Override
	public float calculateCelestialAngle(long l, float f) {
		return 0.25F;
	}

	@Override
	public void registerWorldChunkManager() {
		this.worldChunkMgr = new WorldChunkManagerTwilightForest(this.worldObj);
		//this.worldType = 7;
	}

	@Override
	public IChunkProvider getChunkProvider() {
		return new ChunkProviderTwilightForest(this.worldObj, this.worldObj.getRandomSeed());
	}

	@Override
	public float getCloudHeight() {
		return 64.0F;
	}

	@Override
	public boolean canCoordinateBeSpawn(int i, int j) {
		int k = this.worldObj.getFirstUncoveredBlock(i, j);
		return k == 0 ? false : Block.blocksList[k].blockMaterial.getIsSolid();
	}
}
