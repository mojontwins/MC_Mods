package com.benimatic.twilightforest;

import net.minecraft.src.EntityPig;
import net.minecraft.src.World;

public class EntityTwilightBoar extends EntityPig {
	public EntityTwilightBoar(World world) {
		super(world);
		this.texture = "/twilightforest/wildboar.png";
		this.setSize(0.9F, 0.9F);
	}
}
