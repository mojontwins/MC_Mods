package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.WorldGenTrees;
import net.minecraft.src.WorldGenerator;

public class TFBiomeGenSwamp extends TFBiomeGenBase {
	protected TFBiomeGenSwamp(int id) {
		super(id);
	}

	public WorldGenerator getRandomWorldGenForTrees(Random random) {
		return (WorldGenerator)(random.nextInt(10) == 0 ? new WorldGenTrees() : new TFGenMangroveTree());
	}
}
