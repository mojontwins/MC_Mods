package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.TileEntityMobSpawner;
import net.minecraft.src.World;
import net.minecraft.src.mod_TwilightForest;

public class TFGenHedgeMaze extends TFGenerator {
	int size;
	TFMaze maze;
	Random rand;

	public TFGenHedgeMaze(int i1) {
		this.size = i1;
	}

	public boolean generate(World world1, Random random2, int i3, int i4, int i5) {
		this.worldObj = world1;
		this.rand = random2;
		int i6 = i3 - 7 - this.size * 16;
		int i7 = i5 - 7 - this.size * 16;
		byte b8 = 16;
		this.maze = new TFMaze(b8, b8);
		this.maze.oddBias = 2;
		this.maze.torchBlockID = Block.torchWood.blockID;
		this.maze.wallBlockID = mod_TwilightForest.blockHedge.blockID;
		this.maze.type = 4;
		this.maze.tall = 3;
		this.maze.roots = 3;
		this.fill(i6, i4 - 1, i7, b8 * 3, i4 + 128, b8 * 3, 0, 0);
		this.fill(i6, i4 - 1, i7, b8 * 3, 1, b8 * 3, Block.grass.blockID, 0);
		this.putBlockAndMetadata(i6 - 1, i4, i7 + 23, Block.pumpkinLantern.blockID, 1, true);
		this.putBlockAndMetadata(i6 - 1, i4, i7 + 28, Block.pumpkinLantern.blockID, 1, true);
		this.putBlockAndMetadata(i6 + 49, i4, i7 + 23, Block.pumpkinLantern.blockID, 3, true);
		this.putBlockAndMetadata(i6 + 49, i4, i7 + 28, Block.pumpkinLantern.blockID, 3, true);
		this.putBlockAndMetadata(i6 + 23, i4, i7 - 1, Block.pumpkinLantern.blockID, 2, true);
		this.putBlockAndMetadata(i6 + 28, i4, i7 - 1, Block.pumpkinLantern.blockID, 2, true);
		this.putBlockAndMetadata(i6 + 23, i4, i7 + 49, Block.pumpkinLantern.blockID, 0, true);
		this.putBlockAndMetadata(i6 + 28, i4, i7 + 49, Block.pumpkinLantern.blockID, 0, true);
		int i9 = b8 / 3;
		int[] i10 = new int[i9 * 2];

		for(int i11 = 0; i11 < i9; ++i11) {
			int i12;
			int i13;
			do {
				i12 = random2.nextInt(b8 - 2) + 1;
				i13 = random2.nextInt(b8 - 2) + 1;
			} while(this.isNearRoom(i12, i13, i10));

			this.maze.carveRoom1(i12, i13);
			i10[i11 * 2] = i12;
			i10[i11 * 2 + 1] = i13;
		}

		this.maze.generateRecursiveBacktracker(0, 0);
		this.maze.add4Exits();
		this.maze.copyToWorld(this.worldObj, i6, i4, i7);
		this.decorate3x3Rooms(i10);
		return true;
	}

	protected boolean isNearRoom(int i1, int i2, int[] i3) {
		for(int i4 = 0; i4 < i3.length / 2; ++i4) {
			int i5 = i3[i4 * 2];
			int i6 = i3[i4 * 2 + 1];
			if((i5 != 0 || i6 != 0) && Math.abs(i1 - i5) < 3 && Math.abs(i2 - i6) < 3) {
				return true;
			}
		}

		return false;
	}

	void decorate3x3Rooms(int[] i1) {
		for(int i2 = 0; i2 < i1.length / 2; ++i2) {
			int i3 = i1[i2 * 2];
			int i4 = i1[i2 * 2 + 1];
			this.decorate3x3Room(i3, i4);
		}

	}

	void decorate3x3Room(int i1, int i2) {
		int i3 = this.maze.getWorldX(i1) + 1;
		int i4 = this.maze.worldY;
		int i5 = this.maze.getWorldZ(i2) + 1;
		this.roomSpawner(i3, i4, i5, 8);
		if(!this.roomTreasure(i3, i4, i5, 8)) {
			this.roomTreasure(i3, i4, i5, 8);
		}

		if(!this.roomJackO(i3, i4, i5, 8) || this.rand.nextInt(4) == 0) {
			this.roomJackO(i3, i4, i5, 8);
		}

	}

	private boolean roomSpawner(int i1, int i2, int i3, int i4) {
		int i5 = this.rand.nextInt(i4) + i1 - i4 / 2;
		int i6 = this.rand.nextInt(i4) + i3 - i4 / 2;
		String string7;
		switch(this.rand.nextInt(3)) {
		case 0:
		default:
			string7 = "Spider";
			break;
		
		case 2:
			string7 = "Hostile Wolf";
		}

		return this.placeMobSpawner(i5, i2, i6, string7);
	}

	private boolean roomTreasure(int i1, int i2, int i3, int i4) {
		int i5 = this.rand.nextInt(i4) + i1 - i4 / 2;
		int i6 = this.rand.nextInt(i4) + i3 - i4 / 2;
		return this.worldObj.getBlockId(i5, i2, i6) != 0 ? false : TFTreasure.hedgemaze.generate(this.worldObj, this.rand, i5, i2, i6);
	}

	protected boolean placeMobSpawner(int i1, int i2, int i3, String string4) {
		this.worldObj.setBlockWithNotify(i1, i2, i3, Block.mobSpawner.blockID);
		TileEntityMobSpawner tileEntityMobSpawner5 = (TileEntityMobSpawner)this.worldObj.getBlockTileEntity(i1, i2, i3);
		if(tileEntityMobSpawner5 != null) {
			tileEntityMobSpawner5.setMobID(string4);
			return true;
		} else {
			return false;
		}
	}

	private boolean roomJackO(int i1, int i2, int i3, int i4) {
		int i5 = this.rand.nextInt(i4) + i1 - i4 / 2;
		int i6 = this.rand.nextInt(i4) + i3 - i4 / 2;
		if(this.worldObj.getBlockId(i5, i2, i6) != 0) {
			return false;
		} else {
			this.worldObj.setBlockAndMetadataWithNotify(i5, i2, i6, Block.pumpkinLantern.blockID, this.rand.nextInt(4));
			return true;
		}
	}
}
