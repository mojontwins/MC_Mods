package com.benimatic.twilightforest;

public class TFBiomeGenTwilightForest extends TFBiomeGenBase {

	protected TFBiomeGenTwilightForest(int id) {
		super(id);
	}
}
