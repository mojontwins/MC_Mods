package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class TFGenCaveStalactite extends TFGenerator {
	public double size;
	public int bType;
	public boolean hang;
	public int dir;

	public TFGenCaveStalactite(int blockType, double sizeFactor, boolean down) {
		this.bType = blockType;
		this.size = sizeFactor;
		this.hang = down;
		this.dir = this.hang ? -1 : 1;
	}

	public static TFGenCaveStalactite makeRandomOreStalactite(Random rand, int caveSize) {
		int s1;
		if(caveSize >= 3) {
			s1 = rand.nextInt(6);
			if(s1 == 0) {
				return new TFGenCaveStalactite(Block.oreDiamond.blockID, rand.nextDouble() * 0.5D, true);
			}

			if(s1 == 1) {
				return new TFGenCaveStalactite(Block.oreLapis.blockID, rand.nextDouble() * 0.8D, true);
			}
		}

		if(caveSize >= 2) {
			s1 = rand.nextInt(6);
			if(s1 == 0) {
				return new TFGenCaveStalactite(Block.oreGold.blockID, rand.nextDouble() * 0.6D, true);
			}

			if(s1 == 1 || s1 == 2) {
				return new TFGenCaveStalactite(Block.oreRedstone.blockID, rand.nextDouble() * 0.8D, true);
			}
		}

		s1 = rand.nextInt(5);
		return s1 != 0 && s1 != 1 ? (s1 != 2 && s1 != 3 ? new TFGenCaveStalactite(Block.glowStone.blockID, rand.nextDouble() * 0.5D, true) : new TFGenCaveStalactite(Block.oreCoal.blockID, rand.nextDouble() * 0.8D, true)) : new TFGenCaveStalactite(Block.oreIron.blockID, rand.nextDouble() * 0.7D, true);
	}

	public boolean generate(World world, Random random, int x, int y, int z) {
		this.worldObj = world;
		int ceiling = 129;
		int floor = -1;

		int length;
		Material m;
		for(length = y; length < 128; ++length) {
			m = this.worldObj.getBlockMaterial(x, length, z);
			if(m != Material.air) {
				if(m != Material.ground && m != Material.rock) {
					return false;
				}

				ceiling = length;
				break;
			}
		}

		if(ceiling == 129) {
			return false;
		} else {
			for(length = y; length > 4; --length) {
				m = this.worldObj.getBlockMaterial(x, length, z);
				if(m != Material.air) {
					if(m != Material.ground && m != Material.rock && !this.hang && m != Material.water && !this.hang && m != Material.lava) {
						return false;
					}

					floor = length;
					break;
				}
			}

			length = (int)((double)(ceiling - floor) * this.size);
			return this.makeSpike(random, x, this.hang ? ceiling : floor, z, length);
		}
	}

	public boolean makeSpike(Random random, int x, int y, int z, int length) {
		int dw = (int)((double)length / 4.5D);

		for(int dx = -dw; dx <= dw; ++dx) {
			for(int dz = -dw; dz <= dw; ++dz) {
				int ax = Math.abs(dx);
				int az = Math.abs(dz);
				int dist = (int)((double)Math.max(ax, az) + (double)Math.min(ax, az) * 0.5D);
				int dl = 0;
				if(dist == 0) {
					dl = length;
				}

				if(dist > 0) {
					dl = random.nextInt((int)((double)length / ((double)dist + 0.25D)));
				}

				for(int dy = 0; dy != dl * this.dir; dy += this.dir) {
					this.putBlock(x + dx, y + dy, z + dz, this.bType, false);
				}
			}
		}

		return true;
	}

	public boolean generateOld(World world, Random random, int i, int j, int k) {
		this.worldObj = world;
		if(!world.isAirBlock(i, j, k)) {
			return false;
		} else if(world.getBlockId(i, j + 1, k) != Block.stone.blockID && world.getBlockId(i, j + 1, k) != Block.dirt.blockID) {
			return false;
		} else {
			this.drawDiameterCircle(i, j + 1, k, 3, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j, k, 3, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 1, k, 3, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 2, k, 2, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 3, k, 2, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 4, k, 2, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 5, k, 1, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 6, k, 1, (byte)this.bType, 0, false);
			this.drawDiameterCircle(i, j - 7, k, 1, (byte)this.bType, 0, false);
			return true;
		}
	}
}
