package com.benimatic.twilightforest;

import java.util.Random;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.Block;
import net.minecraft.src.BlockSand;
import net.minecraft.src.Chunk;
import net.minecraft.src.ChunkProviderGenerate;
import net.minecraft.src.IChunkProvider;
import net.minecraft.src.IProgressUpdate;
import net.minecraft.src.MapGenBase;
import net.minecraft.src.MapGenCaves;
import net.minecraft.src.Material;
import net.minecraft.src.NoiseGeneratorOctaves;
import net.minecraft.src.World;
import net.minecraft.src.WorldGenFlowers;
import net.minecraft.src.WorldGenLakes;
import net.minecraft.src.WorldGenLiquids;
import net.minecraft.src.WorldGenMinable;
import net.minecraft.src.WorldGenPumpkin;
import net.minecraft.src.WorldGenReed;
import net.minecraft.src.WorldGenTallGrass;
import net.minecraft.src.WorldGenerator;

public class ChunkProviderTwilightForest extends ChunkProviderGenerate implements IChunkProvider {
	private Random rand;
	private NoiseGeneratorOctaves noiseK;
	private NoiseGeneratorOctaves noiseL;
	private NoiseGeneratorOctaves field_910_m;
	public NoiseGeneratorOctaves a;
	public NoiseGeneratorOctaves b;
	public NoiseGeneratorOctaves c;
	private World worldObj;
	private double[] terrainLevel;
	private MapGenBase caveGen = new MapGenCaves();
	private BiomeGenBase[] biomesForGeneration;
	double[] d;
	double[] valuesK;
	double[] f;
	double[] g;
	double[] h;
	int[][] i = new int[32][32];
	private double[] generatedTemperatures;

	public ChunkProviderTwilightForest(World world1, long j2) {
		super(world1, j2);
		this.worldObj = world1;
		this.rand = new Random(j2);
		this.noiseK = new NoiseGeneratorOctaves(this.rand, 16);
		this.noiseL = new NoiseGeneratorOctaves(this.rand, 16);
		this.field_910_m = new NoiseGeneratorOctaves(this.rand, 8);
		this.a = new NoiseGeneratorOctaves(this.rand, 10);
		this.b = new NoiseGeneratorOctaves(this.rand, 16);
		this.c = new NoiseGeneratorOctaves(this.rand, 8);
	}

	@Override
	public Chunk loadChunk(int i1, int i2) {
		return this.provideChunk(i1, i2);
	}

	@Override
	public Chunk provideChunk(int i1, int i2) {
		this.rand.setSeed((long) i1 * 341873128712L + (long) i2 * 132897987541L);
		byte[] b3 = new byte[32768];
		this.biomesForGeneration = this.worldObj.getWorldChunkManager().loadBlockGeneratorData(this.biomesForGeneration,
				i1 * 16, i2 * 16, 16, 16);
		double[] d4 = this.worldObj.getWorldChunkManager().temperature;
		double[] d5 = this.worldObj.getWorldChunkManager().humidity;
		this.generateTerrain(i1, i2, b3, this.biomesForGeneration, d4);
		this.terraform(i1, i2, b3, this.biomesForGeneration, d4, d5);
		this.addGlaciers(i1, i2, b3, this.biomesForGeneration, d4);
		this.raiseHills(i1, i2, b3);
		this.replaceBlocksForBiome(i1, i2, b3, this.biomesForGeneration, d4);
		this.caveGen.generate(null, worldObj, i1, i2, b3); // This is new!
		Chunk chunk6 = new Chunk(this.worldObj, b3, i1, i2);
		chunk6.func_353_b();
		return chunk6;
	}

	public void generateTerrain(int i1, int i2, byte[] b3, BiomeGenBase[] biomeGenBase4, double[] d5) {
		byte b6 = 17;
		this.terrainLevel = this.initializeNoiseField(this.terrainLevel, i1 * 4, 0, i2 * 4, 5, b6, 5);

		for (int i7 = 0; i7 < 4; ++i7) {
			for (int i8 = 0; i8 < 4; ++i8) {
				for (int i9 = 0; i9 < 16; ++i9) {
					double d10 = 0.125D;
					double d12 = this.terrainLevel[((i7 + 0) * 5 + i8 + 0) * b6 + i9 + 0];
					double d14 = this.terrainLevel[((i7 + 0) * 5 + i8 + 1) * b6 + i9 + 0];
					double d16 = this.terrainLevel[((i7 + 1) * 5 + i8 + 0) * b6 + i9 + 0];
					double d18 = this.terrainLevel[((i7 + 1) * 5 + i8 + 1) * b6 + i9 + 0];
					double d20 = (this.terrainLevel[((i7 + 0) * 5 + i8 + 0) * b6 + i9 + 1] - d12) * d10;
					double d22 = (this.terrainLevel[((i7 + 0) * 5 + i8 + 1) * b6 + i9 + 1] - d14) * d10;
					double d24 = (this.terrainLevel[((i7 + 1) * 5 + i8 + 0) * b6 + i9 + 1] - d16) * d10;
					double d26 = (this.terrainLevel[((i7 + 1) * 5 + i8 + 1) * b6 + i9 + 1] - d18) * d10;

					for (int i28 = 0; i28 < 8; ++i28) {
						double d29 = 0.25D;
						double d31 = d12;
						double d33 = d14;
						double d35 = (d16 - d12) * d29;
						double d37 = (d18 - d14) * d29;

						for (int i39 = 0; i39 < 4; ++i39) {
							int i40 = i39 + i7 * 4 << 11 | 0 + i8 * 4 << 7 | i9 * 8 + i28;
							short s41 = 128;
							double d42 = 0.25D;
							double d44 = d31;
							double d46 = (d33 - d31) * d42;

							for (int i48 = 0; i48 < 4; ++i48) {
								int i49 = 0;
								if (d44 > 0.0D) {
									i49 = Block.stone.blockID;
								}

								b3[i40] = (byte) i49;
								i40 += s41;
								d44 += d46;
							}

							d31 += d35;
							d33 += d37;
						}

						d12 += d20;
						d14 += d22;
						d16 += d24;
						d18 += d26;
					}
				}
			}
		}

	}

	public void terraform(int i1, int i2, byte[] b3, BiomeGenBase[] biomeGenBase4, double[] d5, double[] d6) {
		for (int i7 = 0; i7 < 16; ++i7) {
			for (int i8 = 0; i8 < 16; ++i8) {
				double d9 = 0.25D;
				BiomeGenBase biomeGenBase11 = biomeGenBase4[i7 * 16 + i8];
				double d12 = d5[i7 * 16 + i8];
				double d14 = d6[i7 * 16 + i8];
				double d16;
				if (biomeGenBase11 == TFBiomeGenBase.twilightHighland) {
					d16 = (1.0D - d14 * 4.0D) * (1.0D - (1.0D - d12) * 4.0D);
					d9 = 0.35D + 0.25D * d16;
				}

				if (biomeGenBase11 == TFBiomeGenBase.twilightSwamp) {
					d16 = (1.0D - (1.0D - d14) * 4.0D) * (1.0D - (1.0D - d12) * 4.0D);
					d9 = 0.24D - 0.04D * d16;
				}

				int i19 = -1;

				for (int i20 = 127; i20 >= 0; --i20) {
					int i21 = (i7 * 16 + i8) * 128 + i20;
					byte b22 = b3[i21];
					if (b22 != 0) {
						if (i19 == -1) {
							i19 = (int) ((double) i20 * d9);
						}

						if (i20 >= i19) {
							b3[i21] = 0;
						}
					}
				}
			}
		}

	}

	public void raiseHills(int i1, int i2, byte[] b3) {
		if (nearHollowHill(i1, i2, 0L)) {
			int[] i4 = nearestHillCenter(i1, i2, 0L);
			int i5 = nearestHillSize(i1, i2, 0L);
			double d6 = (double) (i5 * 2 + 1) * 16.0D;
			int i8 = i4[0];
			int i9 = i4[1];

			for (int i10 = 0; i10 < 16; ++i10) {
				for (int i11 = 0; i11 < 16; ++i11) {
					int i13 = -1;
					int i14 = i10 - i8;
					int i15 = i11 - i9;
					int i16 = (int) Math.sqrt((double) (i14 * i14 + i15 * i15));
					int i17 = (int) (Math.cos((double) i16 / d6 * Math.PI) * (d6 / 3.0D));

					int i18;
					int i19;
					for (i18 = 0; i18 <= 127; ++i18) {
						i19 = (i10 * 16 + i11) * 128 + i18;
						byte b20 = b3[i19];
						if (b20 == 0 || b20 == Block.ice.blockID) {
							if (i13 == -1) {
								i13 = i18 + i17;
							}

							if (i18 <= i13) {
								b3[i19] = (byte) Block.stone.blockID;
							}
						}
					}

					i18 = i17 - 4;
					if (i18 < 0) {
						i18 = 0;
					}

					for (i19 = 0; i19 <= 127; ++i19) {
						int i21 = (i10 * 16 + i11) * 128 + i19;
						if (i19 > 16 && i19 < 16 + i18) {
							b3[i21] = 0;
						}
					}
				}
			}
		}

	}

	public static boolean nearHollowHill(int i0, int i1, long j2) {
		for (int i4 = 1; i4 <= 3; ++i4) {
			for (int i5 = -i4; i5 <= i4; ++i5) {
				for (int i6 = -i4; i6 <= i4; ++i6) {
					if (hillSize(i5 + i0, i6 + i1, j2) == i4) {
						return true;
					}
				}
			}
		}

		return false;
	}

	public static int[] nearestHillCenter(int i0, int i1, long j2) {
		for (int i4 = 1; i4 <= 3; ++i4) {
			for (int i5 = -i4; i5 <= i4; ++i5) {
				for (int i6 = -i4; i6 <= i4; ++i6) {
					if (hillSize(i5 + i0, i6 + i1, j2) == i4) {
						int[] i7 = new int[] { i5 * 16 + 8, i6 * 16 + 8 };
						return i7;
					}
				}
			}
		}

		int[] i8 = new int[] { 0, 0 };
		return i8;
	}

	public static boolean isHollowHill(int i0, int i1, long j2) {
		return hillSize(i0, i1, j2) > 0;
	}

	public static int nearestHillSize(int i0, int i1, long j2) {
		for (int i4 = 1; i4 <= 3; ++i4) {
			for (int i5 = -i4; i5 <= i4; ++i5) {
				for (int i6 = -i4; i6 <= i4; ++i6) {
					if (hillSize(i5 + i0, i6 + i1, j2) == i4) {
						return i4;
					}
				}
			}
		}

		return -1;
	}

	public static int hillSize(int i0, int i1, long j2) {
		Random random4 = new Random(j2 + (long) (i0 * 25117) + (long) (i1 * 151121));
		int i5 = random4.nextInt();
		int i6 = -1;
		if ((i0 % 7 == 4 || i0 % 7 == -4) && (i1 % 7 == 4 || i1 % 7 == -4)) {
			i6 = Math.abs(i5 % 6);
			if (i6 == 0 || i6 > 3) {
				i6 = -1;
			}
		}

		return i6;
	}
	
	public static boolean findHedge(int x, int z, long j) {
		Random r = new Random(j + (long)(x + 25117) + (long)(z * 151121));
		int ri = r.nextInt(8);
		
		if(x % 7 == 0 && z % 7 == 0 && ri == 0) return true;
		
		return false;
	}

	public void replaceBlocksForBiome(int i1, int i2, byte[] b3, BiomeGenBase[] biomeGenBase4, double[] d5) {
		boolean z6 = nearHollowHill(i1, i2, 0L);

		for (int i7 = 0; i7 < 16; ++i7) {
			for (int i8 = 0; i8 < 16; ++i8) {
				BiomeGenBase biomeGenBase9 = biomeGenBase4[i7 + i8 * 16];
				byte b10 = biomeGenBase9.topBlock;
				byte b11 = biomeGenBase9.fillerBlock;
				int i12 = 1 + (int) (this.rand.nextDouble() * this.rand.nextDouble() * 3.0D + 0.65D);
				int i13 = -1;

				for (int i14 = 127; i14 >= 0; --i14) {
					int i15 = (i8 * 16 + i7) * 128 + i14;
					byte b16;
					if (i14 <= 8) {
						if (z6) {
							b16 = (byte) Block.bedrock.blockID;
						}
					} else {
						b16 = b3[i15];
						if (b16 != 0 && b16 == Block.stone.blockID) {
							if (i13 == -1) {
								i13 = i14;
								b3[i15] = b10;
							} else if (i14 < i13 && i14 >= i13 - i12) {
								b3[i15] = b11;
							}
						}
					}
				}
			}
		}

	}

	public void addGlaciers(int i1, int i2, byte[] b3, BiomeGenBase[] biomeGenBase4, double[] d5) {
		for (int i6 = 0; i6 < 16; ++i6) {
			for (int i7 = 0; i7 < 16; ++i7) {
				BiomeGenBase biomeGenBase8 = biomeGenBase4[i6 + i7 * 16];
				if (biomeGenBase8 == TFBiomeGenBase.twilightGlacier) {
					int i9 = -1;

					for (int i10 = 127; i10 >= 0; --i10) {
						int i11 = (i7 * 16 + i6) * 128 + i10;
						byte b12 = b3[i11];
						if (b12 == Block.stone.blockID) {
							i9 = i10;
							break;
						}
					}

					double d16 = Math.min(d5[i7 * 16 + i6], 0.1D);
					int i17 = 10 + (int) ((0.1D - d16) * 10.0D);
					int i13 = i9 + i17 + 1;

					for (int i14 = i9 + 1; i14 <= i13 && i14 < 128; ++i14) {
						int i15 = (i7 * 16 + i6) * 128 + i14;
						b3[i15] = (byte) Block.ice.blockID;
					}
				}
			}
		}

	}

	@Override
	protected double[] initializeNoiseField(double[] d1, int i2, int i3, int i4, int i5, int i6, int i7) {
		if (d1 == null) {
			d1 = new double[i5 * i6 * i7];
		}

		double d8 = 684.412D;
		double d10 = 684.412D;
		double[] d12 = this.worldObj.getWorldChunkManager().temperature;
		double[] d13 = this.worldObj.getWorldChunkManager().humidity;
		this.g = this.a.func_4103_a(this.g, i2, i4, i5, i7, 1.121D, 1.121D, 0.5D);
		this.h = this.b.func_4103_a(this.h, i2, i4, i5, i7, 200.0D, 200.0D, 0.5D);
		this.d = this.field_910_m.generateNoiseOctaves(this.d, (double) i2, (double) i3, (double) i4, i5, i6, i7,
				d8 / 80.0D, d10 / 160.0D, d8 / 80.0D);
		this.valuesK = this.noiseK.generateNoiseOctaves(this.valuesK, (double) i2, (double) i3, (double) i4, i5, i6, i7,
				d8, d10, d8);
		this.f = this.noiseL.generateNoiseOctaves(this.f, (double) i2, (double) i3, (double) i4, i5, i6, i7, d8, d10,
				d8);
		int i14 = 0;
		int i15 = 0;
		int i16 = 16 / i5;

		for (int i17 = 0; i17 < i5; ++i17) {
			int i18 = i17 * i16 + i16 / 2;

			for (int i19 = 0; i19 < i7; ++i19) {
				int i20 = i19 * i16 + i16 / 2;
				double d21 = d12[i18 * 16 + i20];
				double d23 = d13[i18 * 16 + i20] * d21;
				double d25 = 1.0D - d23;
				d25 *= d25;
				d25 *= d25;
				d25 = 1.0D - d25;
				double d27 = (this.g[i15] + 256.0D) / 512.0D;
				d27 *= d25;
				if (d27 > 1.0D) {
					d27 = 1.0D;
				}

				double d29 = this.h[i15] / 8000.0D;
				if (d29 < 0.0D) {
					d29 = -d29 * 0.3D;
				}

				d29 = d29 * 3.0D - 2.0D;
				if (d29 < 0.0D) {
					d29 /= 2.0D;
					if (d29 < -1.0D) {
						d29 = -1.0D;
					}

					d29 /= 1.4D;
					d29 /= 2.0D;
					d27 = 0.0D;
				} else {
					if (d29 > 1.0D) {
						d29 = 1.0D;
					}

					d29 /= 8.0D;
				}

				if (d27 < 0.0D) {
					d27 = 0.0D;
				}

				d27 += 0.5D;
				d29 = d29 * (double) i6 / 16.0D;
				double d31 = (double) i6 / 2.0D + d29 * 4.0D;
				++i15;

				for (int i33 = 0; i33 < i6; ++i33) {
					double d34 = 0.0D;
					double d36 = ((double) i33 - d31) * 12.0D / d27;
					if (d36 < 0.0D) {
						d36 *= 4.0D;
					}

					double d38 = this.valuesK[i14] / 512.0D;
					double d40 = this.f[i14] / 512.0D;
					double d42 = (this.d[i14] / 10.0D + 1.0D) / 2.0D;
					if (d42 < 0.0D) {
						d34 = d38;
					} else if (d42 > 1.0D) {
						d34 = d40;
					} else {
						d34 = d38 + (d40 - d38) * d42;
					}

					d34 -= d36;
					if (i33 > i6 - 4) {
						double d44 = (double) ((float) (i33 - (i6 - 4)) / 3.0F);
						d34 = d34 * (1.0D - d44) + -10.0D * d44;
					}

					d1[i14] = d34;
					++i14;
				}
			}
		}

		return d1;
	}

	@Override
	public boolean chunkExists(int i1, int i2) {
		return true;
	}

	@Override
	public void populate(IChunkProvider iChunkProvider1, int chunkX, int chunkZ) {
		BlockSand.fallInstantly = true;
		int x0 = chunkX * 16;
		int z0 = chunkZ * 16;
		BiomeGenBase biomeGenBase6 = this.worldObj.getWorldChunkManager().getBiomeGenAt(x0 + 16, z0 + 16);

		this.rand.setSeed(this.worldObj.getRandomSeed());
		long j7 = this.rand.nextLong() / 2L * 2L + 1L;
		long j9 = this.rand.nextLong() / 2L * 2L + 1L;
		this.rand.setSeed((long) chunkX * j7 + (long) chunkZ * j9 ^ this.worldObj.getRandomSeed());
		int i;
		int j;
		int k;
		if (this.rand.nextInt(4) == 0) {
			i = x0 + this.rand.nextInt(16) + 8;
			j = this.rand.nextInt(128);
			k = z0 + this.rand.nextInt(16) + 8;
			if ((new WorldGenLakes(Block.waterStill.blockID)).generate(this.worldObj, this.rand, i, j, k)) {
				;
			}
		}

		int l;
		if (biomeGenBase6 == TFBiomeGenBase.twilightSwamp) {
			for (i = 0; i < 6; ++i) {
				j = x0 + this.rand.nextInt(16) + 8;
				k = z0 + this.rand.nextInt(16) + 8;
				l = this.worldObj.getHeightValue(j, k);
				(new WorldGenLakes(Block.waterStill.blockID)).generate(this.worldObj, this.rand, j, l, k);
			}
		}

		if (this.rand.nextInt(64) == 0) {
			i = x0 + this.rand.nextInt(16) + 8;
			j = this.rand.nextInt(this.rand.nextInt(120) + 8);
			k = z0 + this.rand.nextInt(16) + 8;
			if (j < 64 || this.rand.nextInt(10) == 0) {
				(new WorldGenLakes(Block.lavaStill.blockID)).generate(this.worldObj, this.rand, i, j, k);
			}
		}

		if (this.rand.nextInt(4) == 0) {
			i = x0 + this.rand.nextInt(16) + 8;
			j = z0 + this.rand.nextInt(16) + 8;
			k = this.worldObj.findTopSolidBlock(i, j);
			TFGenerator tFGenerator15 = this.randomFeature(this.rand, (TFBiomeGenBase) biomeGenBase6);
			if (tFGenerator15.generate(this.worldObj, this.rand, i, k, j)) {
				System.out.println(tFGenerator15 + " success at " + i + ", " + k + ", " + j);
			}
		}

		if (this.rand.nextInt(4) == 0) {
			i = x0 + this.rand.nextInt(16) + 8;
			j = z0 + this.rand.nextInt(16) + 8;
			(new TFGenHollowTree()).generate(this.worldObj, this.rand, i, this.worldObj.findTopSolidBlock(i, j),
					j);
		}

		for (i = 0; i < 20; ++i) {
			j = x0 + this.rand.nextInt(16);
			k = this.rand.nextInt(128);
			l = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.dirt.blockID, 32)).generate(this.worldObj, this.rand, j, k, l);
		}

		for (i = 0; i < 10; ++i) {
			j = x0 + this.rand.nextInt(16);
			k = this.rand.nextInt(128);
			l = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.gravel.blockID, 32)).generate(this.worldObj, this.rand, j, k, l);
		}

		for (i = 0; i < 20; ++i) {
			j = x0 + this.rand.nextInt(16);
			k = this.rand.nextInt(128);
			l = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreCoal.blockID, 16)).generate(this.worldObj, this.rand, j, k, l);
		}

		for (i = 0; i < 20; ++i) {
			j = x0 + this.rand.nextInt(16);
			k = this.rand.nextInt(64);
			l = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreIron.blockID, 8)).generate(this.worldObj, this.rand, j, k, l);
		}

		for (i = 0; i < 1; ++i) {
			j = x0 + this.rand.nextInt(16);
			k = this.rand.nextInt(16) + this.rand.nextInt(16);
			l = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreLapis.blockID, 6)).generate(this.worldObj, this.rand, j, k, l);
		}

		i = (int) ((this.c.func_647_a((double) x0 * 0.5D, (double) z0 * 0.5D) / 8.0D + this.rand.nextDouble() * 4.0D
				+ 4.0D) / 3.0D);
		j = i + 20;
		if (biomeGenBase6 == TFBiomeGenBase.twilightSwamp) {
			j -= 18;
		}

		if (biomeGenBase6 == TFBiomeGenBase.twilightSnow) {
			j -= 10;
		}

		if (biomeGenBase6 == TFBiomeGenBase.twilightHighland) {
			j -= 10;
		}

		if (biomeGenBase6 == TFBiomeGenBase.twilightGlacier) {
			j -= 10;
		}

		if (biomeGenBase6 == TFBiomeGenBase.twilightClearings) {
			j = 0;
		}

		int m;
		for (k = 0; k < j; ++k) {
			l = x0 + this.rand.nextInt(16) + 8;
			m = z0 + this.rand.nextInt(16) + 8;
			WorldGenerator worldGenerator16 = biomeGenBase6.getRandomWorldGenForTrees(this.rand);
			worldGenerator16.func_420_a(1.0D, 1.0D, 1.0D);
			worldGenerator16.generate(this.worldObj, this.rand, l, this.worldObj.getHeightValue(l, m), m);
		}

		byte b25 = 2;
		if (biomeGenBase6 == TFBiomeGenBase.twilightForest) {
			b25 = 2;
		}

		int n;
		int o;
		for (l = 0; l < b25; ++l) {
			m = x0 + this.rand.nextInt(16) + 8;
			o = this.rand.nextInt(128);
			n = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenFlowers(Block.plantYellow.blockID)).generate(this.worldObj, this.rand, m, o, n);
		}

		byte b19 = 7;
		if (biomeGenBase6 == TFBiomeGenBase.twilightClearings) {
			b19 = 3;
		}

		if (biomeGenBase6 == TFBiomeGenBase.twilightSwamp) {
			b19 = 1;
		}

		int p;
		int q;
		for (m = 0; m < b19; ++m) {
			byte b22 = 1;
			if ((biomeGenBase6 == TFBiomeGenBase.twilightForest || biomeGenBase6 == TFBiomeGenBase.twilightMushroom
					|| biomeGenBase6 == TFBiomeGenBase.twilightSwamp) && this.rand.nextInt(3) != 0) {
				b22 = 2;
			}

			n = x0 + this.rand.nextInt(16) + 8;
			p = this.rand.nextInt(128);
			q = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenTallGrass(Block.tallGrass.blockID, b22)).generate(this.worldObj, this.rand, n, p, q);
		}

		if (this.rand.nextInt(2) == 0) {
			m = x0 + this.rand.nextInt(16) + 8;
			o = this.rand.nextInt(128);
			n = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenFlowers(Block.plantRed.blockID)).generate(this.worldObj, this.rand, m, o, n);
		}

		if (this.rand.nextInt(3) == 0) {
			m = x0 + this.rand.nextInt(16) + 8;
			o = this.rand.nextInt(64);
			n = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenFlowers(Block.mushroomBrown.blockID)).generate(this.worldObj, this.rand, m, o, n);
		}

		if (this.rand.nextInt(6) == 0) {
			m = x0 + this.rand.nextInt(16) + 8;
			o = this.rand.nextInt(64);
			n = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenFlowers(Block.mushroomRed.blockID)).generate(this.worldObj, this.rand, m, o, n);
		}

		if (biomeGenBase6 == TFBiomeGenBase.twilightMushroom) {
			for (m = 0; m < 48; ++m) {
				o = x0 + this.rand.nextInt(16) + 8;
				n = this.rand.nextInt(64);
				p = z0 + this.rand.nextInt(16) + 8;
				(new WorldGenFlowers(Block.mushroomBrown.blockID)).generate(this.worldObj, this.rand, o, n, p);
			}

			for (m = 0; m < 24; ++m) {
				o = x0 + this.rand.nextInt(16) + 8;
				n = this.rand.nextInt(64);
				p = z0 + this.rand.nextInt(16) + 8;
				(new WorldGenFlowers(Block.mushroomRed.blockID)).generate(this.worldObj, this.rand, o, n, p);
			}
		}

		for (m = 0; m < 3; ++m) {
			o = x0 + this.rand.nextInt(16) + 8;
			n = z0 + this.rand.nextInt(16) + 8;
			p = this.worldObj.getHeightValue(o, n);
			(new WorldGenReed()).generate(this.worldObj, this.rand, o, p, n);
		}

		if (this.rand.nextInt(32) == 0) {
			m = x0 + this.rand.nextInt(16) + 8;
			o = this.rand.nextInt(128);
			n = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenPumpkin()).generate(this.worldObj, this.rand, m, o, n);
		}

		for (m = 0; m < 50; ++m) {
			o = x0 + this.rand.nextInt(16) + 8;
			n = this.rand.nextInt(this.rand.nextInt(120) + 8);
			p = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenLiquids(Block.waterMoving.blockID)).generate(this.worldObj, this.rand, o, n, p);
		}

		for (m = 0; m < 10; ++m) {
			o = x0 + this.rand.nextInt(16) + 8;
			n = this.rand.nextInt(this.rand.nextInt(this.rand.nextInt(112) + 8) + 8);
			p = z0 + this.rand.nextInt(16) + 8;
			(new WorldGenLiquids(Block.lavaMoving.blockID)).generate(this.worldObj, this.rand, o, n, p);
		}

		this.generatedTemperatures = this.worldObj.getWorldChunkManager().getTemperatures(this.generatedTemperatures,
				x0 + 8, z0 + 8, 16, 16);

		for (m = x0 + 8; m < x0 + 8 + 16; ++m) {
			for (o = z0 + 8; o < z0 + 8 + 16; ++o) {
				n = m - (x0 + 8);
				p = o - (z0 + 8);
				q = this.worldObj.findTopSolidBlock(m, o);
				double d26 = this.generatedTemperatures[n * 16 + p] - (double) (q - 64) / 64.0D * 0.3D;
				if (d26 < 0.5D && q > 0 && q < 128 && this.worldObj.isAirBlock(m, q, o)
						&& this.worldObj.getBlockMaterial(m, q - 1, o).getIsSolid()
						&& this.worldObj.getBlockMaterial(m, q - 1, o) != Material.ice) {
					this.worldObj.setBlockWithNotify(m, q, o, Block.snow.blockID);
				}
			}
		}

		m = nearestHillSize(chunkX, chunkZ, 0L);
		if (isHollowHill(chunkX, chunkZ, 0L) && m > 0) {
			(new TFGenHollowHill(m)).generate(this.worldObj, this.rand, x0 + 8, 17, z0 + 8);
			(new TFGenHillMaze(m)).generate(worldObj, rand, x0, 4, z0);
		} else if(findHedge(chunkX, chunkZ, 0L)) {
			(new TFGenHedgeMaze(m)).generate(worldObj, rand, x0, 4, z0);
		}
		BlockSand.fallInstantly = false;
	}

	public TFGenerator randomFeature(Random random1, TFBiomeGenBase tFBiomeGenBase2) {
		int i3 = random1.nextInt(6);
		switch (i3) {
		case 0:
			return new TFGenStoneCircle();
		case 1:
			return new TFGenWell();
		case 2:
			return new TFGenWitchHut();
		case 3:
			return new TFGenOutsideStalagmite();
		case 4:
			return new TFGenFoundation();
		case 5:
			return new TFGenMonolith();
		default:
			return new TFGenStoneCircle();
		}
	}

	@Override
	public String makeString() {
		return "RandomTwilightForestLevelSource";
	}
}
