package com.benimatic.twilightforest;

import net.minecraft.src.EntityWolf;
import net.minecraft.src.World;

public class EntityTFHostileWolf extends EntityWolf {
	public EntityTFHostileWolf(World world1) {
		super(world1);
		this.setIsAngry(true);
		this.health = 10;
	}

	public void onUpdate() {
		super.onUpdate();
		if(!this.worldObj.singleplayerWorld && this.worldObj.difficultySetting == 0) {
			this.setEntityDead();
		}

	}
}
