package com.benimatic.twilightforest;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.World;
import net.minecraft.src.WorldChunkManager;

public class WorldChunkManagerTwilightForest extends WorldChunkManager {
	public WorldChunkManagerTwilightForest() {
	}

	public WorldChunkManagerTwilightForest(World world) {
		super(world);
	}

	@Override
	public BiomeGenBase[] loadBlockGeneratorData(BiomeGenBase[] abiomegenbase, int i1, int j1, int width, int length) {
		abiomegenbase = super.loadBlockGeneratorData(abiomegenbase, i1, j1, width, length);

		for(int i = 0; i < width * length; ++i) {
			abiomegenbase[i] = TFBiomeGenBase.getBiomeFromLookup(this.temperature[i], this.humidity[i]);			
		}

		return abiomegenbase;
	}
}
