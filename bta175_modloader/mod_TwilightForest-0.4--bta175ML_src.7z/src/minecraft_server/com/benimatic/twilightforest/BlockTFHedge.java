package com.benimatic.twilightforest;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntitySpider;
import net.minecraft.src.Material;
import net.minecraft.src.World;

public class BlockTFHedge extends Block {
	public int damageDone;

	public BlockTFHedge(int i1) {
		super(i1, Material.cactus);
		this.blockIndexInTexture = 133;
		this.damageDone = 3;
	}

	@Override
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world1, int i2, int i3, int i4) {
		float f5 = 0.0625F;
		return AxisAlignedBB.getBoundingBoxFromPool((double)((float)i2), (double)i3, (double)((float)i4), (double)((float)(i2 + 1)), (double)((float)(i3 + 1) - f5), (double)((float)(i4 + 1)));
	}

	@Override
	public void onEntityCollidedWithBlock(World world1, int i2, int i3, int i4, Entity entity5) {
		if(this.shouldDamage(entity5)) {
			entity5.attackEntityFrom((Entity)null, this.damageDone);
		}

	}

	@Override
	public void onEntityWalking(World world1, int i2, int i3, int i4, Entity entity5) {
		if(this.shouldDamage(entity5)) {
			entity5.attackEntityFrom((Entity)null, this.damageDone);
		}

	}

	@Override
	public void onBlockClicked(World world1, int i2, int i3, int i4, EntityPlayer entityPlayer5) {
		entityPlayer5.attackEntityFrom((Entity)null, this.damageDone);
	}

	@Override
	public void harvestBlock(World world1, EntityPlayer entityPlayer2, int i3, int i4, int i5, int i6) {
		super.harvestBlock(world1, entityPlayer2, i3, i4, i5, i6);
		entityPlayer2.attackEntityFrom((Entity)null, this.damageDone);
	}
	
	private boolean shouldDamage(Entity entity1) {
		return !(entity1 instanceof EntitySpider) && !(entity1 instanceof EntityItem);
	}
	
}
