package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelPiglet extends ModelBase {
	public ModelRenderer piglethead = new ModelRenderer(0, 0);
	public ModelRenderer pigletbody;
	public ModelRenderer pigletleg1;
	public ModelRenderer pigletleg2;
	public ModelRenderer pigletleg3;
	public ModelRenderer pigletleg4;

	public ModelPiglet() {
		this.piglethead.addBox(-2.5F, -2.0F, -3.0F, 5, 4, 4, 0.0F);
		this.piglethead.setRotationPoint(0.0F, 17.0F, -3.0F);
		this.pigletbody = new ModelRenderer(14, 4);
		this.pigletbody.addBox(-3.0F, -4.0F, -2.0F, 6, 8, 4, 0.0F);
		this.pigletbody.setRotationPoint(0.0F, 19.0F, 0.0F);
		this.pigletleg1 = new ModelRenderer(0, 8);
		this.pigletleg1.addBox(-1.0F, 0.0F, -1.0F, 2, 3, 2, 0.0F);
		this.pigletleg1.setRotationPoint(-2.0F, 21.0F, 4.0F);
		this.pigletleg2 = new ModelRenderer(0, 8);
		this.pigletleg2.addBox(-1.0F, 0.0F, -1.0F, 2, 3, 2, 0.0F);
		this.pigletleg2.setRotationPoint(2.0F, 21.0F, 4.0F);
		this.pigletleg3 = new ModelRenderer(0, 8);
		this.pigletleg3.addBox(-1.0F, 0.0F, -1.0F, 2, 3, 2, 0.0F);
		this.pigletleg3.setRotationPoint(-2.0F, 21.0F, -2.0F);
		this.pigletleg4 = new ModelRenderer(0, 8);
		this.pigletleg4.addBox(-1.0F, 0.0F, -1.0F, 2, 3, 2, 0.0F);
		this.pigletleg4.setRotationPoint(2.0F, 21.0F, -2.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.piglethead.render(f5);
		this.pigletbody.render(f5);
		this.pigletleg1.render(f5);
		this.pigletleg2.render(f5);
		this.pigletleg3.render(f5);
		this.pigletleg4.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.piglethead.rotateAngleX = f4 / 57.29578F;
		this.piglethead.rotateAngleY = f3 / 57.29578F;
		this.pigletbody.rotateAngleX = 1.570796F;
		this.pigletleg1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		this.pigletleg2.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.pigletleg3.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.pigletleg4.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
	}
}
