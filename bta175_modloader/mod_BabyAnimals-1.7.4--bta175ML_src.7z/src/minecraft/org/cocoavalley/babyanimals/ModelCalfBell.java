package org.cocoavalley.babyanimals;

import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelCalfBell extends ModelBase {
	public ModelRenderer CalfBellbody = new ModelRenderer(15, 4);

	public ModelCalfBell() {
		this.CalfBellbody.addBox(-3.0F, -4.5F, -2.5F, 6, 9, 5, 0.5F);
		this.CalfBellbody.setRotationPoint(0.0F, 12.5F, 0.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.CalfBellbody.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.CalfBellbody.rotateAngleX = 1.570796F;
	}
}
