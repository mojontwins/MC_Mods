package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelChickBell extends ModelBase {
	public ModelRenderer ChickBellleg2 = new ModelRenderer(12, 0);

	public ModelChickBell() {
		this.ChickBellleg2.addBox(-0.5F, 0.0F, 0.0F, 1, 2, 1, 0.2F);
		this.ChickBellleg2.setRotationPoint(1.0F, 22.0F, 0.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.ChickBellleg2.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.ChickBellleg2.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
	}
}
