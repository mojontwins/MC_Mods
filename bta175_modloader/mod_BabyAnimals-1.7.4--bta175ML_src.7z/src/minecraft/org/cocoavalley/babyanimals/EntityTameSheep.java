package org.cocoavalley.babyanimals;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.BlockCloth;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityAnimal;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntityTameSheep extends EntityAnimal {
	public static final float[][] fleeceColorTable = new float[][]{{1.0F, 1.0F, 1.0F}, {0.95F, 0.7F, 0.2F}, {0.9F, 0.5F, 0.85F}, {0.6F, 0.7F, 0.95F}, {0.9F, 0.9F, 0.2F}, {0.5F, 0.8F, 0.1F}, {0.95F, 0.7F, 0.8F}, {0.3F, 0.3F, 0.3F}, {0.6F, 0.6F, 0.6F}, {0.3F, 0.6F, 0.7F}, {0.7F, 0.4F, 0.9F}, {0.2F, 0.4F, 0.8F}, {0.5F, 0.4F, 0.3F}, {0.4F, 0.5F, 0.2F}, {0.8F, 0.3F, 0.3F}, {0.1F, 0.1F, 0.1F}};
	public boolean stay;
	public boolean followplayer;
	public boolean followplayerclose;
	public boolean giveBirth;
	public int timeUntilFurGrows;
	public int timeUntilBirth;
	public int maxHealth;
	public String playerName;

	public EntityTameSheep(World world) {
		super(world);
		if(mod_BabyAnimals.defaultTextures == 1) {
			this.texture = "/mob/sheep.png";
		} else {
			this.texture = "/BabyAnimals/tame_sheep.png";
		}

		this.setSize(0.9F, 1.3F);
		this.health = 20;
		this.stay = true;
		this.giveBirth = false;
		this.maxHealth = this.health;
	}

	protected void entityInit() {
		super.entityInit();
		this.dataWatcher.addObject(16, new Byte((byte)0));
	}

	public boolean attackEntityFrom(Entity entity, int i) {
		return super.attackEntityFrom(entity, i);
	}

	protected void dropFewItems() {
		if(!this.getSheared()) {
			this.entityDropItem(new ItemStack(Block.cloth.blockID, 1, this.getFleeceColor()), 0.0F);
		}

	}

	protected int getDropItemId() {
		return Block.cloth.blockID;
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(!this.worldObj.multiplayerWorld && this.giveBirth && --this.timeUntilBirth <= 0) {
			byte byte0 = (byte)(this.rand.nextInt(32) >= 1 ? 1 : 2);

			for(int i = 0; i < byte0; ++i) {
				this.lastTickPosX = this.posX;
				this.lastTickPosY = this.posY;
				this.lastTickPosZ = this.posZ;
				EntityLamb entitylamb = new EntityLamb(this.worldObj);
				entitylamb.stay = true;
				entitylamb.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);

				for(int j = 0; j < 20; ++j) {
					double d = this.rand.nextGaussian() * 0.02D;
					double d1 = this.rand.nextGaussian() * 0.02D;
					double d2 = this.rand.nextGaussian() * 0.02D;
					this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
				}

				this.worldObj.entityJoinedWorld(entitylamb);
			}

			this.giveBirth = false;
		}

		if(!this.worldObj.multiplayerWorld && --this.timeUntilFurGrows <= 0) {
			this.setSheared(false);
		}

	}

	public void setEntityDead() {
		if(!this.stay || this.health <= 0) {
			this.stay = false;
			super.setEntityDead();
		}
	}

	protected void updatePlayerActionState() {
		super.updatePlayerActionState();
		if(this.followplayer) {
			EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.playerName);
			if(entityplayer != null) {
				float f = entityplayer.getDistanceToEntity(this);
				if(f > 5.0F) {
					this.getPathOrWalkableBlock(entityplayer, f);
				}
			}
		}

	}

	private void getPathOrWalkableBlock(Entity entity, float f) {
		PathEntity pathentity = this.worldObj.getPathToEntity(this, entity, 16.0F);
		if(pathentity == null && f > 12.0F) {
			int i = MathHelper.floor_double(entity.posX) - 2;
			int j = MathHelper.floor_double(entity.posZ) - 2;
			int k = MathHelper.floor_double(entity.boundingBox.minY);

			for(int l = 0; l <= 4; ++l) {
				for(int i1 = 0; i1 <= 4; ++i1) {
					if((l < 1 || i1 < 1 || l > 3 || i1 > 3) && this.worldObj.isBlockOpaqueCube(i + l, k - 1, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k + 1, j + i1)) {
						this.setLocationAndAngles((double)((float)(i + l) + 0.5F), (double)k, (double)((float)(j + i1) + 0.5F), this.rotationYaw, this.rotationPitch);
						return;
					}
				}
			}
		} else {
			this.setPathToEntity(pathentity);
		}

	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(itemstack != null && itemstack.itemID == Item.shears.shiftedIndex && !this.getSheared()) {
			if(!this.worldObj.multiplayerWorld) {
				this.setSheared(true);
				int i = 2 + this.rand.nextInt(3);

				for(int j = 0; j < i; ++j) {
					EntityItem entityitem = this.entityDropItem(new ItemStack(Block.cloth.blockID, 1, this.getFleeceColor()), 1.0F);
					entityitem.motionY += (double)(this.rand.nextFloat() * 0.05F);
					entityitem.motionX += (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F);
					entityitem.motionZ += (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.1F);
				}

				this.timeUntilFurGrows = 24000;
				this.setFleeceColor(0);
			}

			itemstack.damageItem(1, entityplayer);
			return true;
		} else if(!this.followplayer && itemstack != null && itemstack.itemID == Item.seeds.shiftedIndex) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.playerName = entityplayer.username;
			this.followplayer = true;
			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
			if(!this.followplayerclose) {
				this.followplayerclose = true;
				this.moveSpeed = 0.9F;
				this.playerToAttack = entityplayer;
			} else {
				if(!this.followplayerclose) {
					return false;
				}

				this.followplayerclose = false;
				this.moveSpeed = 0.7F;
				this.playerToAttack = null;
			}

			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.miraclePotion.shiftedIndex && !this.giveBirth) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.giveBirth = true;
			this.timeUntilBirth = 120000;
			return true;
		} else if(itemstack != null && itemstack.itemID == Item.dyePowder.shiftedIndex && !this.getSheared() && this.getFleeceColor() != BlockCloth.func_21034_c(itemstack.getItemDamage())) {
			this.setFleeceColor(BlockCloth.func_21034_c(itemstack.getItemDamage()));
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			return true;
		} else if(itemstack == null || itemstack.itemID != Item.lightStoneDust.shiftedIndex || !this.giveBirth && !this.getSheared() && this.health >= this.maxHealth) {
			if(itemstack != null && itemstack.itemID == Item.wheat.shiftedIndex && this.health < this.maxHealth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.health += 2;
				if(this.health > this.maxHealth) {
					this.health = this.maxHealth;
				}

				return true;
			} else if(itemstack == null && this.followplayer) {
				this.followplayer = false;
				return true;
			} else {
				return false;
			}
		} else {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.timeUntilFurGrows = 0;
			this.timeUntilBirth = 0;
			this.health = this.maxHealth;
			return true;
		}
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("Sheared", this.getSheared());
		nbttagcompound.setByte("Color", (byte)this.getFleeceColor());
		nbttagcompound.setBoolean("StayInGame", this.stay);
		nbttagcompound.setInteger("GrowFur", this.timeUntilFurGrows);
		nbttagcompound.setInteger("HaveBaby", this.timeUntilBirth);
		nbttagcompound.setBoolean("FollowPlayer", this.followplayer);
		if(this.followplayer) {
			nbttagcompound.setString("PlayerName", this.playerName);
		} else {
			nbttagcompound.setString("PlayerName", "");
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.setSheared(nbttagcompound.getBoolean("Sheared"));
		this.setFleeceColor(nbttagcompound.getByte("Color"));
		this.stay = nbttagcompound.getBoolean("StayInGame");
		this.timeUntilFurGrows = nbttagcompound.getInteger("GrowFur");
		this.timeUntilBirth = nbttagcompound.getInteger("HaveBaby");
		this.followplayer = nbttagcompound.getBoolean("FollowPlayer");
		this.playerName = nbttagcompound.getString("PlayerName");
	}

	protected String getLivingSound() {
		return "mob.sheep";
	}

	protected String getHurtSound() {
		return "mob.sheep";
	}

	protected String getDeathSound() {
		return "mob.sheep";
	}

	public int getFleeceColor() {
		return this.dataWatcher.getWatchableObjectByte(16) & 15;
	}

	public void setFleeceColor(int i) {
		byte byte0 = this.dataWatcher.getWatchableObjectByte(16);
		this.dataWatcher.updateObject(16, (byte)(byte0 & 240 | i & 15));
	}

	public boolean getSheared() {
		return (this.dataWatcher.getWatchableObjectByte(16) & 16) != 0;
	}

	public void setSheared(boolean flag) {
		byte byte0 = this.dataWatcher.getWatchableObjectByte(16);
		if(flag) {
			this.dataWatcher.updateObject(16, (byte)(byte0 | 16));
		} else {
			this.dataWatcher.updateObject(16, (byte)(byte0 & -17));
		}

	}

	public static int getRandomFleeceColor(Random random) {
		int i = random.nextInt(100);
		return i < 5 ? 15 : (i < 10 ? 7 : (i < 15 ? 8 : (i < 18 ? 12 : (random.nextInt(500) != 0 ? 0 : 6))));
	}
}
