package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelTameChicken extends ModelBase {
	public ModelRenderer tameChickenleftLeg;

	public ModelTameChicken() {
		byte byte0 = 16;
		this.tameChickenleftLeg = new ModelRenderer(26, 0);
		this.tameChickenleftLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 5, 2);
		this.tameChickenleftLeg.setRotationPoint(1.0F, (float)(3 + byte0), 1.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.tameChickenleftLeg.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.tameChickenleftLeg.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
	}
}
