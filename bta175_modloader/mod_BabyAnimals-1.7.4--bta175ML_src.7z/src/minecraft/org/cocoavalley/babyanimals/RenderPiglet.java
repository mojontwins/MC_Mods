package org.cocoavalley.babyanimals;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderPiglet extends RenderLiving {
	public RenderPiglet(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	protected boolean renderTamedPiglet(EntityPiglet entitypiglet, int i, float f) {
		if(entitypiglet.stay) {
			this.loadTexture("/BabyAnimals/lambBell.png");
		}

		return i == 0 && entitypiglet.stay;
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.renderTamedPiglet((EntityPiglet)entityliving, i, f);
	}
}
