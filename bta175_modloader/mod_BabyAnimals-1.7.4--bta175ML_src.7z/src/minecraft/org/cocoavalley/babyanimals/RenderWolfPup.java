package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderWolfPup extends RenderLiving {
	public RenderWolfPup(ModelBase modelbase, float f) {
		super(modelbase, f);
	}

	public void func_25005_a(EntityWolfPup entitywolfpup, double d, double d1, double d2, float f, float f1) {
		super.doRenderLiving(entitywolfpup, d, d1, d2, f, f1);
	}

	protected float func_25004_a(EntityWolfPup entitywolfpup, float f) {
		return entitywolfpup.setTailRotation();
	}

	protected void func_25006_b(EntityWolfPup entitywolfpup, float f) {
	}

	protected void preRenderCallback(EntityLiving entityliving, float f) {
		this.func_25006_b((EntityWolfPup)entityliving, f);
	}

	protected float func_170_d(EntityLiving entityliving, float f) {
		return this.func_25004_a((EntityWolfPup)entityliving, f);
	}

	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
		this.func_25005_a((EntityWolfPup)entityliving, d, d1, d2, f, f1);
	}

	public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
		this.func_25005_a((EntityWolfPup)entity, d, d1, d2, f, f1);
	}
}
