package org.cocoavalley.babyanimals;

import org.lwjgl.opengl.GL11;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelWolfPup extends ModelBase {
	public ModelRenderer wolfPuphead = new ModelRenderer(0, 0);
	ModelRenderer wolfPupsnout;
	ModelRenderer wolfPupear1;
	ModelRenderer wolfPupear2;
	public ModelRenderer wolfPupbody;
	ModelRenderer wolfPupruff;
	public ModelRenderer wolfPupleg1;
	public ModelRenderer wolfPupleg2;
	public ModelRenderer wolfPupleg3;
	public ModelRenderer wolfPupleg4;
	ModelRenderer wolfPuptail;

	public ModelWolfPup() {
		this.wolfPuphead.addBox(-2.5F, -2.0F, -4.0F, 5, 4, 4, 0.0F);
		this.wolfPuphead.setRotationPoint(0.0F, 17.0F, -4.0F);
		this.wolfPupsnout = new ModelRenderer(18, 3);
		this.wolfPupsnout.addBox(-1.5F, 0.0F, -5.0F, 3, 2, 1, 0.0F);
		this.wolfPupsnout.setRotationPoint(0.0F, 17.0F, -4.0F);
		this.wolfPupear1 = new ModelRenderer(14, 0);
		this.wolfPupear1.addBox(-2.5F, -4.0F, -2.0F, 2, 2, 1, 0.0F);
		this.wolfPupear1.setRotationPoint(0.0F, 17.0F, -4.0F);
		this.wolfPupear2 = new ModelRenderer(14, 0);
		this.wolfPupear2.addBox(0.5F, -4.0F, -2.0F, 2, 2, 1, 0.0F);
		this.wolfPupear2.setRotationPoint(0.0F, 17.0F, -4.0F);
		this.wolfPupbody = new ModelRenderer(8, 8);
		this.wolfPupbody.addBox(-2.5F, -4.0F, -2.0F, 5, 8, 4, 0.0F);
		this.wolfPupbody.setRotationPoint(0.0F, 17.0F, 0.0F);
		this.wolfPupruff = new ModelRenderer(26, 0);
		this.wolfPupruff.addBox(-3.5F, -5.0F, -3.0F, 7, 4, 6, -0.5F);
		this.wolfPupruff.setRotationPoint(0.0F, 17.0F, 0.0F);
		this.wolfPupleg1 = new ModelRenderer(0, 8);
		this.wolfPupleg1.addBox(-1.0F, 0.0F, -1.0F, 2, 5, 2, 0.0F);
		this.wolfPupleg1.setRotationPoint(-1.5F, 19.0F, 3.0F);
		this.wolfPupleg2 = new ModelRenderer(0, 8);
		this.wolfPupleg2.addBox(-1.0F, 0.0F, -1.0F, 2, 5, 2, 0.0F);
		this.wolfPupleg2.setRotationPoint(1.5F, 19.0F, 3.0F);
		this.wolfPupleg3 = new ModelRenderer(0, 8);
		this.wolfPupleg3.addBox(-1.0F, 0.0F, -1.0F, 2, 5, 2, 0.0F);
		this.wolfPupleg3.setRotationPoint(-1.5F, 19.0F, -3.0F);
		this.wolfPupleg4 = new ModelRenderer(0, 8);
		this.wolfPupleg4.addBox(-1.0F, 0.0F, -1.0F, 2, 5, 2, 0.0F);
		this.wolfPupleg4.setRotationPoint(1.5F, 19.0F, -3.0F);
		this.wolfPuptail = new ModelRenderer(26, 10);
		this.wolfPuptail.addBox(-0.5F, 0.0F, -0.5F, 1, 3, 1, 0.0F);
		this.wolfPuptail.setRotationPoint(0.0F, 15.5F, 4.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		super.render(f, f1, f2, f3, f4, f5);
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.wolfPuphead.render(f5);
		this.wolfPupsnout.render(f5);
		this.wolfPupear1.render(f5);
		this.wolfPupear2.render(f5);
		this.wolfPupbody.render(f5);
		this.wolfPupruff.render(f5);
		this.wolfPupleg1.render(f5);
		this.wolfPupleg2.render(f5);
		this.wolfPupleg3.render(f5);
		this.wolfPupleg4.render(f5);
		this.wolfPuptail.renderWithRotation(f5);
	}

	public void setLivingAnimations(EntityLiving entityliving, float f, float f1, float f2) {
		EntityWolfPup entitywolfpup = (EntityWolfPup)entityliving;
		if(entitywolfpup.isWolfAngry()) {
			this.wolfPuptail.rotateAngleY = 0.0F;
		} else {
			this.wolfPuptail.rotateAngleY = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		}

		if(entitywolfpup.isWolfSitting()) {
			this.wolfPupruff.setRotationPoint(0.0F, 18.5F, -0.0F);
			this.wolfPupruff.rotateAngleX = 1.256637F;
			this.wolfPupruff.rotateAngleY = 0.0F;
			this.wolfPupbody.setRotationPoint(0.0F, 20.0F, 0.0F);
			this.wolfPupbody.rotateAngleX = 0.7853982F;
			this.wolfPuptail.setRotationPoint(0.0F, 22.0F, 3.0F);
			this.wolfPupleg1.setRotationPoint(-1.5F, 22.0F, 1.0F);
			this.wolfPupleg1.rotateAngleX = 4.712389F;
			this.wolfPupleg2.setRotationPoint(1.5F, 22.0F, 1.0F);
			this.wolfPupleg2.rotateAngleX = 4.712389F;
			this.wolfPupleg3.setRotationPoint(-1.5F, 19.0F, -3.0F);
			this.wolfPupleg3.rotateAngleX = 5.811947F;
			this.wolfPupleg4.setRotationPoint(1.51F, 19.0F, -3.0F);
			this.wolfPupleg4.rotateAngleX = 5.811947F;
		} else {
			this.wolfPupbody.setRotationPoint(0.0F, 17.0F, 0.0F);
			this.wolfPupbody.rotateAngleX = 1.570796F;
			this.wolfPupruff.setRotationPoint(0.0F, 17.0F, 0.0F);
			this.wolfPupruff.rotateAngleX = this.wolfPupbody.rotateAngleX;
			this.wolfPuptail.setRotationPoint(0.0F, 15.5F, 4.0F);
			this.wolfPupleg1.setRotationPoint(-1.5F, 19.0F, 3.0F);
			this.wolfPupleg2.setRotationPoint(1.5F, 19.0F, 3.0F);
			this.wolfPupleg3.setRotationPoint(-1.5F, 19.0F, -3.0F);
			this.wolfPupleg4.setRotationPoint(1.5F, 19.0F, -3.0F);
			this.wolfPupleg1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
			this.wolfPupleg2.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
			this.wolfPupleg3.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
			this.wolfPupleg4.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		}

		float f3 = entitywolfpup.getInterestedAngle(f2) + entitywolfpup.getShakeAngle(f2, 0.0F);
		this.wolfPuphead.rotateAngleZ = f3;
		this.wolfPupear1.rotateAngleZ = f3;
		this.wolfPupear2.rotateAngleZ = f3;
		this.wolfPupsnout.rotateAngleZ = f3;
		this.wolfPupruff.rotateAngleZ = entitywolfpup.getShakeAngle(f2, -0.08F);
		this.wolfPupbody.rotateAngleZ = entitywolfpup.getShakeAngle(f2, -0.16F);
		this.wolfPuptail.rotateAngleZ = entitywolfpup.getShakeAngle(f2, -0.2F);
		if(entitywolfpup.getWolfShaking()) {
			float f4 = entitywolfpup.getEntityBrightness(f2) * entitywolfpup.getShadingWhileShaking(f2);
			GL11.glColor3f(f4, f4, f4);
		}

	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.wolfPuphead.rotateAngleX = f4 / 57.29578F;
		this.wolfPuphead.rotateAngleY = f3 / 57.29578F;
		this.wolfPupsnout.rotateAngleY = this.wolfPuphead.rotateAngleY;
		this.wolfPupsnout.rotateAngleX = this.wolfPuphead.rotateAngleX;
		this.wolfPupear1.rotateAngleY = this.wolfPuphead.rotateAngleY;
		this.wolfPupear1.rotateAngleX = this.wolfPuphead.rotateAngleX;
		this.wolfPupear2.rotateAngleY = this.wolfPuphead.rotateAngleY;
		this.wolfPupear2.rotateAngleX = this.wolfPuphead.rotateAngleX;
		this.wolfPuptail.rotateAngleX = f2;
	}
}
