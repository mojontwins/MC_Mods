package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderTameChicken extends RenderLiving {
	public RenderTameChicken(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	public void renderChicken(EntityTameChicken entitytamechicken, double d, double d1, double d2, float f, float f1) {
		super.doRenderLiving(entitytamechicken, d, d1, d2, f, f1);
	}

	protected float getWingRotation(EntityTameChicken entitytamechicken, float f) {
		float f1 = entitytamechicken.field_756_e + (entitytamechicken.field_752_b - entitytamechicken.field_756_e) * f;
		float f2 = entitytamechicken.field_757_d + (entitytamechicken.destPos - entitytamechicken.field_757_d) * f;
		return (MathHelper.sin(f1) + 1.0F) * f2;
	}

	protected float func_170_d(EntityLiving entityliving, float f) {
		return this.getWingRotation((EntityTameChicken)entityliving, f);
	}

	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
		this.renderChicken((EntityTameChicken)entityliving, d, d1, d2, f, f1);
	}

	public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
		this.renderChicken((EntityTameChicken)entity, d, d1, d2, f, f1);
	}

	protected boolean renderTameChicken(EntityTameChicken entitytamechicken, int i, float f) {
		if(entitytamechicken.stay) {
			this.loadTexture("/BabyAnimals/chickenBand.png");
		}

		return i == 0 && entitytamechicken.stay;
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.renderTameChicken((EntityTameChicken)entityliving, i, f);
	}
}
