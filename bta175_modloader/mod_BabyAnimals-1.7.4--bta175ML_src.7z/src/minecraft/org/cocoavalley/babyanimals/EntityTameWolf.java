package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.ItemFood;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntityTameWolf extends EntityWolf {
	private boolean isWolfShaking;
	private boolean field_25052_g;
	public boolean newWolf;
	public boolean giveBirth;
	public int timeUntilBirth;
	public int maxHealth;
	public boolean followplayerclose;

	public EntityTameWolf(World world) {
		super(world);
		this.setSize(0.8F, 0.8F);
		this.moveSpeed = 1.1F;
		this.setWolfTamed(true);
		this.setPathToEntity((PathEntity)null);
		this.worldObj.setEntityState(this, (byte)7);
		this.health = 20;
		this.maxHealth = 20;
	}

	public String getEntityTexture() {
		return "/BabyAnimals/tame_wolf_blue.png";
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("Sitting", this.isWolfSitting());
		nbttagcompound.setInteger("HaveBaby", this.timeUntilBirth);
		if(this.getWolfOwner() == null) {
			nbttagcompound.setString("Owner", "");
		} else {
			nbttagcompound.setString("Owner", this.getWolfOwner());
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.setWolfSitting(nbttagcompound.getBoolean("Sitting"));
		this.timeUntilBirth = nbttagcompound.getInteger("HaveBaby");
		String s = nbttagcompound.getString("Owner");
		if(s.length() > 0) {
			this.setWolfOwner(s);
			this.setWolfTamed(true);
		}

	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(this.hasCurrentTarget() && !this.hasPath() && !this.isWolfAngry()) {
			Entity s = this.getCurrentTarget();
			if(s instanceof EntityPlayer) {
				EntityPlayer byte0 = (EntityPlayer)s;
				ItemStack i = byte0.inventory.getCurrentItem();
				if(i != null && Item.itemsList[i.itemID] instanceof ItemFood) {
					((ItemFood)Item.itemsList[i.itemID]).getIsWolfsFavoriteMeat();
				}

				if(byte0.isPlayerSleeping()) {
					this.setWolfSitting(true);
					this.isJumping = false;
					this.setPathToEntity((PathEntity)null);
				}
			}
		}

		if(!this.isMultiplayerEntity && this.isWolfShaking && !this.field_25052_g && !this.hasPath()) {
			this.field_25052_g = true;
			this.worldObj.setEntityState(this, (byte)8);
		}

		if(!this.worldObj.multiplayerWorld && this.giveBirth && --this.timeUntilBirth <= 0) {
			String string12 = this.getWolfOwner();
			byte b13 = (byte)(this.rand.nextInt(32) >= 1 ? 1 : 2);

			for(int i14 = 0; i14 < b13; ++i14) {
				this.lastTickPosX = this.posX;
				this.lastTickPosY = this.posY;
				this.lastTickPosZ = this.posZ;
				EntityWolfPup entitywolfpup = new EntityWolfPup(this.worldObj);
				entitywolfpup.setWolfOwner(string12);
				entitywolfpup.newPup = true;
				entitywolfpup.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);

				for(int j = 0; j < 20; ++j) {
					double d = this.rand.nextGaussian() * 0.02D;
					double d1 = this.rand.nextGaussian() * 0.02D;
					double d2 = this.rand.nextGaussian() * 0.02D;
					this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
				}

				this.worldObj.entityJoinedWorld(entitywolfpup);
			}

			this.giveBirth = false;
		}

	}

	protected void attackEntity(Entity entity, float f) {
		if(!this.isWolfTamed() || !(entity instanceof EntityPlayer)) {
			super.attackEntity(entity, f);
		}
	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(itemstack != null && Item.itemsList[itemstack.itemID] instanceof ItemFood) {
			ItemFood itemfood = (ItemFood)Item.itemsList[itemstack.itemID];
			if(itemfood.getIsWolfsFavoriteMeat() && this.dataWatcher.getWatchableObjectInt(18) < 20) {
				--itemstack.stackSize;
				if(itemstack.stackSize <= 0) {
					entityplayer.inventory.setInventorySlotContents(entityplayer.inventory.currentItem, (ItemStack)null);
				}

				this.heal(((ItemFood)Item.porkRaw).getHealAmount());
				return true;
			}
		} else {
			if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
				if(!this.followplayerclose) {
					if(this.isWolfSitting()) {
						this.setWolfSitting(false);
					}

					this.followplayerclose = true;
					this.playerToAttack = entityplayer;
				} else {
					if(!this.followplayerclose) {
						return false;
					}

					this.followplayerclose = false;
					this.playerToAttack = null;
				}

				return true;
			}

			if(itemstack != null && itemstack.itemID == Item.lightStoneDust.shiftedIndex && (this.dataWatcher.getWatchableObjectInt(18) < 20 || this.giveBirth)) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.heal(this.maxHealth);
				this.timeUntilBirth = 0;
				return true;
			}

			if(itemstack != null && itemstack.itemID == mod_BabyAnimals.miraclePotion.shiftedIndex && !this.giveBirth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.giveBirth = true;
				this.timeUntilBirth = 48000;
				return true;
			}
		}

		if(!this.worldObj.multiplayerWorld) {
			if(this.getWolfOwner() != entityplayer.username) {
				this.setWolfOwner(entityplayer.username);
			}

			this.setWolfSitting(!this.isWolfSitting());
			this.isJumping = false;
			this.setPathToEntity((PathEntity)null);
			return true;
		} else {
			return false;
		}
	}
}
