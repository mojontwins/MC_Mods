package org.cocoavalley.babyanimals;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderLamb extends RenderLiving {
	public RenderLamb(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	protected boolean renderTamedLamb(EntityLamb entitylamb, int i, float f) {
		if(entitylamb.stay) {
			this.loadTexture("/BabyAnimals/lambBell.png");
		}

		return i == 0 && entitylamb.stay;
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.renderTamedLamb((EntityLamb)entityliving, i, f);
	}
}
