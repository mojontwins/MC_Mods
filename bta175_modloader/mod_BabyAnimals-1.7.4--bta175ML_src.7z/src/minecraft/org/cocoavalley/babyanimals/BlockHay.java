package org.cocoavalley.babyanimals;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.Item;
import net.minecraft.src.Material;

public class BlockHay extends Block {
	public BlockHay(int i, int j) {
		super(i, j, Material.leaves);
	}

	public int idDropped(int i, Random random) {
		return Item.wheat.shiftedIndex;
	}

	public int quantityDropped(Random random) {
		return 4;
	}
}
