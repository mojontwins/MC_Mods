package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelSquick extends ModelBase {
	ModelRenderer squickbody = new ModelRenderer(0, 0);
	ModelRenderer[] squicktentacles = new ModelRenderer[8];
	ModelRenderer squickbill;
	ModelRenderer squickrightWing;
	ModelRenderer squickleftWing;
	ModelRenderer squickrightLeg;
	ModelRenderer squickleftLeg;
	public double degrees90 = Math.PI / 2D;
	public double pi = Math.PI;
	public double d;

	public ModelSquick() {
		this.squickbody.addBox(-3.0F, -4.0F, -3.0F, 6, 8, 6, 0.0F);
		this.squickbody.setRotationPoint(0.0F, 17.0F, 0.0F);
		this.squickbill = new ModelRenderer(0, 0);
		this.squickbill.addBox(-1.0F, 0.0F, -4.0F, 2, 1, 1, 0.0F);
		this.squickbill.setRotationPoint(0.0F, 18.0F, 0.0F);
		this.squickrightWing = new ModelRenderer(24, 7);
		this.squickrightWing.addBox(0.0F, 0.0F, -2.0F, 1, 3, 4, 0.0F);
		this.squickrightWing.setRotationPoint(-4.0F, 18.0F, 0.0F);
		this.squickleftWing = new ModelRenderer(24, 7);
		this.squickleftWing.addBox(-1.0F, 0.0F, -2.0F, 1, 3, 4, 0.0F);
		this.squickleftWing.setRotationPoint(4.0F, 18.0F, 0.0F);
		this.squickrightLeg = new ModelRenderer(18, 0);
		this.squickrightLeg.addBox(-1.5F, 0.0F, -3.0F, 3, 3, 3, 0.0F);
		this.squickrightLeg.setRotationPoint(-1.5F, 21.0F, 1.5F);
		this.squickleftLeg = new ModelRenderer(18, 0);
		this.squickleftLeg.addBox(-1.5F, 0.0F, -3.0F, 3, 3, 3, 0.0F);
		this.squickleftLeg.setRotationPoint(1.5F, 21.0F, 1.5F);

		for(int i = 0; i < this.squicktentacles.length; ++i) {
			this.d = (double)i * this.pi * 2.0D / (double)this.squicktentacles.length;
			float f = (float)Math.cos(this.d) * 2.5F;
			float f1 = (float)Math.sin(this.d) * 2.5F;
			this.squicktentacles[i] = new ModelRenderer(30, 0);
			this.squicktentacles[i].addBox(-0.5F, -8.0F, -0.5F, 1, 8, 1, 0.0F);
			this.squicktentacles[i].setRotationPoint(f, 13.0F, f1);
		}

	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		for(int i = 0; i < this.squicktentacles.length; ++i) {
			this.squicktentacles[i].rotateAngleX = MathHelper.cos(2.0F * f * 0.6662F) * 1.4F * f1 / 3.0F;
			this.d = (double)i * this.pi * -2.0D / (double)this.squicktentacles.length + this.degrees90;
			this.squicktentacles[i].rotateAngleY = (float)this.d;
		}

		this.squickbill.rotateAngleX = this.squickbody.rotateAngleX;
		this.squickbill.rotateAngleY = this.squickbody.rotateAngleY;
		this.squickrightLeg.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		this.squickleftLeg.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.squickrightWing.rotateAngleZ = f2;
		this.squickrightWing.rotateAngleY = this.squickbody.rotateAngleY;
		this.squickrightWing.rotateAngleX = this.squickbody.rotateAngleX;
		this.squickleftWing.rotateAngleZ = -f2;
		this.squickleftWing.rotateAngleY = this.squickbody.rotateAngleY;
		this.squickleftWing.rotateAngleX = this.squickbody.rotateAngleX;
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.squickbody.render(f5);
		this.squickbill.render(f5);
		this.squickrightLeg.render(f5);
		this.squickleftLeg.render(f5);
		this.squickrightWing.render(f5);
		this.squickleftWing.render(f5);

		for(int i = 0; i < this.squicktentacles.length; ++i) {
			this.squicktentacles[i].render(f5);
		}

	}
}
