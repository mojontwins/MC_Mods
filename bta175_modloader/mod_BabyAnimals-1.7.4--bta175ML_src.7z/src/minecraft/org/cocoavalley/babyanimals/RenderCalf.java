package org.cocoavalley.babyanimals;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderCalf extends RenderLiving {
	public RenderCalf(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	protected boolean renderTamedCalf(EntityCalf entitycalf, int i, float f) {
		if(entitycalf.stay) {
			this.loadTexture("/BabyAnimals/lambBell.png");
		}

		return i == 0 && entitycalf.stay;
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.renderTamedCalf((EntityCalf)entityliving, i, f);
	}
}
