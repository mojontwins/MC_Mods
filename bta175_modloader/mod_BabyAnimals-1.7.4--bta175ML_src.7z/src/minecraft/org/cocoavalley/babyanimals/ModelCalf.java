package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelCalf extends ModelBase {
	public ModelRenderer calfhead = new ModelRenderer(0, 0);
	public ModelRenderer calfhorn1;
	public ModelRenderer calfhorn2;
	public ModelRenderer calfbody;
	public ModelRenderer calfleg1;
	public ModelRenderer calfleg2;
	public ModelRenderer calfleg3;
	public ModelRenderer calfleg4;

	public ModelCalf() {
		this.calfhead.addBox(-3.0F, -3.0F, -3.0F, 6, 6, 4, 0.0F);
		this.calfhead.setRotationPoint(0.0F, 10.0F, -4.0F);
		this.calfhorn1 = new ModelRenderer(17, 0);
		this.calfhorn1.addBox(-3.5F, -4.0F, -2.0F, 1, 2, 1, 0.0F);
		this.calfhorn1.setRotationPoint(0.0F, 10.0F, -4.0F);
		this.calfhorn2 = new ModelRenderer(17, 0);
		this.calfhorn2.addBox(2.5F, -4.0F, -2.0F, 1, 2, 1, 0.0F);
		this.calfhorn2.setRotationPoint(0.0F, 10.0F, -4.0F);
		this.calfbody = new ModelRenderer(15, 5);
		this.calfbody.addBox(-3.0F, -4.5F, -2.5F, 6, 9, 5, 0.0F);
		this.calfbody.setRotationPoint(0.0F, 12.5F, 0.0F);
		this.calfleg1 = new ModelRenderer(0, 10);
		this.calfleg1.addBox(-1.0F, 0.0F, -1.0F, 2, 9, 2, 0.0F);
		this.calfleg1.setRotationPoint(-2.0F, 15.0F, 4.0F);
		this.calfleg2 = new ModelRenderer(0, 10);
		this.calfleg2.addBox(-1.0F, 0.0F, -1.0F, 2, 9, 2, 0.0F);
		this.calfleg2.setRotationPoint(2.0F, 15.0F, 4.0F);
		this.calfleg3 = new ModelRenderer(0, 10);
		this.calfleg3.addBox(-1.0F, 0.0F, -1.0F, 2, 9, 2, 0.0F);
		this.calfleg3.setRotationPoint(-2.0F, 15.0F, -3.0F);
		this.calfleg4 = new ModelRenderer(0, 10);
		this.calfleg4.addBox(-1.0F, 0.0F, -1.0F, 2, 9, 2, 0.0F);
		this.calfleg4.setRotationPoint(2.0F, 15.0F, -3.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.calfhead.render(f5);
		this.calfhorn1.render(f5);
		this.calfhorn2.render(f5);
		this.calfbody.render(f5);
		this.calfleg1.render(f5);
		this.calfleg2.render(f5);
		this.calfleg3.render(f5);
		this.calfleg4.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.calfhead.rotateAngleX = f4 / 57.29578F;
		this.calfhead.rotateAngleY = f3 / 57.29578F;
		this.calfhorn1.rotateAngleY = this.calfhead.rotateAngleY;
		this.calfhorn1.rotateAngleX = this.calfhead.rotateAngleX;
		this.calfhorn2.rotateAngleY = this.calfhead.rotateAngleY;
		this.calfhorn2.rotateAngleX = this.calfhead.rotateAngleX;
		this.calfbody.rotateAngleX = 1.570796F;
		this.calfleg1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		this.calfleg2.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.calfleg3.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.calfleg4.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
	}
}
