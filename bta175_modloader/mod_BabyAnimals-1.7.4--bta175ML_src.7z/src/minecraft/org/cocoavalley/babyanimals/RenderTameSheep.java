package org.cocoavalley.babyanimals;

import org.lwjgl.opengl.GL11;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderTameSheep extends RenderLiving {
	public RenderTameSheep(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	protected boolean hasFur(EntityTameSheep entitytamesheep, int i, float f) {
		if(i == 0 && !entitytamesheep.getSheared()) {
			this.loadTexture("/mob/sheep_fur.png");
			float f1 = entitytamesheep.getEntityBrightness(f);
			int j = entitytamesheep.getFleeceColor();
			GL11.glColor3f(f1 * EntityTameSheep.fleeceColorTable[j][0], f1 * EntityTameSheep.fleeceColorTable[j][1], f1 * EntityTameSheep.fleeceColorTable[j][2]);
			return true;
		} else {
			return false;
		}
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.hasFur((EntityTameSheep)entityliving, i, f);
	}
}
