package org.cocoavalley.babyanimals;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderChick extends RenderLiving {
	public RenderChick(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	protected boolean renderTamedChick(EntityChick entitychick, int i, float f) {
		if(entitychick.stay) {
			this.loadTexture("/BabyAnimals/lambBell.png");
		}

		return i == 0 && entitychick.stay;
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.renderTamedChick((EntityChick)entityliving, i, f);
	}
}
