package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderSquicken extends RenderLiving {
	public RenderSquicken(ModelBase modelbase, float f) {
		super(modelbase, f);
	}

	public void renderChicken(EntitySquicken entitysquicken, double d, double d1, double d2, float f, float f1) {
		super.doRenderLiving(entitysquicken, d, d1, d2, f, f1);
	}

	protected float getWingRotation(EntitySquicken entitysquicken, float f) {
		float f1 = entitysquicken.field_756_e + (entitysquicken.field_752_b - entitysquicken.field_756_e) * f;
		float f2 = entitysquicken.field_757_d + (entitysquicken.destPos - entitysquicken.field_757_d) * f;
		return (MathHelper.sin(f1) + 1.0F) * f2;
	}

	protected float func_170_d(EntityLiving entityliving, float f) {
		return this.getWingRotation((EntitySquicken)entityliving, f);
	}

	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
		this.renderChicken((EntitySquicken)entityliving, d, d1, d2, f, f1);
	}

	public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
		this.renderChicken((EntitySquicken)entity, d, d1, d2, f, f1);
	}
}
