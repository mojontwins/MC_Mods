package org.cocoavalley.babyanimals;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.World;

public class ItemLasso extends Item {
	public ItemLasso(int i) {
		super(i);
		this.maxStackSize = 1;
	}

	public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer) {
		entityplayer.swingItem();
		return itemstack;
	}

	public boolean isFull3D() {
		return true;
	}
}
