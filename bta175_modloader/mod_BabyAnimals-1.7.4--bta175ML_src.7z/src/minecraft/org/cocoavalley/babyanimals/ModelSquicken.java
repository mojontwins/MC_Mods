package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelSquicken extends ModelBase {
	ModelRenderer squickenbody = new ModelRenderer(0, 0);
	ModelRenderer[] squickententacles = new ModelRenderer[8];
	ModelRenderer squickenbill;
	ModelRenderer squickenchin;
	ModelRenderer squickenrightWing;
	ModelRenderer squickenleftWing;
	ModelRenderer squickenrightLeg;
	ModelRenderer squickenleftLeg;
	public double degrees90 = Math.PI / 2D;
	public double pi = Math.PI;
	public double d;

	public ModelSquicken() {
		this.squickenbody.addBox(-6.0F, -8.0F, -6.0F, 12, 16, 12, 0.0F);
		this.squickenbody.setRotationPoint(0.0F, 10.0F, 0.0F);
		this.squickenbill = new ModelRenderer(0, 0);
		this.squickenbill.addBox(-2.0F, 0.0F, -8.0F, 4, 2, 2, 0.0F);
		this.squickenbill.setRotationPoint(0.0F, 12.0F, 0.0F);
		this.squickenchin = new ModelRenderer(2, 4);
		this.squickenchin.addBox(-1.0F, 2.0F, -7.0F, 2, 2, 2, 0.0F);
		this.squickenchin.setRotationPoint(0.0F, 12.0F, 0.0F);
		this.squickenrightWing = new ModelRenderer(48, 20);
		this.squickenrightWing.addBox(0.0F, 0.0F, -3.0F, 1, 4, 6, 0.0F);
		this.squickenrightWing.setRotationPoint(-7.0F, 12.0F, 0.0F);
		this.squickenleftWing = new ModelRenderer(48, 20);
		this.squickenleftWing.addBox(-1.0F, 0.0F, -3.0F, 1, 4, 6, 0.0F);
		this.squickenleftWing.setRotationPoint(7.0F, 12.0F, 0.0F);
		this.squickenrightLeg = new ModelRenderer(36, 0);
		this.squickenrightLeg.addBox(-1.5F, 0.0F, -3.0F, 3, 6, 3, 0.0F);
		this.squickenrightLeg.setRotationPoint(-2.0F, 18.0F, 1.0F);
		this.squickenleftLeg = new ModelRenderer(36, 0);
		this.squickenleftLeg.addBox(-1.5F, 0.0F, -3.0F, 3, 6, 3, 0.0F);
		this.squickenleftLeg.setRotationPoint(2.0F, 18.0F, 1.0F);

		for(int i = 0; i < this.squickententacles.length; ++i) {
			this.d = (double)i * this.pi * 2.0D / (double)this.squickententacles.length;
			float f = (float)Math.cos(this.d) * 5.0F;
			float f1 = (float)Math.sin(this.d) * 5.0F;
			this.squickententacles[i] = new ModelRenderer(48, 0);
			this.squickententacles[i].addBox(-1.0F, -18.0F, -1.0F, 2, 18, 2, 0.0F);
			this.squickententacles[i].setRotationPoint(f, 2.0F, f1);
		}

	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		for(int i = 0; i < this.squickententacles.length; ++i) {
			this.squickententacles[i].rotateAngleX = MathHelper.cos(2.0F * f * 0.6662F) * 1.4F * f1 / 3.0F;
			this.d = (double)i * this.pi * -2.0D / (double)this.squickententacles.length + this.degrees90;
			this.squickententacles[i].rotateAngleY = (float)this.d;
		}

		this.squickenbill.rotateAngleX = this.squickenbody.rotateAngleX;
		this.squickenbill.rotateAngleY = this.squickenbody.rotateAngleY;
		this.squickenchin.rotateAngleX = this.squickenbody.rotateAngleX;
		this.squickenchin.rotateAngleY = this.squickenbody.rotateAngleY;
		this.squickenrightLeg.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		this.squickenleftLeg.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.squickenrightWing.rotateAngleZ = f2;
		this.squickenrightWing.rotateAngleY = this.squickenbody.rotateAngleY;
		this.squickenrightWing.rotateAngleX = this.squickenbody.rotateAngleX;
		this.squickenleftWing.rotateAngleZ = -f2;
		this.squickenleftWing.rotateAngleY = this.squickenbody.rotateAngleY;
		this.squickenleftWing.rotateAngleX = this.squickenbody.rotateAngleX;
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.squickenbody.render(f5);
		this.squickenbill.render(f5);
		this.squickenchin.render(f5);
		this.squickenrightLeg.render(f5);
		this.squickenleftLeg.render(f5);
		this.squickenrightWing.render(f5);
		this.squickenleftWing.render(f5);

		for(int i = 0; i < this.squickententacles.length; ++i) {
			this.squickententacles[i].render(f5);
		}

	}
}
