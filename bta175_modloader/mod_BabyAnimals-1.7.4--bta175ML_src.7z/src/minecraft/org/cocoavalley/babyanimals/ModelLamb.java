package org.cocoavalley.babyanimals;

import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelLamb extends ModelBase {
	public ModelRenderer lambhead = new ModelRenderer(0, 0);
	public ModelRenderer lambbody;
	public ModelRenderer lambleg1;
	public ModelRenderer lambleg2;
	public ModelRenderer lambleg3;
	public ModelRenderer lambleg4;

	public ModelLamb() {
		this.lambhead.addBox(-3.0F, -2.5F, -3.0F, 6, 5, 4, 0.0F);
		this.lambhead.setRotationPoint(0.0F, 13.0F, -4.0F);
		this.lambbody = new ModelRenderer(15, 4);
		this.lambbody.addBox(-3.0F, -4.5F, -2.5F, 6, 9, 5, 0.0F);
		this.lambbody.setRotationPoint(0.0F, 15.5F, 0.0F);
		this.lambleg1 = new ModelRenderer(0, 9);
		this.lambleg1.addBox(-1.0F, 0.0F, -1.0F, 2, 6, 2, 0.0F);
		this.lambleg1.setRotationPoint(-2.0F, 18.0F, 4.0F);
		this.lambleg2 = new ModelRenderer(0, 9);
		this.lambleg2.addBox(-1.0F, 0.0F, -1.0F, 2, 6, 2, 0.0F);
		this.lambleg2.setRotationPoint(2.0F, 18.0F, 4.0F);
		this.lambleg3 = new ModelRenderer(0, 9);
		this.lambleg3.addBox(-1.0F, 0.0F, -1.0F, 2, 6, 2, 0.0F);
		this.lambleg3.setRotationPoint(-2.0F, 18.0F, -3.0F);
		this.lambleg4 = new ModelRenderer(0, 9);
		this.lambleg4.addBox(-1.0F, 0.0F, -1.0F, 2, 6, 2, 0.0F);
		this.lambleg4.setRotationPoint(2.0F, 18.0F, -3.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.lambhead.render(f5);
		this.lambbody.render(f5);
		this.lambleg1.render(f5);
		this.lambleg2.render(f5);
		this.lambleg3.render(f5);
		this.lambleg4.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.lambhead.rotateAngleX = f4 / 57.29578F;
		this.lambhead.rotateAngleY = f3 / 57.29578F;
		this.lambbody.rotateAngleX = 1.570796F;
		this.lambleg1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
		this.lambleg2.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.lambleg3.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
		this.lambleg4.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
	}
}
