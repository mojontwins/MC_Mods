package org.cocoavalley.babyanimals;

import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityAnimal;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntitySquick extends EntityAnimal {
	public boolean field_753_a = false;
	public float field_752_b = 0.0F;
	public float destPos = 0.0F;
	public float field_757_d;
	public float field_756_e;
	public float field_755_h = 1.0F;
	public boolean stay;
	public boolean growUp;
	public boolean followplayer;
	public boolean followplayerclose;
	public int maxHealth;
	public String playerName;

	public EntitySquick(World world) {
		super(world);
		this.texture = "/BabyAnimals/squick.png";
		this.setSize(0.5F, 0.8F);
		this.health = 10;
		this.maxHealth = this.health;
		this.stay = true;
		this.growUp = false;
	}

	protected boolean canTriggerWalking() {
		return false;
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		this.field_756_e = this.field_752_b;
		this.field_757_d = this.destPos;
		this.destPos = (float)((double)this.destPos + (double)(this.onGround ? -1 : 4) * 0.3D);
		if(this.destPos < 0.0F) {
			this.destPos = 0.0F;
		}

		if(this.destPos > 1.0F) {
			this.destPos = 1.0F;
		}

		if(!this.onGround && this.field_755_h < 1.0F) {
			this.field_755_h = 1.0F;
		}

		this.field_755_h = (float)((double)this.field_755_h * 0.9D);
		if(!this.onGround && this.motionY < 0.0D) {
			this.motionY *= 0.6D;
		}

		this.field_752_b += this.field_755_h * 2.0F;
		if(!this.worldObj.multiplayerWorld && this.growUp) {
			this.lastTickPosX = this.posX;
			this.lastTickPosY = this.posY;
			this.lastTickPosZ = this.posZ;
			EntitySquicken entitysquicken = new EntitySquicken(this.worldObj);
			entitysquicken.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
			entitysquicken.health = this.health * 2;

			for(int i = 0; i < 20; ++i) {
				double d = this.rand.nextGaussian() * 0.02D;
				double d1 = this.rand.nextGaussian() * 0.02D;
				double d2 = this.rand.nextGaussian() * 0.02D;
				this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
			}

			this.worldObj.entityJoinedWorld(entitysquicken);
			this.health = 0;
			this.setEntityDead();
			this.growUp = false;
		}

	}

	protected void fall(float f) {
	}

	public boolean canBreatheUnderwater() {
		return true;
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("FollowPlayer", this.followplayer);
		nbttagcompound.setBoolean("StayInGame", this.stay);
		if(this.followplayer) {
			nbttagcompound.setString("PlayerName", this.playerName);
		} else {
			nbttagcompound.setString("PlayerName", "");
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.followplayer = nbttagcompound.getBoolean("FollowPlayer");
		this.stay = nbttagcompound.getBoolean("StayInGame");
		this.playerName = nbttagcompound.getString("PlayerName");
	}

	public void setEntityDead() {
		if(!this.stay || this.health <= 0) {
			this.stay = false;
			super.setEntityDead();
		}
	}

	protected void updatePlayerActionState() {
		super.updatePlayerActionState();
		if(this.followplayer) {
			EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.playerName);
			if(entityplayer != null) {
				float f = entityplayer.getDistanceToEntity(this);
				if(f > 5.0F) {
					this.getPathOrWalkableBlock(entityplayer, f);
				}
			}
		}

	}

	private void getPathOrWalkableBlock(Entity entity, float f) {
		PathEntity pathentity = this.worldObj.getPathToEntity(this, entity, 16.0F);
		if(pathentity == null && f > 12.0F) {
			int i = MathHelper.floor_double(entity.posX) - 2;
			int j = MathHelper.floor_double(entity.posZ) - 2;
			int k = MathHelper.floor_double(entity.boundingBox.minY);

			for(int l = 0; l <= 4; ++l) {
				for(int i1 = 0; i1 <= 4; ++i1) {
					if((l < 1 || i1 < 1 || l > 3 || i1 > 3) && this.worldObj.isBlockOpaqueCube(i + l, k - 1, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k + 1, j + i1)) {
						this.setLocationAndAngles((double)((float)(i + l) + 0.5F), (double)k, (double)((float)(j + i1) + 0.5F), this.rotationYaw, this.rotationPitch);
						return;
					}
				}
			}
		} else {
			this.setPathToEntity(pathentity);
		}

	}

	protected String getLivingSound() {
		return "chick";
	}

	protected String getHurtSound() {
		return "chick";
	}

	protected String getDeathSound() {
		return "chick";
	}

	protected float getSoundVolume() {
		return 0.4F;
	}

	protected int getDropItemId() {
		return 0;
	}

	protected void dropFewItems() {
		int i = this.rand.nextInt(3);

		int k;
		for(k = 0; k < i; ++k) {
			this.entityDropItem(new ItemStack(Item.dyePowder, 1, 0), 0.0F);
		}

		i = this.rand.nextInt(3);

		for(k = 0; k < i; ++k) {
			this.dropItem(Item.feather.shiftedIndex, 1);
		}

	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(!this.followplayer && itemstack != null && itemstack.itemID == Item.seeds.shiftedIndex) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.playerName = entityplayer.username;
			this.followplayer = true;
			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
			if(!this.followplayerclose) {
				this.followplayerclose = true;
				this.moveSpeed = 0.9F;
				this.playerToAttack = entityplayer;
			} else {
				if(!this.followplayerclose) {
					return false;
				}

				this.followplayerclose = false;
				this.moveSpeed = 0.7F;
				this.playerToAttack = null;
			}

			return true;
		} else if(itemstack != null && itemstack.itemID == Item.lightStoneDust.shiftedIndex && this.health < this.maxHealth) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.health = this.maxHealth;
			return true;
		} else if(itemstack != null && (itemstack.itemID == Item.fishRaw.shiftedIndex || itemstack.itemID == Item.fishCooked.shiftedIndex) && this.health < this.maxHealth) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.health += 3;
			if(this.health > this.maxHealth) {
				this.health = this.maxHealth;
			}

			return true;
		} else if(itemstack == null || itemstack.itemID != Item.cake.shiftedIndex && itemstack.itemID != Block.cake.blockID) {
			if(itemstack == null && this.followplayer) {
				this.followplayer = false;
				return true;
			} else {
				return false;
			}
		} else {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.growUp = true;
			return true;
		}
	}
}
