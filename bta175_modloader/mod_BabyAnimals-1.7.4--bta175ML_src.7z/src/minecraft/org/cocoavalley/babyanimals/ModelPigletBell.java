package org.cocoavalley.babyanimals;

import net.minecraft.src.ModelBase;
import net.minecraft.src.ModelRenderer;

public class ModelPigletBell extends ModelBase {
	public ModelRenderer PigletBellbody = new ModelRenderer(16, 5);

	public ModelPigletBell() {
		this.PigletBellbody.addBox(-3.0F, -4.0F, -2.0F, 6, 8, 4, 0.0F);
		this.PigletBellbody.setRotationPoint(0.0F, 19.0F, 0.0F);
	}

	public void render(float f, float f1, float f2, float f3, float f4, float f5) {
		this.setRotationAngles(f, f1, f2, f3, f4, f5);
		this.PigletBellbody.render(f5);
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
		this.PigletBellbody.rotateAngleX = 1.570796F;
	}
}
