package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityAnimal;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntitySquicken extends EntityAnimal {
	public boolean field_753_a = false;
	public float field_752_b = 0.0F;
	public float destPos = 0.0F;
	public float field_757_d;
	public float field_756_e;
	public float field_755_h = 1.0F;
	public int timeUntilNextEgg;
	public boolean stay;
	public boolean followplayer;
	public boolean followplayerclose;
	public int maxHealth;
	public String playerName;

	public EntitySquicken(World world) {
		super(world);
		this.texture = "/BabyAnimals/squicken.png";
		this.setSize(0.7F, 1.5F);
		this.health = 20;
		this.stay = true;
		this.timeUntilNextEgg = this.rand.nextInt(3000) + 3000;
		this.maxHealth = this.health;
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		this.field_756_e = this.field_752_b;
		this.field_757_d = this.destPos;
		this.destPos = (float)((double)this.destPos + (double)(this.onGround ? -1 : 4) * 0.3D);
		if(this.destPos < 0.0F) {
			this.destPos = 0.0F;
		}

		if(this.destPos > 1.0F) {
			this.destPos = 1.0F;
		}

		if(!this.onGround && this.field_755_h < 1.0F) {
			this.field_755_h = 1.0F;
		}

		this.field_755_h = (float)((double)this.field_755_h * 0.9D);
		if(!this.onGround && this.motionY < 0.0D) {
			this.motionY *= 0.6D;
		}

		this.field_752_b += this.field_755_h * 2.0F;
		if(!this.worldObj.multiplayerWorld && --this.timeUntilNextEgg <= 0) {
			this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
			this.entityDropItem(new ItemStack(Item.dyePowder, 1, 0), 0.0F);
			this.timeUntilNextEgg = this.rand.nextInt(3000) + 3000;
		}

	}

	protected void fall(float f) {
	}

	public boolean canBreatheUnderwater() {
		return true;
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("FollowPlayer", this.followplayer);
		nbttagcompound.setBoolean("StayInGame", this.stay);
		if(this.followplayer) {
			nbttagcompound.setString("PlayerName", this.playerName);
		} else {
			nbttagcompound.setString("PlayerName", "");
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.followplayer = nbttagcompound.getBoolean("FollowPlayer");
		this.stay = nbttagcompound.getBoolean("StayInGame");
		this.playerName = nbttagcompound.getString("PlayerName");
	}

	public void setEntityDead() {
		if(!this.stay || this.health <= 0) {
			this.stay = false;
			super.setEntityDead();
		}
	}

	protected void updatePlayerActionState() {
		super.updatePlayerActionState();
		if(this.followplayer) {
			EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.playerName);
			if(entityplayer != null) {
				float f = entityplayer.getDistanceToEntity(this);
				if(f > 5.0F) {
					this.getPathOrWalkableBlock(entityplayer, f);
				}
			}
		}

	}

	private void getPathOrWalkableBlock(Entity entity, float f) {
		PathEntity pathentity = this.worldObj.getPathToEntity(this, entity, 16.0F);
		if(pathentity == null && f > 12.0F) {
			int i = MathHelper.floor_double(entity.posX) - 2;
			int j = MathHelper.floor_double(entity.posZ) - 2;
			int k = MathHelper.floor_double(entity.boundingBox.minY);

			for(int l = 0; l <= 4; ++l) {
				for(int i1 = 0; i1 <= 4; ++i1) {
					if((l < 1 || i1 < 1 || l > 3 || i1 > 3) && this.worldObj.isBlockOpaqueCube(i + l, k - 1, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k + 1, j + i1)) {
						this.setLocationAndAngles((double)((float)(i + l) + 0.5F), (double)k, (double)((float)(j + i1) + 0.5F), this.rotationYaw, this.rotationPitch);
						return;
					}
				}
			}
		} else {
			this.setPathToEntity(pathentity);
		}

	}

	protected String getLivingSound() {
		return "mob.chicken";
	}

	protected String getHurtSound() {
		return "mob.chickenhurt";
	}

	protected String getDeathSound() {
		return "mob.chickenhurt";
	}

	protected int getDropItemId() {
		return 0;
	}

	protected void dropFewItems() {
		int i = this.rand.nextInt(3);

		int k;
		for(k = 0; k < i; ++k) {
			this.entityDropItem(new ItemStack(Item.dyePowder, 1, 0), 0.0F);
		}

		i = this.rand.nextInt(3);

		for(k = 0; k < i; ++k) {
			this.dropItem(Item.feather.shiftedIndex, 1);
		}

	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(!this.followplayer && itemstack != null && itemstack.itemID == Item.seeds.shiftedIndex) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.playerName = entityplayer.username;
			this.followplayer = true;
			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
			if(!this.followplayerclose) {
				this.followplayerclose = true;
				this.moveSpeed = 0.9F;
				this.playerToAttack = entityplayer;
			} else {
				if(!this.followplayerclose) {
					return false;
				}

				this.followplayerclose = false;
				this.moveSpeed = 0.7F;
				this.playerToAttack = null;
			}

			return true;
		} else if(itemstack == null || itemstack.itemID != Item.lightStoneDust.shiftedIndex || this.health >= this.maxHealth && this.timeUntilNextEgg <= 0) {
			if(itemstack != null && (itemstack.itemID == Item.fishRaw.shiftedIndex || itemstack.itemID == Item.fishCooked.shiftedIndex) && this.health < this.maxHealth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.health += 3;
				if(this.health > this.maxHealth) {
					this.health = this.maxHealth;
				}

				return true;
			} else if(itemstack == null && this.followplayer) {
				this.followplayer = false;
				return true;
			} else {
				return false;
			}
		} else {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.timeUntilNextEgg = 0;
			this.health = this.maxHealth;
			return true;
		}
	}
}
