package org.cocoavalley.babyanimals;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderTamePig extends RenderLiving {
	public RenderTamePig(ModelBase modelbase, ModelBase modelbase1, float f) {
		super(modelbase, f);
		this.setRenderPassModel(modelbase1);
	}

	protected boolean renderSaddledPig(EntityTamePig entitytamepig, int i, float f) {
		this.loadTexture("/mob/saddle.png");
		return i == 0 && entitytamepig.getSaddled();
	}

	protected boolean shouldRenderPass(EntityLiving entityliving, int i, float f) {
		return this.renderSaddledPig((EntityTamePig)entityliving, i, f);
	}
}
