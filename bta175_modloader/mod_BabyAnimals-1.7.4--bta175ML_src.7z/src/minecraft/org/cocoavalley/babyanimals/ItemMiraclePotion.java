package org.cocoavalley.babyanimals;

import net.minecraft.src.Item;

public class ItemMiraclePotion extends Item {
	public ItemMiraclePotion(int i) {
		super(i);
		this.maxStackSize = 3;
	}

	public boolean isFull3D() {
		return true;
	}
}
