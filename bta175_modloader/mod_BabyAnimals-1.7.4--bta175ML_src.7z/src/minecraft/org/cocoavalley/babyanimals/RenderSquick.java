package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;

public class RenderSquick extends RenderLiving {
	public RenderSquick(ModelBase modelbase, float f) {
		super(modelbase, f);
	}

	public void renderChicken(EntitySquick entitysquick, double d, double d1, double d2, float f, float f1) {
		super.doRenderLiving(entitysquick, d, d1, d2, f, f1);
	}

	protected float getWingRotation(EntitySquick entitysquick, float f) {
		float f1 = entitysquick.field_756_e + (entitysquick.field_752_b - entitysquick.field_756_e) * f;
		float f2 = entitysquick.field_757_d + (entitysquick.destPos - entitysquick.field_757_d) * f;
		return (MathHelper.sin(f1) + 1.0F) * f2;
	}

	protected float func_170_d(EntityLiving entityliving, float f) {
		return this.getWingRotation((EntitySquick)entityliving, f);
	}

	public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
		this.renderChicken((EntitySquick)entityliving, d, d1, d2, f, f1);
	}

	public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
		this.renderChicken((EntitySquick)entity, d, d1, d2, f, f1);
	}
}
