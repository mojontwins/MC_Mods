package net.minecraft.src;

import java.util.Map;

import org.cocoavalley.babyanimals.BlockHay;
import org.cocoavalley.babyanimals.EntityCalf;
import org.cocoavalley.babyanimals.EntityChick;
import org.cocoavalley.babyanimals.EntityFertileEgg;
import org.cocoavalley.babyanimals.EntityLamb;
import org.cocoavalley.babyanimals.EntityPiglet;
import org.cocoavalley.babyanimals.EntitySquick;
import org.cocoavalley.babyanimals.EntitySquicken;
import org.cocoavalley.babyanimals.EntitySquickenEgg;
import org.cocoavalley.babyanimals.EntityTameChicken;
import org.cocoavalley.babyanimals.EntityTameCow;
import org.cocoavalley.babyanimals.EntityTamePig;
import org.cocoavalley.babyanimals.EntityTameSheep;
import org.cocoavalley.babyanimals.EntityTameWolf;
import org.cocoavalley.babyanimals.EntityWolfPup;
import org.cocoavalley.babyanimals.ItemFertileEgg;
import org.cocoavalley.babyanimals.ItemLasso;
import org.cocoavalley.babyanimals.ItemMiraclePotion;
import org.cocoavalley.babyanimals.ItemSquickenEgg;
import org.cocoavalley.babyanimals.ModelCalf;
import org.cocoavalley.babyanimals.ModelCalfBell;
import org.cocoavalley.babyanimals.ModelChick;
import org.cocoavalley.babyanimals.ModelChickBell;
import org.cocoavalley.babyanimals.ModelLamb;
import org.cocoavalley.babyanimals.ModelLambBell;
import org.cocoavalley.babyanimals.ModelPiglet;
import org.cocoavalley.babyanimals.ModelPigletBell;
import org.cocoavalley.babyanimals.ModelSquick;
import org.cocoavalley.babyanimals.ModelSquicken;
import org.cocoavalley.babyanimals.ModelTameChicken;
import org.cocoavalley.babyanimals.ModelWolfPup;
import org.cocoavalley.babyanimals.RenderCalf;
import org.cocoavalley.babyanimals.RenderChick;
import org.cocoavalley.babyanimals.RenderLamb;
import org.cocoavalley.babyanimals.RenderPiglet;
import org.cocoavalley.babyanimals.RenderSquick;
import org.cocoavalley.babyanimals.RenderSquicken;
import org.cocoavalley.babyanimals.RenderTameChicken;
import org.cocoavalley.babyanimals.RenderTameCow;
import org.cocoavalley.babyanimals.RenderTamePig;
import org.cocoavalley.babyanimals.RenderTameSheep;
import org.cocoavalley.babyanimals.RenderWolfPup;

public class mod_BabyAnimals extends BaseModMp {

	@MLProp(name="calvesSpawn", info="Spawn calves, 0 = No, 1 = Yes")
	public static int calvesSpawn = 1;
	
	@MLProp(name="chicksSpawn", info="Spawn chicks, 0 = No, 1 = Yes")
	public static int chicksSpawn = 1;
	
	@MLProp(name="lambsSpawn", info="Spawn lambs, 0 = No, 1 = Yes")
	public static int lambsSpawn = 1;
	
	@MLProp(name="pigletsSpawn", info="Spawn piglets, 0 = No, 1 = Yes")
	public static int pigletsSpawn = 1;
	
	@MLProp(name="pigletsSpawn", info="Spawn pups, 0 = No, 1 = Yes")
	public static int pupsSpawn = 1;
	
	@MLProp(name="squeggID")
	public static int squeggID = 8450;
	
	@MLProp(name="potionID")
	public static int potionID = 8451;
	
	@MLProp(name="lassoID")
	public static int lassoID = 8453;

	@MLProp(name="tameEggID")
	public static int tameEggID = 8454;
	
	@MLProp(name="baleID")
	public static int baleID = 160;
	
	@MLProp(name="defaultTextures", info="Use 1 to get adults from your texture pack, 0 to use textures that come with the mod")
	public static int defaultTextures = 0;
	
	@MLProp(name="maxPassiveMobs", info="Max. Passive mobs, 15 is the number Minecraft comes with.")
	public int maxPassiveMobs = 30;
	
	@MLProp(name="entityPigletID")
	public static int entityPigletID = 2006;
	
	@MLProp(name="entityCalfID")
	public static int entityCalfID = 2007;
	
	@MLProp(name="entityLambID")
	public static int entityLambID = 2008;
	
	@MLProp(name="entityChickID")
	public static int entityChickID = 2009;
	
	@MLProp(name="entityTameChickenID")
	public static int entityTameChickenID = 2010;
	
	@MLProp(name="entityTameCowID")
	public static int entityTameCowID = 2011;
	
	@MLProp(name="entityTameP�gID")
	public static int entityTameP�gID = 2012;
	
	@MLProp(name="entityTameSheepID")
	public static int entityTameSheepID = 2013;
	
	@MLProp(name="entityWolfPupID")
	public static int entityWolfPupID = 2014;
	
	@MLProp(name="entityTameWolfID")
	public static int entityTameWolfID = 2015;
	
	@MLProp(name="entitySquickenID")
	public static int entitySquickenID = 2016;
	
	@MLProp(name="entitySquickID")
	public static int entitySquickID = 2017;
	
	public static Block bale; 
	public static int squegg = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/squegg.png");
	public static int potion = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/mpotion.png");
	public static int shears = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/shears.png");
	public static int lasso = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/lasso.png");
	public static int tameEgg = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/tameEgg.png");
	
	public static Item squickenEgg;
	public static Item miraclePotion;
	public static Item ropeLasso;
	public static Item fertileEgg;

	@Override
	public String Version() {
		return "mod_BabyAnimals by cocoavalley version 1.7.3";
	}

	public mod_BabyAnimals() {
		
		// Add sounds
		
		ModLoader.RegisterResource(this, "calf1", "/BabyAnimals/calf1.ogg");
		ModLoader.RegisterResource(this, "calfhurt1", "/BabyAnimals/calfhurt1.ogg");
		ModLoader.RegisterResource(this, "chick1", "/BabyAnimals/chick1.ogg");
		ModLoader.RegisterResource(this, "chick2", "/BabyAnimals/chick2.ogg");
		ModLoader.RegisterResource(this, "chickhurt1", "/BabyAnimals/chickhurt1.ogg");
		ModLoader.RegisterResource(this, "lamb1", "/BabyAnimals/lamb1.ogg");
		ModLoader.RegisterResource(this, "lamb2", "/BabyAnimals/lamb2.ogg");
		ModLoader.RegisterResource(this, "piglet1", "/BabyAnimals/piglet1.ogg");
		ModLoader.RegisterResource(this, "piglet2", "/BabyAnimals/piglet2.ogg");
		ModLoader.RegisterResource(this, "pigletdeath", "/BabyAnimals/pigletdeath.ogg");
		ModLoader.RegisterResource(this, "pup_bark1", "/BabyAnimals/pup_bark1.ogg");
		ModLoader.RegisterResource(this, "pup_bark2", "/BabyAnimals/pup_bark2.ogg");
		ModLoader.RegisterResource(this, "pup_death", "/BabyAnimals/pup_death.ogg");
		ModLoader.RegisterResource(this, "pup_hurt1", "/BabyAnimals/pup_hurt1.ogg");
		ModLoader.RegisterResource(this, "pup_hurt2", "/BabyAnimals/pup_hurt2.ogg");
		ModLoader.RegisterResource(this, "pup_hurt3", "/BabyAnimals/pup_hurt3.ogg");
		ModLoader.RegisterResource(this, "pup_whine1", "/BabyAnimals/pup_whine1.ogg");
		
		// Modify passive mob cap

		try {
			ModLoader.setPrivateValue(EnumCreatureType.class, EnumCreatureType.creature, "e", this.maxPassiveMobs);
		} catch (Exception exception2) {
		}
		
		// Blocks & Items
		
		bale = (new BlockHay(baleID, 0)).setHardness(0.2F).setStepSound(Block.soundGrassFootstep).setBlockName("Hay");
		squickenEgg = (new ItemSquickenEgg(squeggID)).setItemName("squickenEgg").setIconIndex(squegg);
		miraclePotion = (new ItemMiraclePotion(potionID)).setItemName("miraclePotion").setIconIndex(potion);
		ropeLasso = (new ItemLasso(lassoID)).setItemName("lasso").setIconIndex(lasso);
		fertileEgg = (new ItemFertileEgg(tameEggID)).setItemName("fertileEgg").setIconIndex(tameEgg);
		
		ModLoader.RegisterBlock(bale);
		bale.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/BabyAnimals/hay.png");
		ModLoader.AddName(bale, "Hay Bale");
		ModLoader.AddName(squickenEgg, "Squicken Egg");
		ModLoader.AddName(miraclePotion, "Miracle Potion");
		ModLoader.AddName(ropeLasso, "Lasso");
		ModLoader.AddName(fertileEgg, "Fertile Egg");
		
		ModLoader.RegisterEntityID(EntityPiglet.class, "Piglet", entityPigletID);
		ModLoader.RegisterEntityID(EntityCalf.class, "Calf", entityCalfID);
		ModLoader.RegisterEntityID(EntityLamb.class, "Lamb", entityLambID);
		ModLoader.RegisterEntityID(EntityChick.class, "Chick", entityChickID);
		ModLoader.RegisterEntityID(EntityTameChicken.class, "TameChicken", entityTameChickenID);
		ModLoader.RegisterEntityID(EntityTameCow.class, "TameCow", entityTameCowID);
		ModLoader.RegisterEntityID(EntityTamePig.class, "TamePig", entityTameP�gID);
		ModLoader.RegisterEntityID(EntityTameSheep.class, "TameSheep", entityTameSheepID);
		ModLoader.RegisterEntityID(EntityWolfPup.class, "WolfPup", entityWolfPupID);
		ModLoader.RegisterEntityID(EntityTameWolf.class, "TameWolf", entityTameWolfID);
		ModLoader.RegisterEntityID(EntitySquicken.class, "Squicken", entitySquickenID);
		ModLoader.RegisterEntityID(EntitySquick.class, "Squick", entitySquickID);
		
		// Spawn upon config
		
		if(pigletsSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityPiglet.class, 10, EnumCreatureType.creature);
		}

		if(calvesSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityCalf.class, 8, EnumCreatureType.creature);
		}

		if(lambsSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityLamb.class, 10, EnumCreatureType.creature);
		}

		if(chicksSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityChick.class, 10, EnumCreatureType.creature);
		}

		if(pupsSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityWolfPup.class, 2, EnumCreatureType.creature);
		}

		// Recipes
		
		ModLoader.AddShapelessRecipe(new ItemStack(squickenEgg, 1), new Object[]{new ItemStack(Item.dyePowder, 1, 0), Item.egg});
		ModLoader.AddShapelessRecipe(new ItemStack(squickenEgg, 1), new Object[]{new ItemStack(Item.dyePowder, 1, 0), fertileEgg});
		ModLoader.AddShapelessRecipe(new ItemStack(Item.silk, 9), new Object[]{new ItemStack(Block.cloth)});
		ModLoader.AddShapelessRecipe(new ItemStack(Item.wheat, 4), new Object[]{new ItemStack(bale)});
		ModLoader.AddShapelessRecipe(new ItemStack(fertileEgg, 1), new Object[]{miraclePotion, Item.egg});
		ModLoader.AddRecipe(new ItemStack(bale, 1), new Object[]{"##", "##", '#', new ItemStack(Item.wheat)});
		ModLoader.AddRecipe(new ItemStack(ropeLasso, 1), new Object[]{"###", "# #", "###", '#', Item.silk});
		ModLoader.AddRecipe(new ItemStack(miraclePotion, 3), new Object[]{"###", "YXY", "@@@", '#', Item.wheat, 'X', Item.cake, 'Y', Item.seeds, '@', Item.bucketWater});
		ModLoader.AddRecipe(new ItemStack(miraclePotion, 3), new Object[]{"###", "YXY", "@@@", '#', Item.wheat, 'X', Block.cake, 'Y', Item.seeds, '@', Item.bucketWater});
		ModLoader.AddRecipe(new ItemStack(Item.cake), new Object[]{"###", "YXY", "@@@", '#', Item.bucketMilk, 'X', squickenEgg, 'Y', Item.sugar, '@', Item.wheat});
		ModLoader.AddRecipe(new ItemStack(Item.cake), new Object[]{"###", "YXY", "@@@", '#', Item.bucketMilk, 'X', fertileEgg, 'Y', Item.sugar, '@', Item.wheat});
	}

	@Override
	public void AddRenderer(Map<Class<?>, Render> map) {
		map.put(EntityPiglet.class, new RenderPiglet(new ModelPiglet(), new ModelPigletBell(), 0.35F));
		map.put(EntityCalf.class, new RenderCalf(new ModelCalf(), new ModelCalfBell(), 0.35F));
		map.put(EntityLamb.class, new RenderLamb(new ModelLamb(), new ModelLambBell(), 0.35F));
		map.put(EntityChick.class, new RenderChick(new ModelChick(), new ModelChickBell(), 0.2F));
		map.put(EntityTameChicken.class, new RenderTameChicken(new ModelChicken(), new ModelTameChicken(), 0.35F));
		map.put(EntityTameCow.class, new RenderTameCow(new ModelCow(), 0.7F));
		map.put(EntityTamePig.class, new RenderTamePig(new ModelPig(), new ModelPig(0.5F), 0.7F));
		map.put(EntityTameSheep.class, new RenderTameSheep(new ModelSheep2(), new ModelSheep1(), 0.7F));
		map.put(EntityWolfPup.class, new RenderWolfPup(new ModelWolfPup(), 0.35F));
		map.put(EntityTameWolf.class, new RenderWolf(new ModelWolf(), 0.5F));
		map.put(EntitySquicken.class, new RenderSquicken(new ModelSquicken(), 0.5F));
		map.put(EntitySquick.class, new RenderSquick(new ModelSquick(), 0.2F));
		map.put(EntitySquickenEgg.class, new RenderSnowball(squegg));
		map.put(EntityFertileEgg.class, new RenderSnowball(tameEgg));
	}
}
