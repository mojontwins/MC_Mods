package net.minecraft.src;

import org.cocoavalley.babyanimals.BlockHay;
import org.cocoavalley.babyanimals.EntityCalf;
import org.cocoavalley.babyanimals.EntityChick;
import org.cocoavalley.babyanimals.EntityLamb;
import org.cocoavalley.babyanimals.EntityPiglet;
import org.cocoavalley.babyanimals.EntitySquick;
import org.cocoavalley.babyanimals.EntitySquicken;
import org.cocoavalley.babyanimals.EntityTameChicken;
import org.cocoavalley.babyanimals.EntityTameCow;
import org.cocoavalley.babyanimals.EntityTamePig;
import org.cocoavalley.babyanimals.EntityTameSheep;
import org.cocoavalley.babyanimals.EntityTameWolf;
import org.cocoavalley.babyanimals.EntityWolfPup;
import org.cocoavalley.babyanimals.ItemFertileEgg;
import org.cocoavalley.babyanimals.ItemLasso;
import org.cocoavalley.babyanimals.ItemMiraclePotion;
import org.cocoavalley.babyanimals.ItemSquickenEgg;

public class mod_BabyAnimals extends BaseModMp {
	@MLProp(name="calvesSpawn", info="Spawn calves, 0 = No, 1 = Yes")
	public static int calvesSpawn = 1;
	
	@MLProp(name="chicksSpawn", info="Spawn chicks, 0 = No, 1 = Yes")
	public static int chicksSpawn = 1;
	
	@MLProp(name="lambsSpawn", info="Spawn lambs, 0 = No, 1 = Yes")
	public static int lambsSpawn = 1;
	
	@MLProp(name="pigletsSpawn", info="Spawn piglets, 0 = No, 1 = Yes")
	public static int pigletsSpawn = 1;
	
	@MLProp(name="pigletsSpawn", info="Spawn pups, 0 = No, 1 = Yes")
	public static int pupsSpawn = 1;
	
	@MLProp(name="squeggID")
	public static int squeggID = 8450;
	
	@MLProp(name="potionID")
	public static int potionID = 8451;
	
	@MLProp(name="lassoID")
	public static int lassoID = 8453;

	@MLProp(name="tameEggID")
	public static int tameEggID = 8454;
	
	@MLProp(name="baleID")
	public static int baleID = 160;
	
	@MLProp(name="defaultTextures", info="Use 1 to get adults from your texture pack, 0 to use textures that come with the mod")
	public static int defaultTextures = 0;
	
	@MLProp(name="maxPassiveMobs", info="Max. Passive mobs, 15 is the number Minecraft comes with.")
	public int maxPassiveMobs = 30;
	
	@MLProp(name="entityPigletID")
	public static int entityPigletID = 2006;
	
	@MLProp(name="entityCalfID")
	public static int entityCalfID = 2007;
	
	@MLProp(name="entityLambID")
	public static int entityLambID = 2008;
	
	@MLProp(name="entityChickID")
	public static int entityChickID = 2009;
	
	@MLProp(name="entityTameChickenID")
	public static int entityTameChickenID = 2010;
	
	@MLProp(name="entityTameCowID")
	public static int entityTameCowID = 2011;
	
	@MLProp(name="entityTameP�gID")
	public static int entityTameP�gID = 2012;
	
	@MLProp(name="entityTameSheepID")
	public static int entityTameSheepID = 2013;
	
	@MLProp(name="entityWolfPupID")
	public static int entityWolfPupID = 2014;
	
	@MLProp(name="entityTameWolfID")
	public static int entityTameWolfID = 2015;
	
	@MLProp(name="entitySquickenID")
	public static int entitySquickenID = 2016;
	
	@MLProp(name="entitySquickID")
	public static int entitySquickID = 2017;
	
	public static Block bale; 
	public static int squegg = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/squegg.png");
	public static int potion = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/mpotion.png");
	public static int shears = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/shears.png");
	public static int lasso = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/lasso.png");
	public static int tameEgg = ModLoader.addOverride("/gui/items.png", "/BabyAnimals/tameEgg.png");
	
	public static Item squickenEgg;
	public static Item miraclePotion;
	public static Item ropeLasso;
	public static Item fertileEgg;

	@Override
	public String Version() {
		return "mod_BabyAnimals by cocoavalley version 1.7.3";
	}

	public mod_BabyAnimals() {
				
		// Modify passive mob cap

		try {
			ModLoader.setPrivateValue(EnumCreatureType.class, EnumCreatureType.creature, "e", this.maxPassiveMobs);
		} catch (Exception exception2) {
		}
		
		// Blocks & Items
		
		bale = (new BlockHay(baleID, 0)).setHardness(0.2F).setStepSound(Block.soundGrassFootstep).setBlockName("Hay");
		squickenEgg = (new ItemSquickenEgg(squeggID)).setItemName("squickenEgg").setIconIndex(squegg);
		miraclePotion = (new ItemMiraclePotion(potionID)).setItemName("miraclePotion").setIconIndex(potion);
		ropeLasso = (new ItemLasso(lassoID)).setItemName("lasso").setIconIndex(lasso);
		fertileEgg = (new ItemFertileEgg(tameEggID)).setItemName("fertileEgg").setIconIndex(tameEgg);
		
		ModLoader.RegisterBlock(bale);
		bale.blockIndexInTexture = ModLoader.addOverride("/terrain.png", "/BabyAnimals/hay.png");
		
		ModLoader.RegisterEntityID(EntityPiglet.class, "Piglet", entityPigletID);
		ModLoader.RegisterEntityID(EntityCalf.class, "Calf", entityCalfID);
		ModLoader.RegisterEntityID(EntityLamb.class, "Lamb", entityLambID);
		ModLoader.RegisterEntityID(EntityChick.class, "Chick", entityChickID);
		ModLoader.RegisterEntityID(EntityTameChicken.class, "TameChicken", entityTameChickenID);
		ModLoader.RegisterEntityID(EntityTameCow.class, "TameCow", entityTameCowID);
		ModLoader.RegisterEntityID(EntityTamePig.class, "TamePig", entityTameP�gID);
		ModLoader.RegisterEntityID(EntityTameSheep.class, "TameSheep", entityTameSheepID);
		ModLoader.RegisterEntityID(EntityWolfPup.class, "WolfPup", entityWolfPupID);
		ModLoader.RegisterEntityID(EntityTameWolf.class, "TameWolf", entityTameWolfID);
		ModLoader.RegisterEntityID(EntitySquicken.class, "Squicken", entitySquickenID);
		ModLoader.RegisterEntityID(EntitySquick.class, "Squick", entitySquickID);
		
		// Spawn upon config
		
		if(pigletsSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityPiglet.class, 10, EnumCreatureType.creature);
		}

		if(calvesSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityCalf.class, 8, EnumCreatureType.creature);
		}

		if(lambsSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityLamb.class, 10, EnumCreatureType.creature);
		}

		if(chicksSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityChick.class, 10, EnumCreatureType.creature);
		}

		if(pupsSpawn == 1) {
			ModLoader.AddSpawn((Class<?>)EntityWolfPup.class, 2, EnumCreatureType.creature);
		}

		// Recipes
		
		ModLoader.AddShapelessRecipe(new ItemStack(squickenEgg, 1), new Object[]{new ItemStack(Item.dyePowder, 1, 0), Item.egg});
		ModLoader.AddShapelessRecipe(new ItemStack(squickenEgg, 1), new Object[]{new ItemStack(Item.dyePowder, 1, 0), fertileEgg});
		ModLoader.AddShapelessRecipe(new ItemStack(Item.silk, 9), new Object[]{new ItemStack(Block.cloth)});
		ModLoader.AddShapelessRecipe(new ItemStack(Item.wheat, 4), new Object[]{new ItemStack(bale)});
		ModLoader.AddShapelessRecipe(new ItemStack(fertileEgg, 1), new Object[]{miraclePotion, Item.egg});
		ModLoader.AddRecipe(new ItemStack(bale, 1), new Object[]{"##", "##", '#', new ItemStack(Item.wheat)});
		ModLoader.AddRecipe(new ItemStack(ropeLasso, 1), new Object[]{"###", "# #", "###", '#', Item.silk});
		ModLoader.AddRecipe(new ItemStack(miraclePotion, 3), new Object[]{"###", "YXY", "@@@", '#', Item.wheat, 'X', Item.cake, 'Y', Item.seeds, '@', Item.bucketWater});
		ModLoader.AddRecipe(new ItemStack(miraclePotion, 3), new Object[]{"###", "YXY", "@@@", '#', Item.wheat, 'X', Block.cake, 'Y', Item.seeds, '@', Item.bucketWater});
		ModLoader.AddRecipe(new ItemStack(Item.cake), new Object[]{"###", "YXY", "@@@", '#', Item.bucketMilk, 'X', squickenEgg, 'Y', Item.sugar, '@', Item.wheat});
		ModLoader.AddRecipe(new ItemStack(Item.cake), new Object[]{"###", "YXY", "@@@", '#', Item.bucketMilk, 'X', fertileEgg, 'Y', Item.sugar, '@', Item.wheat});
	}

}
