package org.cocoavalley.babyanimals;

import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityAnimal;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntityCalf extends EntityAnimal {
	public boolean stay;
	public boolean followplayer;
	public boolean growUp;
	public int maxHealth;
	public String playerName;
	public boolean followplayerclose;

	public EntityCalf(World world) {
		super(world);
		this.texture = "/BabyAnimals/calf.png";
		this.setSize(0.7F, 0.8F);
		this.health = 4;
		this.maxHealth = this.health;
		this.growUp = false;
	}

	protected boolean canTriggerWalking() {
		return false;
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(!this.worldObj.singleplayerWorld && this.growUp) {
			this.lastTickPosX = this.posX;
			this.lastTickPosY = this.posY;
			this.lastTickPosZ = this.posZ;
			EntityTameCow entitytamecow = new EntityTameCow(this.worldObj);
			entitytamecow.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
			entitytamecow.health = this.health * 2;

			for(int i = 0; i < 20; ++i) {
				double d = this.rand.nextGaussian() * 0.02D;
				double d1 = this.rand.nextGaussian() * 0.02D;
				double d2 = this.rand.nextGaussian() * 0.02D;
				this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
			}

			this.worldObj.entityJoinedWorld(entitytamecow);
			this.health = 0;
			this.setEntityDead();
			this.growUp = false;
		}

	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("FollowPlayer", this.followplayer);
		nbttagcompound.setBoolean("StayInGame", this.stay);
		if(this.followplayer) {
			nbttagcompound.setString("PlayerName", this.playerName);
		} else {
			nbttagcompound.setString("PlayerName", "");
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.followplayer = nbttagcompound.getBoolean("FollowPlayer");
		this.stay = nbttagcompound.getBoolean("StayInGame");
		this.playerName = nbttagcompound.getString("PlayerName");
	}

	public void setEntityDead() {
		if(!this.stay || this.health <= 0) {
			this.stay = false;
			super.setEntityDead();
		}
	}

	protected void updatePlayerActionState() {
		super.updatePlayerActionState();
		if(this.followplayer) {
			EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.playerName);
			if(entityplayer != null) {
				float f = entityplayer.getDistanceToEntity(this);
				if(f > 5.0F) {
					this.getPathOrWalkableBlock(entityplayer, f);
				}
			}
		}

	}

	private void getPathOrWalkableBlock(Entity entity, float f) {
		PathEntity pathentity = this.worldObj.getPathToEntity(this, entity, 16.0F);
		if(pathentity == null && f > 12.0F) {
			int i = MathHelper.floor_double(entity.posX) - 2;
			int j = MathHelper.floor_double(entity.posZ) - 2;
			int k = MathHelper.floor_double(entity.boundingBox.minY);

			for(int l = 0; l <= 4; ++l) {
				for(int i1 = 0; i1 <= 4; ++i1) {
					if((l < 1 || i1 < 1 || l > 3 || i1 > 3) && this.worldObj.isBlockOpaqueCube(i + l, k - 1, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k + 1, j + i1)) {
						this.setLocationAndAngles((double)((float)(i + l) + 0.5F), (double)k, (double)((float)(j + i1) + 0.5F), this.rotationYaw, this.rotationPitch);
						return;
					}
				}
			}
		} else {
			this.setPathToEntity(pathentity);
		}

	}

	protected String getLivingSound() {
		return "calf";
	}

	protected String getHurtSound() {
		return "calfhurt";
	}

	protected String getDeathSound() {
		return "calfhurt";
	}

	protected float getSoundVolume() {
		return 0.4F;
	}

	protected int getDropItemId() {
		return Item.leather.shiftedIndex;
	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(!this.followplayer && itemstack != null && itemstack.itemID == Item.seeds.shiftedIndex) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.playerName = entityplayer.username;
			this.followplayer = true;
			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
			if(!this.followplayerclose) {
				this.followplayerclose = true;
				this.moveSpeed = 0.9F;
				this.playerToAttack = entityplayer;
			} else {
				if(!this.followplayerclose) {
					return false;
				}

				this.followplayerclose = false;
				this.moveSpeed = 0.7F;
				this.playerToAttack = null;
			}

			return true;
		} else if(!this.stay && itemstack != null && itemstack.itemID == Item.wheat.shiftedIndex) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.health *= 2;
			this.maxHealth *= 2;
			this.stay = true;
			return true;
		} else if(!this.stay || itemstack == null || (itemstack.itemID != Item.dyePowder.shiftedIndex || itemstack.getItemDamage() != 2) && itemstack.itemID != Block.cactus.blockID) {
			if(this.stay && itemstack != null && (itemstack.itemID == Item.cake.shiftedIndex || itemstack.itemID == Block.cake.blockID)) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.growUp = true;
				return true;
			} else if(this.stay && itemstack != null && itemstack.itemID == Item.lightStoneDust.shiftedIndex && this.health < this.maxHealth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.health = this.maxHealth;
				return true;
			} else if(this.stay && itemstack != null && itemstack.itemID == Item.wheat.shiftedIndex && this.health < this.maxHealth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.health += 2;
				if(this.health > this.maxHealth) {
					this.health = this.maxHealth;
				}

				return true;
			} else if(itemstack == null && this.followplayer) {
				this.followplayer = false;
				return true;
			} else {
				return false;
			}
		} else {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			if(this.health > 1) {
				this.health /= 2;
			}

			this.maxHealth /= 2;
			this.stay = false;
			this.followplayer = false;
			return true;
		}
	}
}
