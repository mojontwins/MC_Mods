package org.cocoavalley.babyanimals;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.ItemFood;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntityTameWolf extends EntityWolf {
	private boolean isWolfShaking;
	private boolean field_25052_g;
	public boolean newWolf;
	public boolean giveBirth;
	public int timeUntilBirth;
	public int maxHealth;
	public boolean followplayerclose;

	public EntityTameWolf(World world) {
		super(world);
		this.setSize(0.8F, 0.8F);
		this.moveSpeed = 1.1F;
		this.setIsTamed(true);
		this.setPathToEntity((PathEntity)null);
		this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)7);
		this.health = 20;
		this.maxHealth = 20;
	}

	public String getEntityTexture() {
		return "/BabyAnimals/tame_wolf_blue.png";
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("Sitting", this.getIsSitting());
		nbttagcompound.setInteger("HaveBaby", this.timeUntilBirth);
		if(this.getOwner() == null) {
			nbttagcompound.setString("Owner", "");
		} else {
			nbttagcompound.setString("Owner", this.getOwner());
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.setIsSitting(nbttagcompound.getBoolean("Sitting"));
		this.timeUntilBirth = nbttagcompound.getInteger("HaveBaby");
		String s = nbttagcompound.getString("Owner");
		if(s.length() > 0) {
			this.setOwner(s);
			this.setIsTamed(true);
		}

	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(this.func_25021_O() && !this.getGotPath() && !this.getIsAngry()) {
			Entity s = this.getCurrentTarget();
			if(s instanceof EntityPlayer) {
				EntityPlayer byte0 = (EntityPlayer)s;
				ItemStack i = byte0.inventory.getCurrentItem();
				if(i != null && Item.itemsList[i.itemID] instanceof ItemFood) {
					((ItemFood)Item.itemsList[i.itemID]).func_25010_k();
				}

				if(byte0.func_22057_E()) {
					this.setIsSitting(true);
					this.isJumping = false;
					this.setPathToEntity((PathEntity)null);
				}
			}
		}

		if(!this.isMultiplayerEntity && this.isWolfShaking && !this.field_25052_g && !this.getGotPath()) {
			this.field_25052_g = true;
			this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)8);
		}

		if(!this.worldObj.singleplayerWorld && this.giveBirth && --this.timeUntilBirth <= 0) {
			String string12 = this.getOwner();
			byte b13 = (byte)(this.rand.nextInt(32) >= 1 ? 1 : 2);

			for(int i14 = 0; i14 < b13; ++i14) {
				this.lastTickPosX = this.posX;
				this.lastTickPosY = this.posY;
				this.lastTickPosZ = this.posZ;
				EntityWolfPup entitywolfpup = new EntityWolfPup(this.worldObj);
				entitywolfpup.setOwner(string12);
				entitywolfpup.newPup = true;
				entitywolfpup.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);

				for(int j = 0; j < 20; ++j) {
					double d = this.rand.nextGaussian() * 0.02D;
					double d1 = this.rand.nextGaussian() * 0.02D;
					double d2 = this.rand.nextGaussian() * 0.02D;
					this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
				}

				this.worldObj.entityJoinedWorld(entitywolfpup);
			}

			this.giveBirth = false;
		}

	}

	protected void attackEntity(Entity entity, float f) {
		if(!this.func_25030_y() || !(entity instanceof EntityPlayer)) {
			super.attackEntity(entity, f);
		}
	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(itemstack != null && Item.itemsList[itemstack.itemID] instanceof ItemFood) {
			ItemFood itemfood = (ItemFood)Item.itemsList[itemstack.itemID];
			if(itemfood.func_25010_k() && this.dataWatcher.getWatchableObjectInteger(18) < 20) {
				--itemstack.stackSize;
				if(itemstack.stackSize <= 0) {
					entityplayer.inventory.setInventorySlotContents(entityplayer.inventory.currentItem, (ItemStack)null);
				}

				this.heal(((ItemFood)Item.porkRaw).getHealAmount());
				return true;
			}
		} else {
			if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
				if(!this.followplayerclose) {
					if(this.getIsSitting()) {
						this.setIsSitting(false);
					}

					this.followplayerclose = true;
					this.playerToAttack = entityplayer;
				} else {
					if(!this.followplayerclose) {
						return false;
					}

					this.followplayerclose = false;
					this.playerToAttack = null;
				}

				return true;
			}

			if(itemstack != null && itemstack.itemID == Item.lightStoneDust.shiftedIndex && (this.dataWatcher.getWatchableObjectInteger(18) < 20 || this.giveBirth)) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.heal(this.maxHealth);
				this.timeUntilBirth = 0;
				return true;
			}

			if(itemstack != null && itemstack.itemID == mod_BabyAnimals.miraclePotion.shiftedIndex && !this.giveBirth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.giveBirth = true;
				this.timeUntilBirth = 48000;
				return true;
			}
		}

		if(!this.worldObj.singleplayerWorld) {
			if(this.getOwner() != entityplayer.username) {
				this.setOwner(entityplayer.username);
			}

			this.setIsSitting(!this.getIsSitting());
			this.isJumping = false;
			this.setPathToEntity((PathEntity)null);
			return true;
		} else {
			return false;
		}
	}
}
