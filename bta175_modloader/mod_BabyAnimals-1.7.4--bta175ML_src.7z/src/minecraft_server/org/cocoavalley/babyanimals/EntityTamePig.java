package org.cocoavalley.babyanimals;

import net.minecraft.src.AchievementList;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityAnimal;
import net.minecraft.src.EntityLightningBolt;
import net.minecraft.src.EntityPigZombie;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntityTamePig extends EntityAnimal {
	public boolean struckByLightning;
	public boolean stay;
	public boolean followplayer;
	public boolean followplayerclose;
	public boolean giveBirth;
	public boolean controlled;
	public int timeUntilBirth;
	public int maxHealth;
	public String playerName;

	public EntityTamePig(World world) {
		super(world);
		if(mod_BabyAnimals.defaultTextures == 1) {
			this.texture = "/mob/pig.png";
		} else {
			this.texture = "/BabyAnimals/tame_pig.png";
		}

		this.setSize(0.9F, 0.9F);
		this.health = 20;
		this.stay = true;
		this.giveBirth = false;
		this.maxHealth = this.health;
		this.struckByLightning = false;
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(!this.worldObj.singleplayerWorld && this.giveBirth && --this.timeUntilBirth <= 0) {
			byte byte0 = (byte)(this.rand.nextInt(32) >= 1 ? 1 : 2);

			for(int i = 0; i < byte0; ++i) {
				this.lastTickPosX = this.posX;
				this.lastTickPosY = this.posY;
				this.lastTickPosZ = this.posZ;
				EntityPiglet entitypiglet = new EntityPiglet(this.worldObj);
				entitypiglet.stay = true;
				entitypiglet.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);

				for(int j = 0; j < 20; ++j) {
					double d = this.rand.nextGaussian() * 0.02D;
					double d1 = this.rand.nextGaussian() * 0.02D;
					double d2 = this.rand.nextGaussian() * 0.02D;
					this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
				}

				this.worldObj.entityJoinedWorld(entitypiglet);
			}

			this.giveBirth = false;
		}

	}

	protected void entityInit() {
		this.dataWatcher.addObject(16, (byte)0);
	}

	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("Saddle", this.getSaddled());
		nbttagcompound.setBoolean("StayInGame", this.stay);
		nbttagcompound.setInteger("HaveBaby", this.timeUntilBirth);
		nbttagcompound.setBoolean("FollowPlayer", this.followplayer);
		if(this.followplayer) {
			nbttagcompound.setString("PlayerName", this.playerName);
		} else {
			nbttagcompound.setString("PlayerName", "");
		}

	}

	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		this.setSaddled(nbttagcompound.getBoolean("Saddle"));
		this.stay = nbttagcompound.getBoolean("StayInGame");
		this.timeUntilBirth = nbttagcompound.getInteger("HaveBaby");
		this.followplayer = nbttagcompound.getBoolean("FollowPlayer");
		this.playerName = nbttagcompound.getString("PlayerName");
	}

	public void setEntityDead() {
		if(!this.stay || this.health <= 0) {
			this.stay = false;
			super.setEntityDead();
		}
	}

	protected void updatePlayerActionState() {
		super.updatePlayerActionState();
		if(this.followplayer) {
			EntityPlayer entityplayer = this.worldObj.getPlayerEntityByName(this.playerName);
			if(entityplayer != null) {
				float f = entityplayer.getDistanceToEntity(this);
				if(f > 5.0F) {
					this.getPathOrWalkableBlock(entityplayer, f);
				}
			}
		}

	}

	private void getPathOrWalkableBlock(Entity entity, float f) {
		PathEntity pathentity = this.worldObj.getPathToEntity(this, entity, 16.0F);
		if(pathentity == null && f > 12.0F) {
			int i = MathHelper.floor_double(entity.posX) - 2;
			int j = MathHelper.floor_double(entity.posZ) - 2;
			int k = MathHelper.floor_double(entity.boundingBox.minY);

			for(int l = 0; l <= 4; ++l) {
				for(int i1 = 0; i1 <= 4; ++i1) {
					if((l < 1 || i1 < 1 || l > 3 || i1 > 3) && this.worldObj.isBlockOpaqueCube(i + l, k - 1, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k, j + i1) && !this.worldObj.isBlockOpaqueCube(i + l, k + 1, j + i1)) {
						this.setLocationAndAngles((double)((float)(i + l) + 0.5F), (double)k, (double)((float)(j + i1) + 0.5F), this.rotationYaw, this.rotationPitch);
						return;
					}
				}
			}
		} else {
			this.setPathToEntity(pathentity);
		}

	}

	protected String getLivingSound() {
		return "mob.pig";
	}

	protected String getHurtSound() {
		return "mob.pig";
	}

	protected String getDeathSound() {
		return "mob.pigdeath";
	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(itemstack != null && itemstack.itemID == Item.stick.shiftedIndex && this.getSaddled() && !this.worldObj.singleplayerWorld && (this.riddenByEntity == null || this.riddenByEntity == entityplayer)) {
			entityplayer.mountEntity(this);
			return true;
		} else if(!this.followplayer && itemstack != null && itemstack.itemID == Item.seeds.shiftedIndex) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.playerName = entityplayer.username;
			this.followplayer = true;
			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
			if(!this.followplayerclose) {
				this.followplayerclose = true;
				this.moveSpeed = 0.9F;
				this.playerToAttack = entityplayer;
			} else {
				if(!this.followplayerclose) {
					return false;
				}

				this.followplayerclose = false;
				this.moveSpeed = 0.7F;
				this.playerToAttack = null;
			}

			return true;
		} else if(itemstack != null && itemstack.itemID == mod_BabyAnimals.miraclePotion.shiftedIndex && !this.giveBirth) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.giveBirth = true;
			this.timeUntilBirth = 96000;
			return true;
		} else if(itemstack != null && itemstack.itemID == Item.saddle.shiftedIndex && !this.getSaddled()) {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.setSaddled(true);
			return true;
		} else if(itemstack == null || itemstack.itemID != Item.lightStoneDust.shiftedIndex || !this.giveBirth && this.health >= this.maxHealth) {
			if(itemstack != null && itemstack.itemID == Item.wheat.shiftedIndex && this.health < this.maxHealth) {
				entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
				this.health += 2;
				if(this.health > this.maxHealth) {
					this.health = this.maxHealth;
				}

				return true;
			} else if(itemstack == null && this.followplayer) {
				this.followplayer = false;
				return true;
			} else {
				return false;
			}
		} else {
			entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
			this.timeUntilBirth = 0;
			this.health = this.maxHealth;
			return true;
		}
	}

	protected int getDropItemId() {
		return this.fire > 0 ? Item.porkCooked.shiftedIndex : Item.porkRaw.shiftedIndex;
	}

	public boolean getSaddled() {
		return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
	}

	public void setSaddled(boolean flag) {
		if(flag) {
			this.dataWatcher.updateObject(16, (byte)1);
		} else {
			this.dataWatcher.updateObject(16, (byte)0);
		}

	}

	public void onStruckByLightning(EntityLightningBolt entitylightningbolt) {
		this.struckByLightning = true;
		EntityPigZombie entitypigzombie = new EntityPigZombie(this.worldObj);
		entitypigzombie.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
		this.worldObj.entityJoinedWorld(entitypigzombie);
		this.setEntityDead();
	}

	protected void fall(float f) {
		super.fall(f);
		if(f > 5.0F && this.riddenByEntity instanceof EntityPlayer) {
			((EntityPlayer)this.riddenByEntity).triggerAchievement(AchievementList.flyPig);
		}

	}
}
