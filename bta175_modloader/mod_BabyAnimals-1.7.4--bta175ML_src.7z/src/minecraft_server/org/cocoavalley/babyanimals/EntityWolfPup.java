package org.cocoavalley.babyanimals;

import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.ItemFood;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_BabyAnimals;

public class EntityWolfPup extends EntityWolf {
	private boolean isWolfShaking;
	private boolean field_25052_g;
	public boolean isOwned;
	public boolean growUp;
	public int maxHealth;
	public boolean newPup;
	public boolean isDown;
	public boolean followplayerclose;

	public EntityWolfPup(World world) {
		super(world);
		this.texture = "/BabyAnimals/wolfpup.png";
		this.setSize(0.5F, 0.5F);
		this.moveSpeed = 1.0F;
		this.health = 8;
		this.maxHealth = this.health;
		this.growUp = false;
	}

	protected boolean canTriggerWalking() {
		return false;
	}

	protected String getLivingSound() {
		return this.getIsAngry() ? "pup_bark" : (this.rand.nextInt(3) == 0 ? (this.func_25030_y() && this.health < 10 ? "pup_whine" : "mob.wolf.panting") : "pup_bark");
	}

	protected String getHurtSound() {
		return "pup_hurt";
	}

	protected String getDeathSound() {
		return "pup_death";
	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		if(this.newPup) {
			this.setIsTamed(true);
			this.setPathToEntity((PathEntity)null);
			this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)7);
			this.health = 20;
			this.maxHealth = this.health;
			this.newPup = false;
		}

		if(this.func_25021_O() && !this.getGotPath() && !this.getIsAngry()) {
			Entity s = this.getCurrentTarget();
			if(s instanceof EntityPlayer) {
				EntityPlayer entitytamewolf = (EntityPlayer)s;
				ItemStack i = entitytamewolf.inventory.getCurrentItem();
				if(i != null) {
					if(!this.func_25030_y() && i.itemID == Item.bone.shiftedIndex) {
					} else if(this.func_25030_y() && Item.itemsList[i.itemID] instanceof ItemFood) {
						((ItemFood)Item.itemsList[i.itemID]).func_25010_k();
					}
				}

				if(entitytamewolf.func_22057_E()) {
					this.setIsSitting(true);
					this.isJumping = false;
					this.setPathToEntity((PathEntity)null);
				}
			}
		}

		if(!this.isMultiplayerEntity && this.isWolfShaking && !this.field_25052_g && !this.getGotPath()) {
			this.field_25052_g = true;
			this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)8);
		}

		if(!this.worldObj.singleplayerWorld && this.growUp) {
			String string10 = this.getOwner();
			this.lastTickPosX = this.posX;
			this.lastTickPosY = this.posY;
			this.lastTickPosZ = this.posZ;
			EntityTameWolf entityTameWolf11 = new EntityTameWolf(this.worldObj);
			entityTameWolf11.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0F);
			entityTameWolf11.setOwner(string10);

			for(int i12 = 0; i12 < 20; ++i12) {
				double d = this.rand.nextGaussian() * 0.02D;
				double d1 = this.rand.nextGaussian() * 0.02D;
				double d2 = this.rand.nextGaussian() * 0.02D;
				this.worldObj.spawnParticle("explode", this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
			}

			this.worldObj.entityJoinedWorld(entityTameWolf11);
			this.setEntityDead();
		}

	}

	protected void attackEntity(Entity entity, float f) {
		if(!this.func_25030_y() || !(entity instanceof EntityPlayer)) {
			if(f > 2.0F && f < 6.0F && this.rand.nextInt(10) == 0) {
				if(this.onGround) {
					double byte01 = entity.posX - this.posX;
					double d1 = entity.posZ - this.posZ;
					float f1 = MathHelper.sqrt_double(byte01 * byte01 + d1 * d1);
					this.motionX = byte01 / (double)f1 * 0.5D * (double)0.8F + this.motionX * (double)0.2F;
					this.motionZ = d1 / (double)f1 * 0.5D * (double)0.8F + this.motionZ * (double)0.2F;
					this.motionY = (double)0.4F;
				}
			} else if((double)f < 1.5D && entity.boundingBox.maxY > this.boundingBox.minY && entity.boundingBox.minY < this.boundingBox.maxY) {
				this.attackTime = 20;
				byte byte0 = 1;
				if(this.func_25030_y()) {
					byte0 = 2;
				}

				entity.attackEntityFrom(this, byte0);
			}

		}
	}

	public boolean interact(EntityPlayer entityplayer) {
		ItemStack itemstack = entityplayer.inventory.getCurrentItem();
		if(!this.func_25030_y()) {
			if(itemstack != null && itemstack.itemID == Item.bone.shiftedIndex && !this.getIsAngry()) {
				--itemstack.stackSize;
				if(itemstack.stackSize <= 0) {
					entityplayer.inventory.setInventorySlotContents(entityplayer.inventory.currentItem, (ItemStack)null);
				}

				if(!this.worldObj.singleplayerWorld) {
					if(this.rand.nextInt(3) == 0) {
						this.setIsTamed(true);
						this.setPathToEntity((PathEntity)null);
						this.setIsSitting(true);
						this.health = 20;
						this.maxHealth = this.health;
						this.setOwner(entityplayer.username);
						this.showHeartsOrSmokeFXPup(true);
						this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)7);
					} else {
						this.showHeartsOrSmokeFXPup(false);
						this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)6);
					}
				}

				return true;
			}
		} else {
			if(itemstack != null && Item.itemsList[itemstack.itemID] instanceof ItemFood) {
				ItemFood itemfood = (ItemFood)Item.itemsList[itemstack.itemID];
				if(itemfood.func_25010_k() && this.dataWatcher.getWatchableObjectInteger(18) < 20) {
					--itemstack.stackSize;
					if(itemstack.stackSize <= 0) {
						entityplayer.inventory.setInventorySlotContents(entityplayer.inventory.currentItem, (ItemStack)null);
					}

					this.heal(((ItemFood)Item.porkRaw).getHealAmount());
					return true;
				}
			} else {
				if(itemstack != null && itemstack.itemID == mod_BabyAnimals.ropeLasso.shiftedIndex) {
					if(!this.followplayerclose) {
						if(this.getIsSitting()) {
							this.setIsSitting(false);
						}

						this.followplayerclose = true;
						this.playerToAttack = entityplayer;
					} else {
						if(!this.followplayerclose) {
							return false;
						}

						this.followplayerclose = false;
						this.playerToAttack = null;
					}

					return true;
				}

				if(itemstack != null && (itemstack.itemID == Item.dyePowder.shiftedIndex && itemstack.getItemDamage() == 2 || itemstack.itemID == Block.cactus.blockID)) {
					entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
					if(this.health > 1) {
						this.health /= 2;
					}

					this.maxHealth /= 2;
					this.setIsSitting(false);
					this.setIsTamed(false);
					this.worldObj.sendTrackedEntityStatusUpdatePacket(this, (byte)6);
					return true;
				}

				if(itemstack != null && itemstack.itemID == Item.lightStoneDust.shiftedIndex && this.dataWatcher.getWatchableObjectInteger(18) < 20) {
					entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
					this.heal(this.maxHealth);
					return true;
				}

				if(itemstack != null && (itemstack.itemID == Item.cake.shiftedIndex || itemstack.itemID == Block.cake.blockID)) {
					entityplayer.inventory.decrStackSize(entityplayer.inventory.currentItem, 1);
					this.growUp = true;
					return true;
				}
			}

			if(entityplayer.username.equals(this.getOwner())) {
				if(!this.worldObj.singleplayerWorld) {
					this.setIsSitting(!this.getIsSitting());
					this.isJumping = false;
					this.setPathToEntity((PathEntity)null);
				}

				return true;
			}
		}

		return false;
	}
	
	private void showHeartsOrSmokeFXPup(boolean flag) {
		String s = "heart";
		if(!flag) {
			s = "smoke";
		}

		for(int i = 0; i < 7; ++i) {
			double d = this.rand.nextGaussian() * 0.02D;
			double d1 = this.rand.nextGaussian() * 0.02D;
			double d2 = this.rand.nextGaussian() * 0.02D;
			this.worldObj.spawnParticle(s, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + 0.5D + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d, d1, d2);
		}

	}
}
