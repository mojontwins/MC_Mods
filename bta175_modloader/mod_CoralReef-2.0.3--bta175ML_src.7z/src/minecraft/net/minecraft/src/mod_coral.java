package net.minecraft.src;

import java.util.Random;

import org.nandonalt.coralreef.BlockCoral;
import org.nandonalt.coralreef.BlockCoral2;
import org.nandonalt.coralreef.ItemCoral;
import org.nandonalt.coralreef.WorldGen_Reef;
import org.nandonalt.coralreef.WorldGen_Reef2;

public class mod_coral extends BaseMod {
	@MLProp(name="spiky", info="Enable spiky coral")
	public boolean spiky = true;
	
	@MLProp(name="size", info="Coral reef sizes, 0 small 1 normal 2 big", min=0, max=3)
	public int size = 1;
	
	@MLProp(name="bubble", info="Corals make bubbles")
	public static boolean bubble = true;
	
	@MLProp(name="grow", info="Reefs grow")
	public static boolean grow = false;
	
	@MLProp(name="blockCoral1ID")
	public static int blockCoral1ID = 154;
	
	@MLProp(name="blockCoral2ID")
	public static int blockCoral2ID = 155;
	
	@MLProp(name="blockCoral3ID")
	public static int blockCoral3ID = 156;
	
	@MLProp(name="blockCoral4ID")
	public static int blockCoral4ID = 157;
	
	@MLProp(name="blockCoral5ID")
	public static int blockCoral5ID = 158;
	
	public int min1;
	public int min2;
	public int max1;
	public int max2;
	public static int Sprite_coral1 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_coral1.png");
	public static int Sprite_coral2 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_coral2.png");
	public static int Sprite_coral3 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_coral3.png");
	public static int Sprite_coral4 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_coral4.png");
	public static int Sprite_coral5 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_coral5.png");
	public static int Sprite_coral6 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_coral6.png");
	public static int Sprite_coralr1 = ModLoader.addOverride("/terrain.png", "/CoralMod/block_reef2.png");
	public static Block Coral5 = (new BlockCoral(blockCoral5ID, 6, Sprite_coral1, Sprite_coral2, Sprite_coral3, Sprite_coral4, Sprite_coral5, Sprite_coral6)).setHardness(0.2F).setStepSound(Block.soundStoneFootstep).setLightValue(1.0F).setBlockName("CoralLightt");
	public static Block Coral4 = (new BlockCoral(blockCoral4ID, 6, Sprite_coral1, Sprite_coral2, Sprite_coral3, Sprite_coral4, Sprite_coral5, Sprite_coral6)).setHardness(0.2F).setStepSound(Block.soundStoneFootstep).setBlockName("Coral4");
	public static Block Coral1 = (new BlockCoral(blockCoral1ID, 1, Sprite_coral1, Sprite_coral2, Sprite_coral3, Sprite_coral4, Sprite_coral5, Sprite_coral6)).setHardness(0.2F).setStepSound(Block.soundStoneFootstep).setBlockName("Coral1");
	public static Block Coral2 = (new BlockCoral2(blockCoral2ID, ModLoader.addOverride("/terrain.png", "/CoralMod/block_reef.png"))).setHardness(0.5F).setStepSound(Block.soundStoneFootstep).setBlockName("Coral2");
	public static Block Coral3 = (new BlockCoral2(blockCoral3ID, Sprite_coralr1)).setHardness(0.5F).setStepSound(Block.soundStoneFootstep).setBlockName("Coral3");

	public mod_coral() {

		ModLoader.RegisterBlock(Coral1, ItemCoral.class);
		ModLoader.RegisterBlock(Coral2);
		ModLoader.RegisterBlock(Coral3);
		ModLoader.RegisterBlock(Coral4, ItemCoral.class);
		ModLoader.RegisterBlock(Coral5, ItemCoral.class);
		ModLoader.AddName(Coral2, "Sea Coral");
		ModLoader.AddName(Coral3, "Dry Coral");
		ModLoader.AddName(Coral1, "Coral");
		ModLoader.AddName(Coral4, "Coral");
		ModLoader.AddName(Coral5, "Coral");
		this.AddRecipes();
	}

	public String Version() {
		return "BTA 1.7.5_01 - By Nandonalt";
	}

	public void GenerateSurface(World paramdn, Random paramRandom, int paramInt1, int paramInt2) {
		switch(size) {
		case 0:
			this.min1 = 15;
			this.min2 = 10;
			this.max1 = 40;
			this.max2 = 20;
			break;
		default:
			this.min1 = 35;
			this.min2 = 25;
			this.max1 = 60;
			this.max2 = 35;
			break;
		case 2:
			this.min1 = 45;
			this.min2 = 30;
			this.max1 = 70;
			this.max2 = 45;
			break;
		}

		int i;
		int j;
		int k;
		int m;
		int numberReef;
		for(i = 0; i < 80; ++i) {
			j = paramInt1 + paramRandom.nextInt(16);
			k = paramRandom.nextInt(128);
			m = paramInt2 + paramRandom.nextInt(16);
			numberReef = paramRandom.nextInt(this.max1 - this.min1 + 1) + this.min1;
			(new WorldGen_Reef(numberReef, Coral2.blockID, spiky)).generate(paramdn, paramRandom, j, k, m);
		}

		for(i = 0; i < 80; ++i) {
			j = paramInt1 + paramRandom.nextInt(16);
			k = paramRandom.nextInt(128);
			m = paramInt2 + paramRandom.nextInt(16);
			numberReef = paramRandom.nextInt(this.max2 - this.min2 + 1) + this.min2;
			(new WorldGen_Reef2(numberReef, Coral3.blockID)).generate(paramdn, paramRandom, j, k, m);
		}

	}

	public void AddRecipes() {
		Item dye = Item.dyePowder;
		ModLoader.AddRecipe(new ItemStack(dye, 1, 14), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 0)});
		ModLoader.AddRecipe(new ItemStack(dye, 1, 10), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 1)});
		ModLoader.AddRecipe(new ItemStack(dye, 1, 13), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 2)});
		ModLoader.AddRecipe(new ItemStack(dye, 1, 9), new Object[]{"B", 'B', new ItemStack(Coral4, 1, 3)});
		ModLoader.AddRecipe(new ItemStack(dye, 1, 3), new Object[]{"B", 'B', new ItemStack(Coral1, 1, 4)});
		ModLoader.AddRecipe(new ItemStack(dye, 1, 6), new Object[]{"B", 'B', new ItemStack(Coral5, 1, 5)});
	}
}
