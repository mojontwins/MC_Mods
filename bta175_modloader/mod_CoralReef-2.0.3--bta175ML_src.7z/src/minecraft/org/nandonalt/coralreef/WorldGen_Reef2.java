package org.nandonalt.coralreef;

import java.util.Random;

import net.minecraft.src.Block;
import net.minecraft.src.MathHelper;
import net.minecraft.src.World;
import net.minecraft.src.WorldGenerator;
import net.minecraft.src.mod_coral;

public class WorldGen_Reef2 extends WorldGenerator {
	private int coralID;
	private int numberOfBlocks;

	public WorldGen_Reef2(int paramInt, int coralID) {
		this.coralID = coralID;
		this.numberOfBlocks = paramInt;
	}

	@Override
	public boolean generate(World paramdn, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
		float f = paramRandom.nextFloat() * 3.141593F;
		double d1 = (double)((float)(paramInt1 + 8) + MathHelper.sin(f) * (float)this.numberOfBlocks / 8.0F);
		double d2 = (double)((float)(paramInt1 + 8) - MathHelper.sin(f) * (float)this.numberOfBlocks / 8.0F);
		double d3 = (double)((float)(paramInt3 + 8) + MathHelper.cos(f) * (float)this.numberOfBlocks / 8.0F);
		double d4 = (double)((float)(paramInt3 + 8) - MathHelper.cos(f) * (float)this.numberOfBlocks / 8.0F);
		double d5 = (double)(paramInt2 + paramRandom.nextInt(3) + 2);
		double d6 = (double)(paramInt2 + paramRandom.nextInt(3) + 2);

		for(int i = 0; i <= this.numberOfBlocks; ++i) {
			double d7 = d1 + (d2 - d1) * (double)i / (double)this.numberOfBlocks;
			double d8 = d5 + (d6 - d5) * (double)i / (double)this.numberOfBlocks;
			double d9 = d3 + (d4 - d3) * (double)i / (double)this.numberOfBlocks;
			double d10 = paramRandom.nextDouble() * (double)this.numberOfBlocks / 16.0D;
			double d11 = (double)(MathHelper.sin((float)i * 3.141593F / (float)this.numberOfBlocks) + 1.0F) * d10 + 1.0D;
			double d12 = (double)(MathHelper.sin((float)i * 3.141593F / (float)this.numberOfBlocks) + 1.0F) * d10 + 1.0D;

			for(int j = (int)(d7 - d11 / 2.0D); j <= (int)(d7 + d11 / 2.0D); ++j) {
				for(int k = (int)(d8 - d12 / 2.0D); k <= (int)(d8 + d12 / 2.0D); ++k) {
					for(int m = (int)(d9 - d11 / 2.0D); m <= (int)(d9 + d11 / 2.0D); ++m) {
						double d13 = ((double)j + 0.5D - d7) / (d11 / 2.0D);
						double d14 = ((double)k + 0.5D - d8) / (d12 / 2.0D);
						double d15 = ((double)m + 0.5D - d9) / (d11 / 2.0D);
						if(d13 * d13 + d14 * d14 + d15 * d15 < 1.0D && (paramdn.getBlockId(j, k, m) == mod_coral.Coral2.blockID || paramdn.getBlockId(j, k, m) == mod_coral.Coral2.blockID) && (paramdn.getBlockId(j, k + 1, m) == Block.waterStill.blockID || paramdn.getBlockId(j, k + 1, m) == Block.waterMoving.blockID) && (paramdn.getBlockId(j, k + 2, m) == Block.waterStill.blockID || paramdn.getBlockId(j, k + 2, m) == Block.waterMoving.blockID) && (paramdn.getBlockId(j, k + 3, m) == Block.waterStill.blockID || paramdn.getBlockId(j, k + 3, m) == Block.waterMoving.blockID) && (paramdn.getBlockId(j, k + 4, m) == Block.waterStill.blockID || paramdn.getBlockId(j, k + 4, m) == Block.waterMoving.blockID)) {
							paramdn.setBlockWithNotify(j, k, m, this.coralID);
							paramdn.setBlockWithNotify(j + 1, k, m, this.coralID);
							paramdn.setBlockWithNotify(j, k, m + 1, this.coralID);
							paramdn.setBlockWithNotify(j + 1, k, m + 1, this.coralID);
							paramdn.setBlockWithNotify(j, k + paramRandom.nextInt(2), m, this.coralID);
							paramdn.setBlockWithNotify(j + 1, k + paramRandom.nextInt(2), m, this.coralID);
							paramdn.setBlockWithNotify(j, k + paramRandom.nextInt(2), m + 1, this.coralID);
							paramdn.setBlockWithNotify(j + 1, k + paramRandom.nextInt(2), m + 1, this.coralID);
						}
					}
				}
			}
		}

		return true;
	}
}
