package org.nandonalt.coralreef;

import java.util.Random;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityWaterMob;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_coral;

public class BlockCoral extends Block {
	public int sprite;
	public int sprite2;
	public int sprite3;
	public int sprite4;
	public int sprite5;
	public int sprite6;
	public int type;
	public int ia;
	public int id;

	public BlockCoral(int paramInt1, int type, int sprite1, int sprite2, int sprite3, int sprite4, int sprite5, int sprite6) {
		super(paramInt1, Material.water);
		this.blockIndexInTexture = sprite1;
		this.sprite2 = sprite2;
		this.sprite3 = sprite3;
		this.sprite4 = sprite4;
		this.sprite5 = sprite5;
		this.sprite6 = sprite6;
		this.type = type;
		float f;
		if(type == 1) {
			f = 0.375F;
			this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 1.0F, 0.5F + f);
		} else if(type == 6) {
			f = 0.5F;
			this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
		}

		this.setTickOnLoad(true);
	}

	@Override
	public void updateTick(World paramfb, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
		if(mod_coral.grow) {
			super.updateTick(paramfb, paramInt1, paramInt2, paramInt3, paramRandom);
			int i = paramfb.getBlockMetadata(paramInt1, paramInt2, paramInt3);
			if(i == 1 || i == 4) {
				int lp;
				for(lp = 1; paramfb.getBlockId(paramInt1, paramInt2 - lp, paramInt3) == this.blockID; ++lp) {
				}

				int rand = paramRandom.nextInt(100);
				if(rand == 0 && (paramfb.getBlockId(paramInt1, paramInt2 + 1, paramInt3) == 8 || paramfb.getBlockId(paramInt1, paramInt2 + 1, paramInt3) == 9) && (paramfb.getBlockId(paramInt1, paramInt2 + 2, paramInt3) == 8 || paramfb.getBlockId(paramInt1, paramInt2 + 2, paramInt3) == 9) && lp < 4) {
					paramfb.setBlockAndMetadataWithNotify(paramInt1, paramInt2 + 1, paramInt3, this.blockID, i);
				}
			}
		}

	}

	@Override
	public void randomDisplayTick(World world, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
		if(mod_coral.bubble) {
			Random rand = world.rand;
			double d1 = 0.0625D;

			for(int i = 0; i < 6; ++i) {
				double d2 = (double)((float)paramInt1 + rand.nextFloat());
				double d3 = (double)((float)paramInt2 + rand.nextFloat());
				double d4 = (double)((float)paramInt3 + rand.nextFloat());
				if(i == 0 && !world.isBlockOpaqueCube(paramInt1, paramInt2 + 1, paramInt3)) {
					d3 = (double)(paramInt2 + 1) + d1;
				}

				if(i == 1 && !world.isBlockOpaqueCube(paramInt1, paramInt2 - 1, paramInt3)) {
					d3 = (double)(paramInt2 + 0) - d1;
				}

				if(i == 2 && !world.isBlockOpaqueCube(paramInt1, paramInt2, paramInt3 + 1)) {
					d4 = (double)(paramInt3 + 1) + d1;
				}

				if(i == 3 && !world.isBlockOpaqueCube(paramInt1, paramInt2, paramInt3 - 1)) {
					d4 = (double)(paramInt3 + 0) - d1;
				}

				if(i == 4 && !world.isBlockOpaqueCube(paramInt1 + 1, paramInt2, paramInt3)) {
					d2 = (double)(paramInt1 + 1) + d1;
				}

				if(i == 5 && !world.isBlockOpaqueCube(paramInt1 - 1, paramInt2, paramInt3)) {
					d2 = (double)(paramInt1 + 0) - d1;
				}

				if(d2 < (double)paramInt1 || d2 > (double)(paramInt1 + 1) || d3 < 0.0D || d3 > (double)(paramInt2 + 1) || d4 < (double)paramInt3 || d4 > (double)(paramInt3 + 1)) {
					world.spawnParticle("bubble", d2, d3, d4, 0.0D, 0.0D, 0.0D);
				}
			}
		}

	}

	@Override
	protected int damageDropped(int paramInt) {
		return paramInt;
	}

	@Override
	public int idDropped(int paramInt, Random paramRandom) {
		return this.blockID;
	}

	@Override
	public int quantityDropped(int meta, Random paramRandom) {
		return 1;
	}

	@Override
	public boolean canPlaceBlockAt(World paramdn, int paramInt1, int paramInt2, int paramInt3) {
		paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3);
		paramdn.getBlockMetadata(paramInt1, paramInt2 - 1, paramInt3);
		paramdn.getBlockMetadata(paramInt1, paramInt2 + 1, paramInt3);
		int i3 = paramdn.getBlockMetadata(paramInt1, paramInt2, paramInt3);
		return i3 == 1 && (paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral1.blockID && paramdn.getBlockMetadata(paramInt1, paramInt2 - 1, paramInt3) == 1 || paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral2.blockID || paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral3.blockID) ? true : (i3 == 4 && (paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral1.blockID && paramdn.getBlockMetadata(paramInt1, paramInt2 - 1, paramInt3) == 4 || paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral2.blockID || paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral3.blockID) ? true : (paramdn.getBlockId(paramInt1, paramInt2 + 1, paramInt3) == 8 && (paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral2.blockID || paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral3.blockID) ? true : paramdn.getBlockId(paramInt1, paramInt2 + 1, paramInt3) == 9 && (paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral2.blockID || paramdn.getBlockId(paramInt1, paramInt2 - 1, paramInt3) == mod_coral.Coral3.blockID)));
	}

	@Override
	public int getBlockTextureFromSideAndMetadata(int paramInt1, int paramInt2) {
		if(paramInt2 == 0 || paramInt2 > 5) {
			this.sprite = this.blockIndexInTexture;
		}

		if(paramInt2 == 1) {
			this.sprite = this.sprite2;
		}

		if(paramInt2 == 2) {
			this.sprite = this.sprite3;
		}

		if(paramInt2 == 3) {
			this.sprite = this.sprite4;
		}

		if(paramInt2 == 4) {
			this.sprite = this.sprite5;
		}

		if(paramInt2 == 5) {
			this.sprite = this.sprite6;
		}

		return this.sprite;
	}

	@Override
	public boolean renderAsNormalBlock() {
		return false;
	}

	@Override
	public boolean isOpaqueCube() {
		return false;
	}

	@Override
	public int getRenderType() {
		return this.type;
	}

	@Override
	public boolean canBlockStay(World paramfb, int paramInt1, int paramInt2, int paramInt3) {
		return this.canPlaceBlockAt(paramfb, paramInt1, paramInt2, paramInt3);
	}

	@Override
	public void onNeighborBlockChange(World paramdt, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
		if(!this.canBlockStay(paramdt, paramInt1, paramInt2, paramInt3)) {
			this.dropBlockAsItem(paramdt, paramInt1, paramInt2, paramInt3, paramdt.getBlockMetadata(paramInt1, paramInt2, paramInt3));
			paramdt.setBlockWithNotify(paramInt1, paramInt2, paramInt3, 0);
		}

	}

	@Override
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World paramdt, int paramInt1, int paramInt2, int paramInt3) {
		return null;
	}

	@Override
	public void onEntityCollidedWithBlock(World paramdn, int paramInt1, int paramInt2, int paramInt3, Entity paramnl) {
		int i2 = paramdn.getBlockMetadata(paramInt1, paramInt2, paramInt3);
		if(!(paramnl instanceof EntityWaterMob) && i2 == 4) {
			paramnl.attackEntityFrom(paramnl, 2);
		}

	}
}
