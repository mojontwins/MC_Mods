package org.nandonalt.coralreef;

import net.minecraft.src.Block;
import net.minecraft.src.ItemBlock;

public class ItemCoral extends ItemBlock {
	public ItemCoral(int paramInt) {
		super(paramInt);
		this.setMaxDamage(0);
		this.setHasSubtypes(true);
	}

	public int getIconFromDamage(int i) {
		return Block.blocksList[this.shiftedIndex].getBlockTextureFromSideAndMetadata(2, i);
	}

	public int getPlacedBlockMetadata(int paramInt) {
		return paramInt;
	}
}
