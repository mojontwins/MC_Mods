package org.nandonalt.coralreef;

import net.minecraft.src.Block;
import net.minecraft.src.Material;

public class BlockCoral2 extends Block {
	public BlockCoral2(int paramInt1, int type) {
		super(paramInt1, Material.water);
		this.blockIndexInTexture = type;
	}
}
