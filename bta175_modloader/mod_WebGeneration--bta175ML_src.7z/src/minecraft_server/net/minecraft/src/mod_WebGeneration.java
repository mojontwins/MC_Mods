package net.minecraft.src;

import java.util.Random;

public class mod_WebGeneration extends BaseMod {
	
	@MLProp(name="webSpawnChance", info="1 in N chances of spawning a cobweb per chunk.")
	public static int webSpawnChance = 1;

	public mod_WebGeneration() {

	}

	@Override
	public void GenerateSurface(World world, Random random, int i, int j) {
		if(webSpawnChance <= 1 || random.nextInt(webSpawnChance) == 0) {
			int x = i + random.nextInt(16) + 8;
			int y = random.nextInt(128);
			int z = j + random.nextInt(16) + 8;
			this.generateWeb(world, random, x, y, z);
		}
	}

	private void generateWeb(World world, Random random, int x, int y, int z) {
		for(int i = 0; i < 128; ++i) {
			int x2 = x + random.nextInt(8) - random.nextInt(8);
			int y2 = y + random.nextInt(4) - random.nextInt(4);
			int z2 = z + random.nextInt(8) - random.nextInt(8);
			if(world.getBlockLightValue(x2, y2, z2) < 9 && world.isAirBlock(x2, y2, z2) && this.getStoneFaces(world, x2, y2, z2) > 1) {
				world.setBlock(x2, y2, z2, Block.web.blockID);
			}
		}

	}

	private int getStoneFaces(World world, int x, int y, int z) {
		int c = 0;
		if(world.getBlockId(x + 1, y, z) == Block.stone.blockID) {
			++c;
		}

		if(world.getBlockId(x - 1, y, z) == Block.stone.blockID) {
			++c;
		}

		if(world.getBlockId(x, y, z + 1) == Block.stone.blockID) {
			++c;
		}

		if(world.getBlockId(x, y, z - 1) == Block.stone.blockID) {
			++c;
		}

		if(world.getBlockId(x, y + 1, z) == Block.stone.blockID) {
			++c;
		}

		if(world.getBlockId(x, y - 1, z) == Block.stone.blockID) {
			++c;
		}

		return c;
	}

	@Override
	public String Version() {
		return "1.7.3-DaftPVF";
	}
}

