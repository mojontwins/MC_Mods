package org.mojontwins.minecraft.scatteredfeatures;

import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.Tessellator;

public class RenderBlockTripWire {

	public static boolean renderWorldBlock(RenderBlocks rb, IBlockAccess world,
			int x, int y, int z, Block block) {
		Tessellator tessellator = Tessellator.instance;
		int tIdx = block.getBlockTextureFromSide(0);
		int meta = rb.blockAccess.getBlockMetadata(x, y, z);
		boolean var8 = (meta & 4) == 4;
		boolean var9 = (meta & 2) == 2;

		if (rb.overrideBlockTexture >= 0) {
			tIdx = rb.overrideBlockTexture;
		}

		tessellator.setBrightness(block.getMixedBrightnessForBlock(rb.blockAccess, x, y, z));
		float light = block.getBlockBrightness(rb.blockAccess, x, y, z) * 0.75F;
		tessellator.setColorOpaque_F(light, light, light);

		int tU = (tIdx & 15) << 4;
		int tV = tIdx & 240;
		double u1 = (tU / 256.0F);
		double u2 = ((tU + 16) / 256.0F);
		double v1 = ((tV + (var8 ? 2 : 0)) / 256.0F);
		double v2 = ((tV + (var8 ? 4 : 2)) / 256.0F);

		double bH = (var9 ? 3.5F : 1.5F) / 16.0D;
		boolean var23 = BlockTripWire.connected(rb.blockAccess, x, y, z, meta, 1);
		boolean var24 = BlockTripWire.connected(rb.blockAccess, x, y, z, meta, 3);
		boolean var25 = BlockTripWire.connected(rb.blockAccess, x, y, z, meta, 2);
		boolean var26 = BlockTripWire.connected(rb.blockAccess, x, y, z, meta, 0);
		double bW = 0.03125F;
		double e1 = 0.5F - bW / 2.0F;
		double e2 = e1 + bW;

		if (!var25 && !var24 && !var26 && !var23) {
			var25 = true;
			var26 = true;
		}

		if (var25) {
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.25D, u1, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.25D, u1, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z, u2, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z, u2, v1);
			tessellator.addVertexWithUV((x + e1), y + bH, z, u2, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z, u2, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.25D, u1, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.25D, u1, v1);
		}

		if (var25 || var26 && !var24 && !var23) {
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.5D, u1, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.5D, u1, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.25D, u2, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.25D, u2, v1);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.25D, u2, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.25D, u2, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.5D, u1, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.5D, u1, v1);
		}

		if (var26 || var25 && !var24 && !var23) {
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.75D, u1, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.75D, u1, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.5D, u2, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.5D, u2, v1);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.5D, u2, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.5D, u2, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.75D, u1, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.75D, u1, v1);
		}

		if (var26) {
			tessellator.addVertexWithUV((x + e1), y + bH, (z + 1), u1, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, (z + 1), u1, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.75D, u2, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.75D, u2, v1);
			tessellator.addVertexWithUV((x + e1), y + bH, z + 0.75D, u2, v1);
			tessellator.addVertexWithUV((x + e2), y + bH, z + 0.75D, u2, v2);
			tessellator.addVertexWithUV((x + e2), y + bH, (z + 1), u1, v2);
			tessellator.addVertexWithUV((x + e1), y + bH, (z + 1), u1, v1);
		}

		if (var23) {
			tessellator.addVertexWithUV(x, y + bH, (z + e2), u1, v2);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x, y + bH, (z + e2), u1, v2);
		}

		if (var23 || var24 && !var25 && !var26) {
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e2), u1, v2);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x + 0.25D, y + bH, (z + e2), u1, v2);
		}

		if (var24 || var23 && !var25 && !var26) {
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e2), u1, v2);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x + 0.5D, y + bH, (z + e2), u1, v2);
		}

		if (var24) {
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e2), u1, v2);
			tessellator.addVertexWithUV((x + 1), y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV((x + 1), y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e1), u1, v1);
			tessellator.addVertexWithUV((x + 1), y + bH, (z + e1), u2, v1);
			tessellator.addVertexWithUV((x + 1), y + bH, (z + e2), u2, v2);
			tessellator.addVertexWithUV(x + 0.75D, y + bH, (z + e2), u1, v2);
		}

		return true;
	}

}
