package org.mojontwins.minecraft.scatteredfeatures;

import java.util.Random;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Direction;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_ScatteredFeature;

public class BlockTripWireSource extends Block {
	public BlockTripWireSource(int par1, int textureID) {
		super(par1, textureID, Material.circuits);
		this.setTickRandomly(true);
	}

	/**
	 * Returns a bounding box from the pool of bounding boxes (this means this box
	 * can change after the pool has been cleared to be reused)
	 */
	@Override
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int par2, int par3, int par4) {
		return null;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether or
	 * not to render the shared face of two adjacent blocks and also whether the
	 * player can attach torches, redstone wire, etc to this block.
	 */
	@Override
	public boolean isOpaqueCube() {
		return false;
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	@Override
	public boolean renderAsNormalBlock() {
		return false;
	}

	/**
	 * The type of render function that is called for this block
	 */
	@Override
	public int getRenderType() {
		return mod_ScatteredFeature.tripWireSourceRenderType;
	}

	/**
	 * How many world ticks before ticking
	 */
	@Override
	public int tickRate() {
		return 10;
	}

	/**
	 * checks to see if you can place this block can be placed on that side of a
	 * block: BlockLever overrides
	 */
	@Override
	public boolean canPlaceBlockOnSide(World world, int x, int y, int z, int par5) {
		return par5 == 2 && world.isBlockNormalCube(x, y, z + 1) ? true
				: (par5 == 3 && world.isBlockNormalCube(x, y, z - 1) ? true
						: (par5 == 4 && world.isBlockNormalCube(x + 1, y, z) ? true
								: par5 == 5 && world.isBlockNormalCube(x - 1, y, z)));
	}

	/**
	 * Checks to see if its valid to put this block at the specified coordinates.
	 * Args: world, x, y, z
	 */
	@Override
	public boolean canPlaceBlockAt(World world, int x, int y, int z) {
		return world.isBlockNormalCube(x - 1, y, z) ? true
				: (world.isBlockNormalCube(x + 1, y, z) ? true
						: (world.isBlockNormalCube(x, y, z - 1) ? true
								: world.isBlockNormalCube(x, y, z + 1)));
	}

	/**
	 * called before onBlockPlacedBy by ItemBlock and ItemReed
	 */
	@Override
	public void onBlockPlaced(World world, int x, int y, int z, int par5) {
		byte var9 = 0;

		if (par5 == 2 && world.isBlockNormalCubeDefault(x, y, z + 1, true)) {
			var9 = 2;
		}

		if (par5 == 3 && world.isBlockNormalCubeDefault(x, y, z - 1, true)) {
			var9 = 0;
		}

		if (par5 == 4 && world.isBlockNormalCubeDefault(x + 1, y, z, true)) {
			var9 = 1;
		}

		if (par5 == 5 && world.isBlockNormalCubeDefault(x - 1, y, z, true)) {
			var9 = 3;
		}

		this.updateTripwireSource(world, x, y, z, this.blockID, var9, false, -1, 0);
	}

	/**
	 * Lets the block know when one of its neighbor changes. Doesn't know which
	 * neighbor changed (coordinates passed are their own) Args: x, y, z, neighbor
	 * blockID
	 */
	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, int par5) {
		if (par5 != this.blockID) {
			if (this.func_72144_l(world, x, y, z)) {
				int var6 = world.getBlockMetadata(x, y, z);
				int var7 = var6 & 3;
				boolean var8 = false;

				if (!world.isBlockNormalCube(x - 1, y, z) && var7 == 3) {
					var8 = true;
				}

				if (!world.isBlockNormalCube(x + 1, y, z) && var7 == 1) {
					var8 = true;
				}

				if (!world.isBlockNormalCube(x, y, z - 1) && var7 == 0) {
					var8 = true;
				}

				if (!world.isBlockNormalCube(x, y, z + 1) && var7 == 2) {
					var8 = true;
				}

				if (var8) {
					this.dropBlockAsItem(world, x, y, z, var6, 0);
					world.setBlockWithNotify(x, y, z, 0);
				}
			}
		}
	}

	public void updateTripwireSource(World world, int x, int y, int z, int par5, int par6, boolean par7, int par8,
			int par9) {
		int var10 = par6 & 3;
		boolean var11 = (par6 & 4) == 4;
		boolean var12 = (par6 & 8) == 8;
		boolean var13 = par5 == mod_ScatteredFeature.tripWireSource.blockID;
		boolean var14 = false;
		boolean var15 = !mod_ScatteredFeature.doesBlockHaveSolidTopSurface(world, x, y - 1, z);
		int var16 = Direction.offsetX[var10];
		int var17 = Direction.offsetZ[var10];
		int var18 = 0;
		int[] var19 = new int[42];
		int var20;
		int var21;
		int var22;
		int var23;
		int var24;

		for (var20 = 1; var20 < 42; ++var20) {
			var21 = x + var16 * var20;
			var22 = z + var17 * var20;
			var23 = world.getBlockId(var21, y, var22);

			if (var23 == mod_ScatteredFeature.tripWireSource.blockID) {
				var24 = world.getBlockMetadata(var21, y, var22);

				if ((var24 & 3) == Direction.footInvisibleFaceRemap[var10]) {
					var18 = var20;
				}

				break;
			}

			if (var23 != mod_ScatteredFeature.tripWire.blockID && var20 != par8) {
				var19[var20] = -1;
				var13 = false;
			} else {
				var24 = var20 == par8 ? par9 : world.getBlockMetadata(var21, y, var22);
				boolean var25 = (var24 & 8) != 8;
				boolean var26 = (var24 & 1) == 1;
				boolean var27 = (var24 & 2) == 2;
				var13 &= var27 == var15;
				var14 |= var25 && var26;
				var19[var20] = var24;

				if (var20 == par8) {
					world.scheduleBlockUpdate(x, y, z, par5, this.tickRate());
					var13 &= var25;
				}
			}
		}

		var13 &= var18 > 1;
		var14 &= var13;
		var20 = (var13 ? 4 : 0) | (var14 ? 8 : 0);
		par6 = var10 | var20;

		if (var18 > 0) {
			var21 = x + var16 * var18;
			var22 = z + var17 * var18;
			var23 = Direction.footInvisibleFaceRemap[var10];
			world.setBlockMetadataWithNotify(var21, y, var22, var23 | var20);
			this.notifyNeighborOfChange(world, var21, y, var22, var23);
			this.playSoundEffect(world, var21, y, var22, var13, var14, var11, var12);
		}

		this.playSoundEffect(world, x, y, z, var13, var14, var11, var12);

		if (par5 > 0) {
			world.setBlockMetadataWithNotify(x, y, z, par6);

			if (par7) {
				this.notifyNeighborOfChange(world, x, y, z, var10);
			}
		}

		if (var11 != var13) {
			for (var21 = 1; var21 < var18; ++var21) {
				var22 = x + var16 * var21;
				var23 = z + var17 * var21;
				var24 = var19[var21];

				if (var24 >= 0) {
					if (var13) {
						var24 |= 4;
					} else {
						var24 &= -5;
					}

					world.setBlockMetadataWithNotify(var22, y, var23, var24);
				}
			}
		}
	}

	/**
	 * Ticks the block if it's been scheduled
	 */
	public void updateTick(World world, int x, int y, int z, Random par5Random) {
		this.updateTripwireSource(world, x, y, z, this.blockID, world.getBlockMetadata(x, y, z), true,
				-1, 0);
	}

	/**
	 * only of the conditions are right
	 */
	private void playSoundEffect(World world, int x, int y, int z, boolean par5, boolean par6,
			boolean par7, boolean par8) {
		if (par6 && !par8) {
			world.playSoundEffect((double) x + 0.5D, (double) y + 0.1D, (double) z + 0.5D, "random.click",
					0.4F, 0.6F);
		} else if (!par6 && par8) {
			world.playSoundEffect((double) x + 0.5D, (double) y + 0.1D, (double) z + 0.5D, "random.click",
					0.4F, 0.5F);
		} else if (par5 && !par7) {
			world.playSoundEffect((double) x + 0.5D, (double) y + 0.1D, (double) z + 0.5D, "random.click",
					0.4F, 0.7F);
		} else if (!par5 && par7) {
			world.playSoundEffect((double) x + 0.5D, (double) y + 0.1D, (double) z + 0.5D, "random.bowhit",
					0.4F, 1.2F / (world.rand.nextFloat() * 0.2F + 0.9F));
		}
	}

	private void notifyNeighborOfChange(World world, int x, int y, int z, int par5) {
		world.notifyBlocksOfNeighborChange(x, y, z, this.blockID);

		if (par5 == 3) {
			world.notifyBlocksOfNeighborChange(x - 1, y, z, this.blockID);
		} else if (par5 == 1) {
			world.notifyBlocksOfNeighborChange(x + 1, y, z, this.blockID);
		} else if (par5 == 0) {
			world.notifyBlocksOfNeighborChange(x, y, z - 1, this.blockID);
		} else if (par5 == 2) {
			world.notifyBlocksOfNeighborChange(x, y, z + 1, this.blockID);
		}
	}

	private boolean func_72144_l(World world, int x, int y, int z) {
		if (!this.canPlaceBlockAt(world, x, y, z)) {
			this.dropBlockAsItem(world, x, y, z, world.getBlockMetadata(x, y, z), 0);
			world.setBlockWithNotify(x, y, z, 0);
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Updates the blocks bounds based on its current state. Args: world, x, y, z
	 */
	@Override
	public void setBlockBoundsBasedOnState(IBlockAccess par1IBlockAccess, int x, int y, int z) {
		int var5 = par1IBlockAccess.getBlockMetadata(x, y, z) & 3;
		float var6 = 0.1875F;

		if (var5 == 3) {
			this.setBlockBounds(0.0F, 0.2F, 0.5F - var6, var6 * 2.0F, 0.8F, 0.5F + var6);
		} else if (var5 == 1) {
			this.setBlockBounds(1.0F - var6 * 2.0F, 0.2F, 0.5F - var6, 1.0F, 0.8F, 0.5F + var6);
		} else if (var5 == 0) {
			this.setBlockBounds(0.5F - var6, 0.2F, 0.0F, 0.5F + var6, 0.8F, var6 * 2.0F);
		} else if (var5 == 2) {
			this.setBlockBounds(0.5F - var6, 0.2F, 1.0F - var6 * 2.0F, 0.5F + var6, 0.8F, 1.0F);
		}
	}

	/**
	 * ejects contained items into the world, and notifies neighbours of an update,
	 * as appropriate
	 */
	@Override
	public void onBlockRemoval(World world, int x, int y, int z) {
		// Changed, this needed the new onBlockRemoval that is passed id and meta, which is not in r1.2.5
		int meta = world.getBlockMetadata(x, y, z);
				
		boolean var7 = (meta & 4) == 4;
		boolean var8 = (meta & 8) == 8;

		if (var7 || var8) {
			this.updateTripwireSource(world, x, y, z, 0, meta, false, -1, 0);
		}

		if (var8) {
			world.notifyBlocksOfNeighborChange(x, y, z, this.blockID);
			int var9 = meta & 3;

			if (var9 == 3) {
				world.notifyBlocksOfNeighborChange(x - 1, y, z, this.blockID);
			} else if (var9 == 1) {
				world.notifyBlocksOfNeighborChange(x + 1, y, z, this.blockID);
			} else if (var9 == 0) {
				world.notifyBlocksOfNeighborChange(x, y, z - 1, this.blockID);
			} else if (var9 == 2) {
				world.notifyBlocksOfNeighborChange(x, y, z + 1, this.blockID);
			}
		}

		super.onBlockRemoval(world, x, y, z);
	}

	/**
	 * Is this block powering the block on the specified side
	 */
	@Override
	public boolean isPoweringTo(IBlockAccess par1IBlockAccess, int x, int y, int z, int par5) {
		return (par1IBlockAccess.getBlockMetadata(x, y, z) & 8) == 8;
	}

	/**
	 * Is this block indirectly powering the block on the specified side
	 */
	@Override
	public boolean isIndirectlyPoweringTo(World world, int x, int y, int z, int par5) {
		int var6 = world.getBlockMetadata(x, y, z);

		if ((var6 & 8) != 8) {
			return false;
		} else {
			int var7 = var6 & 3;
			return var7 == 2 && par5 == 2 ? true
					: (var7 == 0 && par5 == 3 ? true : (var7 == 1 && par5 == 4 ? true : var7 == 3 && par5 == 5));
		}
	}

	/**
	 * Can this block provide power. Only wire currently seems to have this change
	 * based on its state.
	 */
	@Override
	public boolean canProvidePower() {
		return true;
	}
}
