package net.minecraft.src;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import net.minecraft.server.MinecraftServer;

import org.mojontwins.minecraft.scatteredfeatures.BlockTripWire;
import org.mojontwins.minecraft.scatteredfeatures.BlockTripWireSource;
import org.mojontwins.minecraft.scatteredfeatures.MapGenHijackedMineshaft;

public class mod_ScatteredFeature extends BaseModMp {
	public static BlockTripWireSource tripWireSource;     
	public static Block tripWire; 
	public static Block stairsSandStone;
	
	@MLProp(name="tripWireSourceID", info="Block tripWireSource ID, default is 131")
	public static int tripWireSourceID = 131;
	@MLProp(name="tripWireID", info="Block tripWire ID, default is 132")
	public static int tripWireID = 132;
	@MLProp(name="stairsSandStoneID", info="Block stairsSandstone ID, default is 128")
	public static int stairsSandStoneID = 128;
	
	public static int tripWireSourceRenderType;
	public static int tripWireRenderType;
	
	// This is used to detect if the world is new and has to be hijacked
	private World currentWorld = null;
	
	// ** SERVER VERSION **

	public mod_ScatteredFeature() {
		// New blocks
		tripWireSource = (BlockTripWireSource) (new BlockTripWireSource(tripWireSourceID, ModLoader.addOverride("/terrain.png", "/org/mojontwins/minecraft/scatteredfeatures/tripwiresource.png")))
				.setBlockName("tripWireSource")
				.setRequiresSelfNotify();
		tripWire = new BlockTripWire(tripWireID, ModLoader.addOverride("/terrain.png", "/org/mojontwins/minecraft/scatteredfeatures/tripwire.png"))
				.setBlockName("tripWire")
				.setRequiresSelfNotify();
		stairsSandStone = new BlockStairs(stairsSandStoneID, Block.sandStone)
				.setBlockName("stairsSandStone")
				.setRequiresSelfNotify()
				.setLightOpacity(0);
	}

	@Override
	public String getVersion() {
		return "ScatteredFeature v1.0";
	}

	@Override
	public void load() {
		// Register blocks
		ModLoader.registerBlock(tripWireSource);
		tripWireSourceRenderType = ModLoader.getUniqueBlockModelID(this, false);
		
		ModLoader.registerBlock(tripWire);
		tripWireRenderType = ModLoader.getUniqueBlockModelID(this, false);
		
		ModLoader.registerBlock(stairsSandStone);
		
		// Recipe
		ModLoader.addRecipe(
				new ItemStack(tripWireSource, 2), 
				new Object[] {"I", "S", "#", '#', Block.planks, 'S', Item.stick, 'I', Item.ingotIron}
			);
		

		ModLoader.addRecipe(
				new ItemStack(stairsSandStone, 4), new Object[] {"#  ", "## ", "###", '#', Block.sandStone});
		
		ModLoader.setInGameHook(this, true, true);
		
		// Undefine vanilla silk
		Item.itemsList[256 + 31] = null; 
		
		// Update to 1.3.2 silk
		Item.silk = (new ItemReed(31, tripWire)).setIconCoord(8, 0).setItemName("string");
	}
	
	// Tick
	@Override
	public void onTickInGame(MinecraftServer mc) {
		
		// This may seem ugly... It is! But ModLoader doesn't have the hooks I need.
		// To generate vanilla structures, structure starts must be found during generation,
		// and then put into the world at the beginning population (just before decoration i.e. trees, etc).
		// ModLoader only has a hook right after chunk population. 
		// So I'm using reflection to change the vanilla mineshaft generator for a custom generator
		// which will call, in turn, the actual mineshaft generator and the new scattered feature generator.
		
		// Of course, this also has obfuscated names.
		if(this.currentWorld != mc.worldMngr[0]) {

			MinecraftServer.logger.info ("Attempting to hijack the chunk provider . . .");
			this.currentWorld = mc.worldMngr[0];
			
			try {
				if(this.currentWorld.chunkProvider instanceof ChunkProviderServer) {	
					ChunkProviderServer cp = (ChunkProviderServer)this.currentWorld.chunkProvider;
					
					Field cpgf = null;

					// Obfuscated ChunkProvider.chunkProvider is "d"
					try {
						cpgf = cp.getClass().getDeclaredField("d");	
					} catch (NoSuchFieldException e) {
						try {
							cpgf = cp.getClass().getDeclaredField("serverChunkGenerator");
						} catch (NoSuchFieldException e1) {
							MinecraftServer.logger.severe ("This should not happen, could not find serverChunkGenerator/d in reflection!");
							return;
						}
					}
					
					cpgf.setAccessible(true);			
					ChunkProviderGenerate cpg = (ChunkProviderGenerate) cpgf.get(cp); 
					MinecraftServer.logger.info("Hijacking " + cpg.getClass());
					
					Field mapGenF = null;
					
					// Obfuscated ChunkProviderGenerate.mineshaftGenerator is "w"
					try {
						mapGenF = cpg.getClass().getDeclaredField("w");
					} catch (NoSuchFieldException e) {
						try {
							mapGenF = cpg.getClass().getDeclaredField("mineshaftGenerator");
						} catch (NoSuchFieldException e1) {
							MinecraftServer.logger.severe ("This should not happen, could not find mineshaftGenerator/w in reflection!");
							return;
						}
					}

					mapGenF.setAccessible(true);
					mapGenF.set(cpg, new MapGenHijackedMineshaft());
					
					MinecraftServer.logger.info("Hijacked!");
				}
				
			} catch (Exception e) {
				e.printStackTrace ();
			}
		}
	}

	// Methods that are not in the r1.2.5 API
	
	public static boolean doesBlockHaveSolidTopSurface(IBlockAccess blockAccess, int x, int y, int z) {
        Block block = Block.blocksList[blockAccess.getBlockId(x, y, z)];
        return block == null ? 
        		false 
        	: 
        		(block.blockMaterial.isOpaque() && block.renderAsNormalBlock() ? 
        				true 
        			: 
        				(block instanceof BlockStairs ? 
        						(blockAccess.getBlockMetadata(x, y, z) & 4) == 4 
        					: 
        						(block instanceof BlockStep ? 
        								(blockAccess.getBlockMetadata(x, y, z) & 8) == 8 
        							: 
        								false)));
	}
	
}
