package net.minecraft.src;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.Properties;
import java.util.Random;

import net.minecraft.client.Minecraft;

import org.mojontwins.minecraft.scatteredfeatures.BlockTripWire;
import org.mojontwins.minecraft.scatteredfeatures.BlockTripWireSource;
import org.mojontwins.minecraft.scatteredfeatures.MapGenHijackedMineshaft;
import org.mojontwins.minecraft.scatteredfeatures.RenderBlockTripWire;
import org.mojontwins.minecraft.scatteredfeatures.RenderBlockTripWireSource;

public class mod_ScatteredFeature extends BaseModMp {
	public static BlockTripWireSource tripWireSource;     
	public static Block tripWire; 
	public static Block stairsSandStone;
	
	@MLProp(name="tripWireSourceID", info="Block tripWireSource ID, default is 131")
	public static int tripWireSourceID = 131;
	@MLProp(name="tripWireID", info="Block tripWire ID, default is 132")
	public static int tripWireID = 132;
	@MLProp(name="stairsSandStoneID", info="Block stairsSandstone ID, default is 128")
	public static int stairsSandStoneID = 128;
	
	public static int tripWireSourceRenderType;
	public static int tripWireRenderType;
	
	// This is used to detect if the world is new and has to be hijacked
	private World currentWorld = null;
	
	// ** CLIENT VERSION **

	public mod_ScatteredFeature() {
		// New blocks
		tripWireSource = (BlockTripWireSource) (new BlockTripWireSource(tripWireSourceID, ModLoader.addOverride("/terrain.png", "/org/mojontwins/minecraft/scatteredfeatures/tripwiresource.png")))
				.setBlockName("tripWireSource")
				.setRequiresSelfNotify();
		tripWire = new BlockTripWire(tripWireID, ModLoader.addOverride("/terrain.png", "/org/mojontwins/minecraft/scatteredfeatures/tripwire.png"))
				.setBlockName("tripWire")
				.setRequiresSelfNotify();
		stairsSandStone = new BlockStairs(stairsSandStoneID, Block.sandStone)
				.setBlockName("stairsSandStone")
				.setRequiresSelfNotify()
				.setLightOpacity(0);
	}

	@Override
	public String getVersion() {
		return "ScatteredFeature v1.0";
	}

	@Override
	public void load() {
		// Register blocks
		ModLoader.registerBlock(tripWireSource);
		ModLoader.addName(tripWireSource, "Tripwire Source");
		tripWireSourceRenderType = ModLoader.getUniqueBlockModelID(this, false);
		
		ModLoader.registerBlock(tripWire);
		ModLoader.addName(tripWire, "Tripwire");
		tripWireRenderType = ModLoader.getUniqueBlockModelID(this, false);
		
		ModLoader.registerBlock(stairsSandStone);
		ModLoader.addName(stairsSandStone, "StairsSandstone");
		
		// Recipe
		ModLoader.addRecipe(
				new ItemStack(tripWireSource, 2), 
				new Object[] {"I", "S", "#", '#', Block.planks, 'S', Item.stick, 'I', Item.ingotIron}
			);
		
		ModLoader.addRecipe(
				new ItemStack(stairsSandStone, 4), new Object[] {"#  ", "## ", "###", '#', Block.sandStone});
		
		ModLoader.setInGameHook(this, true, true);
		
		// Undefine vanilla silk
		Item.itemsList[256 + 31] = null; 
		
		// Update to 1.3.2 silk
		Item.silk = (new ItemReed(31, tripWire)).setIconCoord(8, 0).setItemName("string");
	}
	
	// Tick
	@Override
	public boolean onTickInGame(float partialTicks, Minecraft mc) {
		
		// This may seem ugly... It is! But ModLoader doesn't have the hooks I need.
		// To generate vanilla structures, structure starts must be found during generation,
		// and then put into the world at the beginning population (just before decoration i.e. trees, etc).
		// ModLoader only has a hook right after chunk population. 
		
		// So I'm using reflection to change the vanilla mineshaft generator for a custom generator
		// which will call, in turn, the actual mineshaft generator and the new scattered feature generator.

		// Of course, this also has obfuscated names.
		
		if(this.currentWorld != mc.theWorld) {

			System.out.println ("New world detected.");
			this.currentWorld = mc.theWorld;
			
			try {
				if(this.currentWorld.chunkProvider instanceof ChunkProvider) {
					ChunkProvider cp = (ChunkProvider)this.currentWorld.chunkProvider;
					
					Field cpgf = null;

					// Obfuscated ChunkProvider.chunkProvider is "c"
					try {
						cpgf = cp.getClass().getDeclaredField("c");	
					} catch (NoSuchFieldException e) {
						try {
							cpgf = cp.getClass().getDeclaredField("chunkProvider");
						} catch (NoSuchFieldException e1) {
							System.out.println ("This should not happen, could not find chunkProvider/c in reflection!");
							return false;
						}
					}
					
					cpgf.setAccessible(true);			
					ChunkProviderGenerate cpg = (ChunkProviderGenerate) cpgf.get(cp); 
					System.out.println("Hijacking " + cpg.getClass());
					
					Field mapGenF = null;
					
					// Obfuscated ChunkProviderGenerate.mineshaftGenerator is "w"
					try {
						mapGenF = cpg.getClass().getDeclaredField("w");
					} catch (NoSuchFieldException e) {
						try {
							mapGenF = cpg.getClass().getDeclaredField("mineshaftGenerator");
						} catch (NoSuchFieldException e1) {
							System.out.println ("This should not happen, could not find mineshaftGenerator/w in reflection!");
							return false;
						}
					}

					mapGenF.setAccessible(true);
					mapGenF.set(cpg, new MapGenHijackedMineshaft());
					
					System.out.println("Hijacked!");
				}
				
			} catch (Exception e) {
				e.printStackTrace ();
			}
		}
        return true;
    }
	
	// Implement custom renderers for new blocks
	
	@Override
	public void renderInvBlock(RenderBlocks rb, Block block, int meta, int renderType) {
		//
	}

	@Override
    public boolean renderWorldBlock(RenderBlocks rb, IBlockAccess world, int x, int y, int z, Block block, int renderType) {
		if (renderType == tripWireSourceRenderType) {
			return RenderBlockTripWireSource.renderWorldBlock(rb, world, x, y, z, block);
		} else if (renderType == tripWireRenderType) {
			return RenderBlockTripWire.renderWorldBlock(rb, world, x, y, z, block);
		} else {
			return false;
		}
    }

	// Methods that are not in the r1.2.5 API
	
	public static boolean doesBlockHaveSolidTopSurface(IBlockAccess blockAccess, int x, int y, int z) {
        Block block = Block.blocksList[blockAccess.getBlockId(x, y, z)];
        return block == null ? 
        		false 
        	: 
        		(block.blockMaterial.isOpaque() && block.renderAsNormalBlock() ? 
        				true 
        			: 
        				(block instanceof BlockStairs ? 
        						(blockAccess.getBlockMetadata(x, y, z) & 4) == 4 
        					: 
        						(block instanceof BlockStep ? 
        								(blockAccess.getBlockMetadata(x, y, z) & 8) == 8 
        							: 
        								false)));
	}
	
}
