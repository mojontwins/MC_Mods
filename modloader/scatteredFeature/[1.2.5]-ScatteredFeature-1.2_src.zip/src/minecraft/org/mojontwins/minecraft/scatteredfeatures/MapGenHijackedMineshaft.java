package org.mojontwins.minecraft.scatteredfeatures;

import java.util.Random;

import net.minecraft.src.IChunkProvider;
import net.minecraft.src.MapGenMineshaft;
import net.minecraft.src.World;

public class MapGenHijackedMineshaft extends MapGenMineshaft {
	public MapGenMineshaft mineshaftGen = new MapGenMineshaft();
	public MapGenScatteredFeature scatteredGen = new MapGenScatteredFeature();
	
	public MapGenHijackedMineshaft() {
	}

	@Override
	public void generate(IChunkProvider provider, World world, int chunkX, int chunkZ, byte[] blocks) {
		mineshaftGen.generate(provider, world, chunkX, chunkZ, blocks);
		scatteredGen.generate(provider, world, chunkX, chunkZ, blocks);
	}
	
	@Override
	public boolean generateStructuresInChunk(World world, Random rand, int chunkX, int chunkZ) {
		return mineshaftGen.generateStructuresInChunk(world, rand, chunkX, chunkZ) ||
				scatteredGen.generateStructuresInChunk(world, rand, chunkX, chunkZ);
	}
}
