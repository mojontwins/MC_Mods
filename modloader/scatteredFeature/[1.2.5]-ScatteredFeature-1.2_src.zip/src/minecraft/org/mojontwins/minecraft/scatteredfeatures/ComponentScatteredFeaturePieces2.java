package org.mojontwins.minecraft.scatteredfeatures;

class ComponentScatteredFeaturePieces2
{
}
