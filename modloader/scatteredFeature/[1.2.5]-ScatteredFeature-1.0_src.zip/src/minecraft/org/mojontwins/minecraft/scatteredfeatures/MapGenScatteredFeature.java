package org.mojontwins.minecraft.scatteredfeatures;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.MapGenStructure;
import net.minecraft.src.StructureStart;

public class MapGenScatteredFeature extends MapGenStructure {
	private static List<BiomeGenBase> biomelist = Arrays.asList(new BiomeGenBase[] { 
			BiomeGenBase.desert, 
			BiomeGenBase.desertHills,
			
			BiomeGenBase.jungle,
			BiomeGenBase.jungleHills,
		});

	protected boolean canSpawnStructureAtCoords(int chunkX, int chunkZ) {
		byte maxSpacing = 32;
		byte minSpacing = 8;
		int x = chunkX;
		int z = chunkZ;

		if (chunkX < 0) {
			chunkX -= maxSpacing - 1;
		}

		if (chunkZ < 0) {
			chunkZ -= maxSpacing - 1;
		}

		int xSpaced = chunkX / maxSpacing;
		int zSpaced = chunkZ / maxSpacing;
		Random structureRNG = this.worldObj.setRandomSeed(xSpaced, zSpaced, 14357617);
		xSpaced *= maxSpacing;
		zSpaced *= maxSpacing;
		xSpaced += structureRNG.nextInt(maxSpacing - minSpacing);
		zSpaced += structureRNG.nextInt(maxSpacing - minSpacing);

		if (x == xSpaced && z == zSpaced) {
			if(this.worldObj.getWorldChunkManager().areBiomesViable(
					x * 16 + 8, z * 16 + 8, 0,
					biomelist)) {

		        System.out.println ("Attempting scattered feature");
				return true;
			}
		}

		return false;
	}

	protected StructureStart getStructureStart(int chunkX, int chunkZ) {
		return new StructureScatteredFeatureStart(this.worldObj, this.rand, chunkX, chunkZ);
	}
}
