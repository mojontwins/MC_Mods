package org.mojontwins.minecraft.scatteredfeatures;

import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.Tessellator;
import net.minecraft.src.mod_ScatteredFeature;

public class RenderBlockTripWireSource {

	public static boolean renderWorldBlock(RenderBlocks rb, IBlockAccess world,
			int x, int y, int z, Block block) {
		Tessellator tes = Tessellator.instance;
		int meta = rb.blockAccess.getBlockMetadata(x, y, z);
		int orientation = meta & 3;
		boolean z8 = (meta & 4) == 4;
		boolean z9 = (meta & 8) == 8;
		boolean onSurface = !mod_ScatteredFeature.doesBlockHaveSolidTopSurface(rb.blockAccess, x, y - 1, z);
		boolean overrideTexture = rb.overrideBlockTexture >= 0;

		if (!overrideTexture) {
			rb.overrideBlockTexture = Block.planks.blockIndexInTexture;
		}

		float f12 = 0.25F;
		float f13 = 0.125F;
		float f14 = 0.125F;
		float f15 = 0.3F - f12;
		float f16 = 0.3F + f12;

		if (orientation == 2) {
			block.setBlockBounds(0.5F - f13, f15, 1.0F - f14, 0.5F + f13, f16, 1.0F);
		} else if (orientation == 0) {
			block.setBlockBounds(0.5F - f13, f15, 0.0F, 0.5F + f13, f16, f14);
		} else if (orientation == 1) {
			block.setBlockBounds(1.0F - f14, f15, 0.5F - f13, 1.0F, f16, 0.5F + f13);
		} else if (orientation == 3) {
			block.setBlockBounds(0.0F, f15, 0.5F - f13, f14, f16, 0.5F + f13);
		}

		rb.renderStandardBlock(block, x, y, z);

		if (!overrideTexture) {
			rb.overrideBlockTexture = -1;
		}

		tes.setBrightness(block.getMixedBrightnessForBlock(rb.blockAccess, x, y, z));
		float light = 1.0F;

		if (Block.lightValue[block.blockID] > 0) {
			light = 1.0F;
		}

		tes.setColorOpaque_F(light, light, light);
		int tIdx = block.getBlockTextureFromSide(0);

		if (rb.overrideBlockTexture >= 0) {
			tIdx = rb.overrideBlockTexture;
		}

		int tU = (tIdx & 15) << 4;
		int tV = tIdx & 0xff0; // 240;

		float u1 = (float) tU / 256.0F;
		float u2 = ((float) tU + 15.99F) / 256.0F;
		float v1 = (float) tV / 256.0F;
		float v2 = ((float) tV + 15.99F) / 256.0F;
		
		Vec3[] vec = new Vec3[8];
		float wX = 0.046875F;
		float wZ = 0.046875F;
		float wY = 0.3125F;
		vec[0] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), 0.0D, (double) (-wZ));
		vec[1] = Vec3.getVec3Pool().getVecFromPool((double) wX, 0.0D, (double) (-wZ));
		vec[2] = Vec3.getVec3Pool().getVecFromPool((double) wX, 0.0D, (double) wZ);
		vec[3] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), 0.0D, (double) wZ);
		vec[4] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), (double) wY, (double) (-wZ));
		vec[5] = Vec3.getVec3Pool().getVecFromPool((double) wX, (double) wY, (double) (-wZ));
		vec[6] = Vec3.getVec3Pool().getVecFromPool((double) wX, (double) wY, (double) wZ);
		vec[7] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), (double) wY, (double) wZ);

		for (int i = 0; i < 8; ++i) {
			vec[i].zCoord += 0.0625D;

			if (z9) {
				vec[i].rotateAroundX(0.5235988F);
				vec[i].yCoord -= 0.4375D;
			} else if (z8) {
				vec[i].rotateAroundX(0.08726647F);
				vec[i].yCoord -= 0.4375D;
			} else {
				vec[i].rotateAroundX(-((float) Math.PI * 2F / 9F));
				vec[i].yCoord -= 0.375D;
			}

			vec[i].rotateAroundX(((float) Math.PI / 2F));

			if (orientation == 2) {
				vec[i].rotateAroundY(0.0F);
			}

			if (orientation == 0) {
				vec[i].rotateAroundY((float) Math.PI);
			}

			if (orientation == 1) {
				vec[i].rotateAroundY(((float) Math.PI / 2F));
			}

			if (orientation == 3) {
				vec[i].rotateAroundY(-((float) Math.PI / 2F));
			}

			vec[i].xCoord += (double) x + 0.5D;
			vec[i].yCoord += (double) ((float) y + 0.3125F);
			vec[i].zCoord += (double) z + 0.5D;
		}

		Vec3 vec1 = null;
		Vec3 vec2 = null;
		Vec3 vec3 = null;
		Vec3 vec4 = null;
		byte tU1 = 7;
		byte tU2 = 9;
		byte tV1 = 9;
		byte tEdge = 16;

		for (int i = 0; i < 6; ++i) {
			if (i == 0) {
				vec1 = vec[0];
				vec2 = vec[1];
				vec3 = vec[2];
				vec4 = vec[3];

				// !
				u1 = (float) (tU + tU1) / 256F; // 256.0F;
				u2 = (float) (tU + tU2) / 256F; // 256.0F;
				v1 = (float) (tV + tV1) / 256F; // 256.0F;
				v2 = (float) (tV + tV1 + 2) / 256F; // 256.0F;
			} else if (i == 1) {
				vec1 = vec[7];
				vec2 = vec[6];
				vec3 = vec[5];
				vec4 = vec[4];
			} else if (i == 2) {
				vec1 = vec[1];
				vec2 = vec[0];
				vec3 = vec[4];
				vec4 = vec[5];

				// !
				u1 = (float) (tU + tU1) / 256F; // 256.0F;
				u2 = (float) (tU + tU2) / 256F; // 256.0F;
				v1 = (float) (tV + tV1) / 256F; // 256.0F;
				v2 = (float) (tV + tEdge) / 256F; // 256.0F;
			} else if (i == 3) {
				vec1 = vec[2];
				vec2 = vec[1];
				vec3 = vec[5];
				vec4 = vec[6];
			} else if (i == 4) {
				vec1 = vec[3];
				vec2 = vec[2];
				vec3 = vec[6];
				vec4 = vec[7];
			} else if (i == 5) {
				vec1 = vec[0];
				vec2 = vec[3];
				vec3 = vec[7];
				vec4 = vec[4];
			}

			tes.addVertexWithUV(vec1.xCoord, vec1.yCoord, vec1.zCoord, (double) u1, (double) v2);
			tes.addVertexWithUV(vec2.xCoord, vec2.yCoord, vec2.zCoord, (double) u2, (double) v2);
			tes.addVertexWithUV(vec3.xCoord, vec3.yCoord, vec3.zCoord, (double) u2, (double) v1);
			tes.addVertexWithUV(vec4.xCoord, vec4.yCoord, vec4.zCoord, (double) u1, (double) v1);
		}

		wX = 0.09375F;
		wZ = 0.09375F;
		wY = 0.03125F;
		vec[0] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), 0.0D, (double) (-wZ));
		vec[1] = Vec3.getVec3Pool().getVecFromPool((double) wX, 0.0D, (double) (-wZ));
		vec[2] = Vec3.getVec3Pool().getVecFromPool((double) wX, 0.0D, (double) wZ);
		vec[3] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), 0.0D, (double) wZ);
		vec[4] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), (double) wY, (double) (-wZ));
		vec[5] = Vec3.getVec3Pool().getVecFromPool((double) wX, (double) wY, (double) (-wZ));
		vec[6] = Vec3.getVec3Pool().getVecFromPool((double) wX, (double) wY, (double) wZ);
		vec[7] = Vec3.getVec3Pool().getVecFromPool((double) (-wX), (double) wY, (double) wZ);

		for (int i = 0; i < 8; ++i) {
			vec[i].zCoord += 0.21875D;

			if (z9) {
				vec[i].yCoord -= 0.09375D;
				vec[i].zCoord -= 0.1625D;
				vec[i].rotateAroundX(0.0F);
			} else if (z8) {
				vec[i].yCoord += 0.015625D;
				vec[i].zCoord -= 0.171875D;
				vec[i].rotateAroundX(0.17453294F);
			} else {
				vec[i].rotateAroundX(0.87266463F);
			}

			if (orientation == 2) {
				vec[i].rotateAroundY(0.0F);
			}

			if (orientation == 0) {
				vec[i].rotateAroundY((float) Math.PI);
			}

			if (orientation == 1) {
				vec[i].rotateAroundY(((float) Math.PI / 2F));
			}

			if (orientation == 3) {
				vec[i].rotateAroundY(-((float) Math.PI / 2F));
			}

			vec[i].xCoord += (double) x + 0.5D;
			vec[i].yCoord += (double) ((float) y + 0.3125F);
			vec[i].zCoord += (double) z + 0.5D;
		}

		tU1 = 5;
		tU2 = 11;
		tV1 = 3;
		int tV2 = 9;

		for (int i = 0; i < 6; ++i) {
			if (i == 0) {
				vec1 = vec[0];
				vec2 = vec[1];
				vec3 = vec[2];
				vec4 = vec[3];

				// !
				u1 = (float) (tU + tU1) / 256F; // 256.0F;
				u2 = (float) (tU + tU2) / 256F; // 256.0F;
				v1 = (float) (tV + tV1) / 256F; // 256.0F;
				v2 = (float) (tV + tV2) / 256F; // 256.0F;
			} else if (i == 1) {
				vec1 = vec[7];
				vec2 = vec[6];
				vec3 = vec[5];
				vec4 = vec[4];
			} else if (i == 2) {
				vec1 = vec[1];
				vec2 = vec[0];
				vec3 = vec[4];
				vec4 = vec[5];
				u1 = (float) (tU + tU1) / 256F; // 256.0F;
				u2 = (float) (tU + tU2) / 256F; // 256.0F;
				v1 = (float) (tV + tV1) / 256F; // 256.0F;
				v2 = (float) (tV + tV1 + 2) / 256F; // 256.0F;
			} else if (i == 3) {
				vec1 = vec[2];
				vec2 = vec[1];
				vec3 = vec[5];
				vec4 = vec[6];
			} else if (i == 4) {
				vec1 = vec[3];
				vec2 = vec[2];
				vec3 = vec[6];
				vec4 = vec[7];
			} else if (i == 5) {
				vec1 = vec[0];
				vec2 = vec[3];
				vec3 = vec[7];
				vec4 = vec[4];
			}

			tes.addVertexWithUV(vec1.xCoord, vec1.yCoord, vec1.zCoord, (double) u1, (double) v2);
			tes.addVertexWithUV(vec2.xCoord, vec2.yCoord, vec2.zCoord, (double) u2, (double) v2);
			tes.addVertexWithUV(vec3.xCoord, vec3.yCoord, vec3.zCoord, (double) u2, (double) v1);
			tes.addVertexWithUV(vec4.xCoord, vec4.yCoord, vec4.zCoord, (double) u1, (double) v1);
		}

		if (z8) {
			double i64 = vec[0].yCoord;
			double _w = 0.03125F;
			double e1 = 0.5F - _w / 2.0F;
			double e2 = e1 + _w;

			// !
			int _tU = (mod_ScatteredFeature.tripWire.blockIndexInTexture & 15) << 4;
			int _tV = mod_ScatteredFeature.tripWire.blockIndexInTexture & 240;
			double _u1 = (double) ((float) _tU / 256.0F);
			double _u2 = (double) ((float) (_tU + 16) / 256.0F);
			double _v1 = (double) ((float) (_tV + (z8 ? 2 : 0)) / 256.0F);
			double _v2 = (double) ((float) (_tV + (z8 ? 4 : 2)) / 256.0F);
			
			double tes9 = (double) (onSurface ? 3.5F : 1.5F) / 16.0D;
			light = block.getBlockBrightness(rb.blockAccess, x, y, z) * 0.75F;
			tes.setColorOpaque_F(light, light, light);

			if (orientation == 2) {
				tes.addVertexWithUV((x + e1), y + tes9, z + 0.25D, _u1, _v1);
				tes.addVertexWithUV((x + e2), y + tes9, z + 0.25D, _u1, _v2);
				tes.addVertexWithUV((x + e2), y + tes9, z, _u2, _v2);
				tes.addVertexWithUV((x + e1), y + tes9, z, _u2, _v1);
				tes.addVertexWithUV((x + e1), i64, z + 0.5D, _u1, _v1);
				tes.addVertexWithUV((x + e2), i64, z + 0.5D, _u1, _v2);
				tes.addVertexWithUV((x + e2), y + tes9, z + 0.25D, _u2, _v2);
				tes.addVertexWithUV((x + e1), y + tes9, z + 0.25D, _u2, _v1);
			} else if (orientation == 0) {
				tes.addVertexWithUV((x + e1), y + tes9, z + 0.75D, _u1, _v1);
				tes.addVertexWithUV((x + e2), y + tes9, z + 0.75D, _u1, _v2);
				tes.addVertexWithUV((x + e2), i64, z + 0.5D, _u2, _v2);
				tes.addVertexWithUV((x + e1), i64, z + 0.5D, _u2, _v1);
				tes.addVertexWithUV((x + e1), y + tes9, (z + 1), _u1, _v1);
				tes.addVertexWithUV((x + e2), y + tes9, (z + 1), _u1, _v2);
				tes.addVertexWithUV((x + e2), y + tes9, z + 0.75D, _u2, _v2);
				tes.addVertexWithUV((x + e1), y + tes9, z + 0.75D, _u2, _v1);
			} else if (orientation == 1) {
				tes.addVertexWithUV(x, y + tes9, (z + e2), _u1, _v2);
				tes.addVertexWithUV(x + 0.25D, y + tes9, (z + e2), _u2, _v2);
				tes.addVertexWithUV(x + 0.25D, y + tes9, (z + e1), _u2, _v1);
				tes.addVertexWithUV(x, y + tes9, (z + e1), _u1, _v1);
				tes.addVertexWithUV(x + 0.25D, y + tes9, (z + e2), _u1, _v2);
				tes.addVertexWithUV(x + 0.5D, i64, (z + e2), _u2, _v2);
				tes.addVertexWithUV(x + 0.5D, i64, (z + e1), _u2, _v1);
				tes.addVertexWithUV(x + 0.25D, y + tes9, (z + e1), _u1, _v1);
			} else {
				tes.addVertexWithUV(x + 0.5D, i64, (z + e2), _u1, _v2);
				tes.addVertexWithUV(x + 0.75D, y + tes9, (z + e2), _u2, _v2);
				tes.addVertexWithUV(x + 0.75D, y + tes9, (z + e1), _u2, _v1);
				tes.addVertexWithUV(x + 0.5D, i64, (z + e1), _u1, _v1);
				tes.addVertexWithUV(x + 0.75D, y + tes9, (z + e2), _u1, _v2);
				tes.addVertexWithUV((x + 1), y + tes9, (z + e2), _u2, _v2);
				tes.addVertexWithUV((x + 1), y + tes9, (z + e1), _u2, _v1);
				tes.addVertexWithUV(x + 0.75D, y + tes9, (z + e1), _u1, _v1);
			}
		}

		return true;
	}

}
