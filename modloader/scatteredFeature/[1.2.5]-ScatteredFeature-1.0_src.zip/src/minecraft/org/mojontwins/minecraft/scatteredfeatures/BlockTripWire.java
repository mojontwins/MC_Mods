package org.mojontwins.minecraft.scatteredfeatures;

import java.util.List;
import java.util.Random;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Direction;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Item;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_ScatteredFeature;

public class BlockTripWire extends Block {
	public BlockTripWire(int par1, int textureID) {
		super(par1, textureID, Material.circuits);
		this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.15625F, 1.0F);
		this.setTickRandomly(true);
	}

	/**
	 * How many world ticks before ticking
	 */
	@Override
	public int tickRate() {
		return 10;
	}

	/**
	 * Returns a bounding box from the pool of bounding boxes (this means this box
	 * can change after the pool has been cleared to be reused)
	 */
	@Override
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int par2, int par3, int par4) {
		return null;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether or
	 * not to render the shared face of two adjacent blocks and also whether the
	 * player can attach torches, redstone wire, etc to this block.
	 */
	@Override
	public boolean isOpaqueCube() {
		return false;
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	@Override
	public boolean renderAsNormalBlock() {
		return false;
	}

	/**
	 * Returns which pass should this block be rendered on. 0 for solids and 1 for
	 * alpha
	 */
	@Override
	public int getRenderBlockPass() {
		return 1;
	}

	/**
	 * The type of render function that is called for this block
	 */
	@Override
	public int getRenderType() {
		return mod_ScatteredFeature.tripWireRenderType;
	}

	/**
	 * Returns the ID of the items to drop on destruction.
	 */
	@Override
	public int idDropped(int par1, Random par2Random, int par3) {
		return Item.silk.shiftedIndex;
	}

	/**
	 * Lets the block know when one of its neighbor changes. Doesn't know which
	 * neighbor changed (coordinates passed are their own) Args: x, y, z, neighbor
	 * blockID
	 */
	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, int par5) {
		int meta = world.getBlockMetadata(x, y, z);
		boolean var7 = (meta & 2) == 2;
		boolean var8 = !mod_ScatteredFeature.doesBlockHaveSolidTopSurface(world, x, y - 1, z);

		if (var7 != var8) {
			this.dropBlockAsItem(world, x, y, z, meta, 0);
			world.setBlockWithNotify(x, y, z, 0);
		}
	}

	/**
	 * Updates the blocks bounds based on its current state. Args: world, x, y, z
	 */
	@Override
	public void setBlockBoundsBasedOnState(IBlockAccess world, int x, int y, int z) {
		int meta = world.getBlockMetadata(x, y, z);
		boolean var6 = (meta & 4) == 4;
		boolean var7 = (meta & 2) == 2;

		if (!var7) {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.09375F, 1.0F);
		} else if (!var6) {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
		} else {
			this.setBlockBounds(0.0F, 0.0625F, 0.0F, 1.0F, 0.15625F, 1.0F);
		}
	}

	/**
	 * Called whenever the block is added into the world. Args: world, x, y, z
	 */
	@Override
	public void onBlockAdded(World world, int x, int y, int z) {
		int var5 = mod_ScatteredFeature.doesBlockHaveSolidTopSurface(world, x, y - 1, z) ? 0 : 2;
		world.setBlockMetadataWithNotify(x, y, z, var5);
		this.func_72149_e(world, x, y, z, var5);
	}

	/**
	 * ejects contained items into the world, and notifies neighbours of an update,
	 * as appropriate
	 */
	@Override
	public void onBlockRemoval(World world, int x, int y, int z) {
		// Changed, this needed the new onBlockRemoval that is passed id and meta, which is not in r1.2.5
		int meta = world.getBlockMetadata(x, y, z);
		this.func_72149_e(world, x, y, z, meta | 1);
	}

	/**
	 * Called when the block is attempted to be harvested
	 */
	@Override
	public boolean blockActivated(World world, int x, int y, int z, EntityPlayer par6EntityPlayer) {
		if (!world.isRemote) {
			if (par6EntityPlayer.getCurrentEquippedItem() != null
					&& par6EntityPlayer.getCurrentEquippedItem().itemID == Item.shears.shiftedIndex) {
				int meta = world.getBlockMetadata(x, y, z);
				world.setBlockMetadataWithNotify(x, y, z, meta | 8);
				return true;
			}
		}
		
		return false;
	}

	private void func_72149_e(World world, int x, int y, int z, int par5) {
		int var6 = 0;

		while (var6 < 2) {
			int var7 = 1;

			while (true) {
				if (var7 < 42) {
					int var8 = x + Direction.offsetX[var6] * var7;
					int var9 = z + Direction.offsetZ[var6] * var7;
					int var10 = world.getBlockId(var8, y, var9);

					if (var10 == mod_ScatteredFeature.tripWireSource.blockID) {
						int var11 = world.getBlockMetadata(var8, y, var9) & 3;

						if (var11 == Direction.footInvisibleFaceRemap[var6]) {
							mod_ScatteredFeature.tripWireSource.updateTripwireSource(world, var8, y, var9, var10,
									world.getBlockMetadata(var8, y, var9), true, var7, par5);
						}
					} else if (var10 == mod_ScatteredFeature.tripWire.blockID) {
						++var7;
						continue;
					}
				}

				++var6;
				break;
			}
		}
	}

	/**
	 * Triggered whenever an entity collides with this block (enters into the
	 * block). Args: world, x, y, z, entity
	 */
	public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity par5Entity) {
		if (!world.isRemote) {
			if ((world.getBlockMetadata(x, y, z) & 1) != 1) {
				this.updateTripWireState(world, x, y, z);
			}
		}
	}

	/**
	 * Ticks the block if it's been scheduled
	 */
	public void updateTick(World world, int x, int y, int z, Random par5Random) {
		if (!world.isRemote) {
			if ((world.getBlockMetadata(x, y, z) & 1) == 1) {
				this.updateTripWireState(world, x, y, z);
			}
		}
	}

	private void updateTripWireState(World world, int x, int y, int z) {
		int var5 = world.getBlockMetadata(x, y, z);
		boolean var6 = (var5 & 1) == 1;
		boolean var7 = false;
		// List<Entity> var8 =
		// world.getEntitiesWithinAABBExcludingEntity((Entity)null,
		// AxisAlignedBB.getAABBPool().addOrModifyAABBInPool((double)x + this.minX,
		// (double)y + this.minY, (double)z + this.minZ, (double)x + this.maxX,
		// (double)y + this.maxY, (double)z + this.maxZ));
		List<Entity> var8 = world.getEntitiesWithinAABBExcludingEntity((Entity) null,
				AxisAlignedBB.getBoundingBoxFromPool((double) x + this.minX, (double) y + this.minY,
						(double) z + this.minZ, (double) x + this.maxX, (double) y + this.maxY,
						(double) z + this.maxZ));

		if (!var8.isEmpty()) {
			var7 = true;
		}

		if (var7 && !var6) {
			var5 |= 1;
		}

		if (!var7 && var6) {
			var5 &= -2;
		}

		if (var7 != var6) {
			world.setBlockMetadataWithNotify(x, y, z, var5);
			this.func_72149_e(world, x, y, z, var5);
		}

		if (var7) {
			world.scheduleBlockUpdate(x, y, z, this.blockID, this.tickRate());
		}
	}

	public static boolean connected(IBlockAccess world, int x, int y, int z, int meta, int side) {
		int var6 = x + Direction.offsetX[side];
		int var8 = z + Direction.offsetZ[side];
		int var9 = world.getBlockId(var6, y, var8);
		boolean var10 = (meta & 2) == 2;
		int var11;

		if (var9 == mod_ScatteredFeature.tripWireSource.blockID) {
			var11 = world.getBlockMetadata(var6, y, var8);
			int var13 = var11 & 3;
			return var13 == Direction.footInvisibleFaceRemap[side];
		} else if (var9 == mod_ScatteredFeature.tripWire.blockID) {
			var11 = world.getBlockMetadata(var6, y, var8);
			boolean var12 = (var11 & 2) == 2;
			return var10 == var12;
		} else {
			return false;
		}
	}
}
